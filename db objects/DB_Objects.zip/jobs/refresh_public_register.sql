begin
  sys.dbms_scheduler.create_job(job_name            => 'CRC_ENTRY.REFRESH_PUBLUC_REGISTER',
                                job_type            => 'PLSQL_BLOCK',
                                job_action          => 'BEGIN
    get_new_data;
  END;',
                                start_date          => to_date('03-02-2012 00:00:00', 'dd-mm-yyyy hh24:mi:ss'),
                                repeat_interval     => 'Freq=Daily;ByHour=04;ByMinute=00;BySecond=00',
                                end_date            => to_date(null),
                                job_class           => 'DEFAULT_JOB_CLASS',
                                enabled             => true,
                                auto_drop           => false,
                                comments            => '');
end;
/