create or replace view v_co_company_actual_info as
select  cc.id cc_id
      , cc.uri
      , cc_h."ID",cc_h."CNAME",cc_h."BULSTAT",cc_h."FIRM_DEL_NO",cc_h."FIRM_DEL_YEAR"
      , cc_h."FIRM_DEL_CORT",cc_h."ADDRESS", cc_h."VER_DATE_FROM", cc_h."VER_DATE_TO", cc_h."USER_CREATED"
      , cc_h."DATE_CREATED", cc_h."USER_UPDATED", cc_h."DATE_UPDATED", cc_h."COMPANY_ID", cc_h."NOMENCL_C_TYPE_ID"
      , cc_h."CITY_ID",cc_h."IBAN",cc_h."BIC",cc_h."WEB_ADDRESS"
      , cc_h.trade_mark, cc_h.country
      , nn.name type_name
      , nn.description type_name_en
      , nc.c_type city_type
      , nc.c_name city_name
      , nc.post_code
      , nc.manicip
      , nc.district
      , nr.r_name
from    co_companies cc
      , co_companies_h cc_h
      , nom_nomenclatures nn
      , nom_cities nc
      , nom_rayons nr
where   cc_h.company_id = cc.id
and     cc_h.nomencl_c_type_id = nn.id
and     cc_h.city_id = nc.id(+)
and     cc_h.nomencl_rayons_id = nr.id(+)
and     cc_h.ver_date_from = (select max(ch.ver_date_from)
                              from   co_companies_h ch
                              where  ch.company_id = cc.id)
and     nvl(cc_h.is_person,0) = 0
