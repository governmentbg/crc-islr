create or replace view v_reg_uvedomlen_ul
as
select distinct
t.UL_NAME CompanyName,
t.UL_TYPE CompanyType,
t.eik EIK,
t.web WEBAddress,
t.UL_ADDRESS||', �.���: '||t.UL_PK||', '||t.UL_GR_SELO||' '||t.UL_NAS_MESTO||', ������:'||t.UL_OBSHTINA||', ������: '||t.UL_OBLAST HeadquartersAddress,
case when trim(lk.LK_NAME||' '||lk.LK_PREZIME||' '||lk.LK_FAMILIA) is not null then
  lk.LK_NAME||' '||lk.LK_PREZIME||' '||lk.LK_FAMILIA
else
  null
end ContactPersonName,
--lk.TEL_KOD,
ltrim(lk.TEL_KOD||' '||lk.TEL) PhoneNumber,
lk.E_MAIL �mail,
lk.LK_ADDRESS||', �.���: '||lk.LK_PK||', '||lk.LK_GR_SELO||' '||lk.LK_NAS_MESTO||', ������:'||lk.LK_OBSHTINA||', ������: '||lk.LK_OBLAST PersonAddress,
lk.LK_PK,
lk.LK_GR_SELO,
lk.LK_NAS_MESTO,
lk.LK_OBSHTINA,
lk.LK_OBLAST
from mv_uvedomlenia_ul t
left outer join mv_uvedomlenia_lk lk on
  t.id = lk.ul_id
