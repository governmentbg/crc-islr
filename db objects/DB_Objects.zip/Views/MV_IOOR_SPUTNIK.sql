CREATE OR REPLACE VIEW MV_IOOR_SPUTNIK AS
SELECT
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  p.no vh_nomer,
  p.date_from vh_data,
  p.date_end data_prik,
  pu.name prednaznachenie,
  v.ctrl_station_location mestopol,
  g.t_freq_range Ches_predav,
  g.t_total_bandwidth Ches_len_predav,
  g.r_freq_range Ches_len_priem
  , st.name status
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and nvl(public_register_incl,0) = 1)
                                 )
  join nom_nomenclatures pt on (p.nomencl_type_id = pt.id and pt.prog_name = 'SATS_BULSATS')
  join nom_nomenclatures st on p.nomencl_status_id = st.id and st.prog_name <> 'PROJECT'
  left outer join nom_nomenclatures pu on (p.nomencl_id_net_purpose = pu.id)
  left outer join radio_nets_satellit v on (v.perm_ioor_id = request_routines.last_perm_with_technodata(p.id,pt.prog_name))
  left outer join radio_sat_ground_stations g on (g.sat_srv_net_id = v.id)
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');
