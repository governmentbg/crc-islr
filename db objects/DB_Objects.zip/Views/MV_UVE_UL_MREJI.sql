CREATE OR REPLACE VIEW MV_UVE_UL_MREJI AS
SELECT
t.company_id ul_id,
t.cname ul_name,
n.name ul_type,
s.start_date date_nadlejno,
s.descr_pr usl_mre_descr,
CASE c.c_type
    WHEN '������' THEN '������'
    WHEN '�����' THEN '�-�'
    else c.c_type
end gr_selo,
c.c_name nas_mesto,
c.manicip obshtina,
c.district oblast,
a.stard_date predpolag_data,
a.end_date data_prekratiavane
FROM co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join pec_notif_nets s on (t.company_id = s.company_id)
  join nom_nomenclatures stat on (s.nomencl_id_status = stat.id and stat.prog_name in ('NSSTAT_INS','NSSTAT_SINS'))
  join pec_notif_net_area a on (s.id = a.pec_nt_net_id and (a.end_date is null or a.end_date > trunc(sysdate)))
  join nom_cities c on (a.city_id = c.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');
