CREATE OR REPLACE VIEW MV_IOOR_NOMERA AS
SELECT
  t.cname ul_name,
  n.name ul_type,
  case
    when p.initial_change_no is null then p.no
    else p.no||'-'||lpad(p.initial_change_no,3,'0')
  end resh_nomer,
  p.initial_date resh_data,
  p.date_end data_prik,
  ntr.name vid_razreshenie,
  t.bulstat eik
  , ns.name status
  , p.abortion_date termination_date
  , t.id
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0))
                                                             from co_permissions_ioor pi
                                                             join nom_nomenclatures nsi on (pi.nomencl_status_id = nsi.id)
                                                            where no = p.no and crc_abortion_no_date is null
                                                                  and nsi.prog_name != 'PROJECT')--and nvl(public_register_incl,0)=1
                                 )
  join nom_nomenclatures nt on (p.nomencl_type_id = nt.id and nt.prog_name = 'TREP')
  join nom_nomenclatures ntr on (p.nomencl_perm_type_id = ntr.id )
  join nom_nomenclatures ns on (p.nomencl_status_id = ns.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY')
  and ns.prog_name = 'PSTAT_INS'
;
