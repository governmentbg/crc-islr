CREATE OR REPLACE VIEW MV_IOOR_TELE_ME AS
SELECT
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  case
    when p.initial_change_no is null then p.no
    else p.no||'-'||lpad(p.initial_change_no,3,'0')
  end vh_nomer,
  p.date_from vh_data,
  nvl(to_char(p.DATE_END,'DD.MM.YYY'), p.description) data_prik,
  pu.name prednazn_mre,
  c.c_type gr_selo,
  c.c_name nas_mesto,
  c.district oblast,
  v.carrier_frequency_at_transm nos_chestota,
  v.working_channel rab_kanal
  ,pst.name status
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and nvl(public_register_incl,0) = 1 and company_id = t.company_id)
                                 and nvl(p.is_national,0)=0)
  join nom_nomenclatures pt on (p.nomencl_type_id = pt.id and pt.prog_name = 'RTYPE_101TVA')
  join nom_nomenclatures pst on (p.nomencl_status_id = pst.id and pst.prog_name = 'PSTAT_INS')
  left outer join nom_nomenclatures pu on (p.nomencl_id_net_purpose = pu.id)
  left outer join radio_nets_tv v on (v.perm_ioor_id = request_routines.last_perm_with_technodata(p.id,pt.prog_name))
  left outer join nom_cities c on (c.id = v.city_id)
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');
