connect crc
create or replace view nomera_all as
select
  t.company_id ID/* ЮЛ */,
  t.cname ul_name/* Наименование на ЮЛ съгласно съдебната регистрация */,
  n.name ul_type/* Наименование */,
  nvl(r.decision_no, pi.crc_resolution) decision_no/* Номер на решение */,
  nvl2(r.decision_no, r.decision_date, pi.crc_resolution_date) decision_date/* Дата на решение */,
  nc.code register_code, /*гн - географски номера, 700 - 700, 800 - 800, 90 - 90, 99x - 99X, 116xyz - 116XYZ, 118xy - 118XY,
                           кди - Internet, ISPC - ISPC, 10xy - избор на оператор, M2M, MNC, цммрежи- мобилни, NSPC - NSPC */
  -- географски номера
  r.code geo_kod/* Код */,
--  r.location nas_mesto/* Населено място */,
  r.num_group nom_grupa/* Номерационна група */,
  -- 700, 800
  r.code kod_za_dostap/* Код */,
  r.id_net net_id /* Идентификатор на мрежата */,
  upper(r.num_group) ab_nomera/* Абонатни номера */,
  -- 90
--  r.code kod/* Код */,
--  r.id_net net_id/* Идентификатор на мрежата */,
  nst.name tarifa_id/* Идентификатор на тарифа */,
--  upper(r.num_group) ab_nomera/* Абонатни номера */,
  -- 99X
--  r.code kod/* Код */
  -- 116XYZ
--  r.code kod/* Код */,
  r.service usluga/* Услуга */,
  t.cname predostaven_na/* Наименование на ЮЛ съгласно съдебната регистрация */,
  -- 118XY
--  r.code nomer_za_dostap /* Номер за достъп */,
  -- Internet
  r.code predostaven_nomer/* Код */,
  -- ISPC
  r.bin_dec_no ISPC /* Код */,
  -- избор на оператор - 10xy
  r.code predostaven_kod /* Номер за достъп */,
  -- M2M
--  r.code kod/* Код */,
--  r.id_net net_id /* Идентификатор на мрежата */,
--  upper(r.num_group) ab_nomera/* Абонатни номера */,
  -- MNC
--  r.code kod/* Код */,
  -- мобилни
--  r.code kod/* Код */,
  -- NSPC
  r.zz||'-'||r.yy||'-'||r.xx NSPC,/* Код */
  -- цммрежи
--  r.code kod_za_dostap/* Код */,
  -- uslugi
--  r.service usluga/* Услуга */,
--  r.code predostaven_nomer/* Код */,
  null nat_nom

from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join tn_resources r on (t.company_id = r.company_id and r.pr_publication = 1 and r.req_id is null and r.req_id_denied_by is null)
  join nom_nomenclatures nc on (r.nomencl_id_res_type = nc.id )
  left join co_permissions_ioor pi on (r.perm_ioor_id = pi.id )
  left join nom_nomenclatures nst on (r.nomencl_id_serv_type = nst.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY')
union all
select
  null,null,null,null,null,
  nc.code, -- 'нму'
  null,null,null,null,null,
  null,null,null,null,null,
  null,null,
  r.code nat_nom/* Код */
--  r.service usluga/* Услуга */
from
  tn_resources r
  join nom_nomenclatures nc on (r.nomencl_id_res_type = nc.id and nc.code = 'нму')
where  r.pr_publication = 1 and r.req_id is null and r.req_id_denied_by is null;
grant select on nomera_all to crc_entry;

connect crc_entry
create or replace view mv_nomera_all as
select id, ul_name, ul_type, decision_no, decision_date, register_code, geo_kod, nom_grupa, kod_za_dostap, net_id, ab_nomera, tarifa_id, usluga, predostaven_nomer, predostaven_na, ispc, predostaven_kod, nspc, nomer
from crc.nomera_all;
create table number_registers as select net_type numb_type, register_text, sort_level, add_columns from ioor_registers;

delete number_registers;