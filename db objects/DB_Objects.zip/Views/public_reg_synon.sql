---------------------------------------------------
-- Export file for user CRCONE                   --
-- Created by kkaloyanov on 24.03.2011, 12:24:47 --
---------------------------------------------------

spool public_reg_synon.log

prompt
prompt Creating synonym MV_GEOSTA_BUL00
prompt ================================
prompt
create or replace synonym MV_GEOSTA_BUL00
  for CRC.MV_GEOSTA_BUL00;

prompt
prompt Creating synonym MV_GEOSTA_BUL02
prompt ================================
prompt
create or replace synonym MV_GEOSTA_BUL02
  for CRC.MV_GEOSTA_BUL02;

prompt
prompt Creating synonym MV_IOOR_DVB_T
prompt ==============================
prompt
create or replace synonym MV_IOOR_DVB_T
  for CRC.MV_IOOR_DVB_T;

prompt
prompt Creating synonym MV_IOOR_GEOSTA_UL
prompt ==================================
prompt
create or replace synonym MV_IOOR_GEOSTA_UL
  for CRC.MV_IOOR_GEOSTA_UL;

prompt
prompt Creating synonym MV_IOOR_NOMERA
prompt ===============================
prompt
create or replace synonym MV_IOOR_NOMERA
  for CRC.MV_IOOR_NOMERA;

prompt
prompt Creating synonym MV_IOOR_NOMERA_UL
prompt ==================================
prompt
create or replace synonym MV_IOOR_NOMERA_UL
  for CRC.MV_IOOR_NOMERA_UL;

prompt
prompt Creating synonym MV_IOOR_PAGING
prompt ===============================
prompt
create or replace synonym MV_IOOR_PAGING
  for CRC.MV_IOOR_PAGING;

prompt
prompt Creating synonym MV_IOOR_PMR
prompt ============================
prompt
create or replace synonym MV_IOOR_PMR
  for CRC.MV_IOOR_PMR;

prompt
prompt Creating synonym MV_IOOR_P_TO_MP
prompt ================================
prompt
create or replace synonym MV_IOOR_P_TO_MP
  for CRC.MV_IOOR_P_TO_MP;

prompt
prompt Creating synonym MV_IOOR_P_TO_P
prompt ===============================
prompt
create or replace synonym MV_IOOR_P_TO_P
  for CRC.MV_IOOR_P_TO_P;

prompt
prompt Creating synonym MV_IOOR_RADIOCHES_UL
prompt =====================================
prompt
create or replace synonym MV_IOOR_RADIOCHES_UL
  for CRC.MV_IOOR_RADIOCHES_UL;

prompt
prompt Creating synonym MV_IOOR_RADIO_FM_ME
prompt ====================================
prompt
create or replace synonym MV_IOOR_RADIO_FM_ME
  for CRC.MV_IOOR_RADIO_FM_ME;

prompt
prompt Creating synonym MV_IOOR_RADIO_FM_NA
prompt ====================================
prompt
create or replace synonym MV_IOOR_RADIO_FM_NA
  for CRC.MV_IOOR_RADIO_FM_NA;

prompt
prompt Creating synonym MV_IOOR_SPUTNIK
prompt ================================
prompt
create or replace synonym MV_IOOR_SPUTNIK
  for CRC.MV_IOOR_SPUTNIK;

prompt
prompt Creating synonym MV_IOOR_TELE_ME
prompt ================================
prompt
create or replace synonym MV_IOOR_TELE_ME
  for CRC.MV_IOOR_TELE_ME;

prompt
prompt Creating synonym MV_IOOR_TELE_NA
prompt ================================
prompt
create or replace synonym MV_IOOR_TELE_NA
  for CRC.MV_IOOR_TELE_NA;

prompt
prompt Creating synonym MV_IOOR_TETRA
prompt ==============================
prompt
create or replace synonym MV_IOOR_TETRA
  for CRC.MV_IOOR_TETRA;

prompt
prompt Creating synonym MV_IOOR_TRUNK
prompt ==============================
prompt
create or replace synonym MV_IOOR_TRUNK
  for CRC.MV_IOOR_TRUNK;

prompt
prompt Creating synonym MV_NOMERA_116XYZ
prompt =================================
prompt
create or replace synonym MV_NOMERA_116XYZ
  for CRC.MV_NOMERA_116XYZ;

prompt
prompt Creating synonym MV_NOMERA_118XY
prompt ================================
prompt
create or replace synonym MV_NOMERA_118XY
  for CRC.MV_NOMERA_118XY;

prompt
prompt Creating synonym MV_NOMERA_700
prompt ==============================
prompt
create or replace synonym MV_NOMERA_700
  for CRC.MV_NOMERA_700;

prompt
prompt Creating synonym MV_NOMERA_800
prompt ==============================
prompt
create or replace synonym MV_NOMERA_800
  for CRC.MV_NOMERA_800;

prompt
prompt Creating synonym MV_NOMERA_90
prompt =============================
prompt
create or replace synonym MV_NOMERA_90
  for CRC.MV_NOMERA_90;

prompt
prompt Creating synonym MV_NOMERA_99X
prompt ==============================
prompt
create or replace synonym MV_NOMERA_99X
  for CRC.MV_NOMERA_99X;

prompt
prompt Creating synonym MV_NOMERA_DOST_INTERNET
prompt ========================================
prompt
create or replace synonym MV_NOMERA_DOST_INTERNET
  for CRC.MV_NOMERA_DOST_INTERNET;

prompt
prompt Creating synonym MV_NOMERA_GEOGRAPH
prompt ===================================
prompt
create or replace synonym MV_NOMERA_GEOGRAPH
  for CRC.MV_NOMERA_GEOGRAPH;

prompt
prompt Creating synonym MV_NOMERA_ISPC
prompt ===============================
prompt
create or replace synonym MV_NOMERA_ISPC
  for CRC.MV_NOMERA_ISPC;

prompt
prompt Creating synonym MV_NOMERA_IZBOR_OPERATOR
prompt =========================================
prompt
create or replace synonym MV_NOMERA_IZBOR_OPERATOR
  for CRC.MV_NOMERA_IZBOR_OPERATOR;

prompt
prompt Creating synonym MV_NOMERA_MOBILNI_MR
prompt =====================================
prompt
create or replace synonym MV_NOMERA_MOBILNI_MR
  for CRC.MV_NOMERA_MOBILNI_MR;

prompt
prompt Creating synonym MV_NOMERA_NOMERA_USLUGI
prompt ========================================
prompt
create or replace synonym MV_NOMERA_NOMERA_USLUGI
  for CRC.MV_NOMERA_NOMERA_USLUGI;

prompt
prompt Creating synonym MV_NOMERA_NSPC
prompt ===============================
prompt
create or replace synonym MV_NOMERA_NSPC
  for CRC.MV_NOMERA_NSPC;

prompt
prompt Creating synonym MV_NOMERA_POVREDI
prompt ==================================
prompt
create or replace synonym MV_NOMERA_POVREDI
  for CRC.MV_NOMERA_POVREDI;

prompt
prompt Creating synonym MV_POSHTI_NPU
prompt ==============================
prompt
create or replace synonym MV_POSHTI_NPU
  for CRC.MV_POSHTI_NPU;

prompt
prompt Creating synonym MV_POSHTI_NPU_UL
prompt =================================
prompt
create or replace synonym MV_POSHTI_NPU_UL
  for CRC.MV_POSHTI_NPU_UL;

prompt
prompt Creating synonym MV_POSHTI_UPU
prompt ==============================
prompt
create or replace synonym MV_POSHTI_UPU
  for CRC.MV_POSHTI_UPU;

prompt
prompt Creating synonym MV_POSHTI_UPU_UL
prompt =================================
prompt
create or replace synonym MV_POSHTI_UPU_UL
  for CRC.MV_POSHTI_UPU_UL;

prompt
prompt Creating synonym MV_PREHV_PRAVA
prompt ===============================
prompt
create or replace synonym MV_PREHV_PRAVA
  for CRC.MV_PREHV_PRAVA;

prompt
prompt Creating synonym MV_RADIOLUB_FL
prompt ===============================
prompt
create or replace synonym MV_RADIOLUB_FL
  for CRC.MV_RADIOLUB_FL;

prompt
prompt Creating synonym MV_RADIOLUB_UL
prompt ===============================
prompt
create or replace synonym MV_RADIOLUB_UL
  for CRC.MV_RADIOLUB_UL;

prompt
prompt Creating synonym MV_UVEDOMLENIA_KS
prompt ==================================
prompt
create or replace synonym MV_UVEDOMLENIA_KS
  for CRC.MV_UVEDOMLENIA_KS;

prompt
prompt Creating synonym MV_UVEDOMLENIA_KS_UL
prompt =====================================
prompt
create or replace synonym MV_UVEDOMLENIA_KS_UL
  for CRC.MV_UVEDOMLENIA_KS_UL;

prompt
prompt Creating synonym MV_UVEDOMLENIA_LK
prompt ==================================
prompt
create or replace synonym MV_UVEDOMLENIA_LK
  for CRC.MV_UVEDOMLENIA_LK;

prompt
prompt Creating synonym MV_UVEDOMLENIA_UL
prompt ==================================
prompt
create or replace synonym MV_UVEDOMLENIA_UL
  for CRC.MV_UVEDOMLENIA_UL;

prompt
prompt Creating synonym MV_UVE_UL_MREJI
prompt ================================
prompt
create or replace synonym MV_UVE_UL_MREJI
  for CRC.MV_UVE_UL_MREJI;

prompt
prompt Creating synonym MV_UVE_UL_USLUGI
prompt =================================
prompt
create or replace synonym MV_UVE_UL_USLUGI
  for CRC.MV_UVE_UL_USLUGI;


spool off
