------------------------------------------------------
-- Export file for user CRC                         --
-- Created by tkaloyanov on 01.10.2014 �., 19:31:04 --
------------------------------------------------------

spool crc_views_2014_10_01.log

prompt
prompt Creating view LOGGER_LOGS_5_MIN
prompt ===============================
prompt
create or replace view crc.logger_logs_5_min as
select "ID","LOGGER_LEVEL","TEXT","TIME_STAMP","SCOPE","MODULE","ACTION","USER_NAME","CLIENT_IDENTIFIER","CALL_STACK","UNIT_NAME","LINE_NO","SCN","EXTRA" 
      from logger_logs 
	 where time_stamp > systimestamp - (5/1440);

prompt
prompt Creating view LOGGER_LOGS_60_MIN
prompt ================================
prompt
create or replace view crc.logger_logs_60_min as
select "ID","LOGGER_LEVEL","TEXT","TIME_STAMP","SCOPE","MODULE","ACTION","USER_NAME","CLIENT_IDENTIFIER","CALL_STACK","UNIT_NAME","LINE_NO","SCN","EXTRA" 
      from logger_logs 
	 where time_stamp > systimestamp - (1/24);

prompt
prompt Creating view LOGGER_LOGS_TERSE
prompt ===============================
prompt
create or replace view crc.logger_logs_terse as
select id, logger_level, 
        substr(logger.date_text_format(time_stamp),1,20) time_ago,
        substr(text,1,200) text
   from logger_logs
  where time_stamp > systimestamp - (5/1440)
  order by id asc;

prompt
prompt Creating view MV_GEOSTA_BUL00
prompt =============================
prompt
CREATE OR REPLACE VIEW CRC.MV_GEOSTA_BUL00 AS
SELECT
 t.company_id ID/* �� */,
 t.cname ul_name/* ������������ �� �� �������� ��������� ����������� */,
 n.name ul_type/* ������������ */,
 cast(null as varchar2(3)) n_z_id/* ������������ �� ����������� �� ���� */,
 nt.name vid_mreja/* ������������ */,
 nu.name vid_usluga/* ������������ */,
 p.no razresh_no/* ������� ����� */,
 p.date_from razresh_data/* �� ���� */,
 p.date_start zapo_deynost_data/* ���� �� ��������� �� ������� */,
 p.date_end prikl_deynost_data/* ���� �� ����������� �� ������� */,
 p.description chest_lenta/* �������� �����/������ */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                         where no = p.no and nvl(public_register_incl,0) = 1))
  join nom_nomenclatures nt on (p.nomencl_type_id = nt.id and nt.prog_name = 'RTYPE_BUL00000')
  left outer join nom_nomenclatures nu on (/*p.nomencl_type_id*/p.nomencl_id_net_purpose = nu.id)
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');

prompt
prompt Creating view MV_GEOSTA_BUL02
prompt =============================
prompt
CREATE OR REPLACE VIEW CRC.MV_GEOSTA_BUL02 AS
SELECT
 t.company_id ID/* �� */,
 t.cname ul_name/* ������������ �� �� �������� ��������� ����������� */,
 n.name ul_type/* ������������ */,
 cast(null as varchar2(3)) n_z_id/* ������������ �� ����������� �� ���� */,
 nt.name vid_mreja/* ������������ */,
 nu.name vid_usluga/* ������������ */,
 p.no razresh_no/* ������� ����� */,
 p.date_from razresh_data/* �� ���� */,
 p.date_start zapo_deynost_data/* ���� �� ��������� �� ������� */,
 p.date_end prikl_deynost_data/* ���� �� ����������� �� ������� */,
 p.description chest_lenta/* �������� �����/������ */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                         where no = p.no and nvl(public_register_incl,0) = 1))
  join nom_nomenclatures nt on (p.nomencl_type_id = nt.id and nt.prog_name = 'RTYPE_BUL02000')
  left outer join nom_nomenclatures nu on (/*p.nomencl_type_id*/p.nomencl_id_net_purpose = nu.id)
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');

prompt
prompt Creating view MV_GEOSTA_MSS
prompt ===========================
prompt
CREATE OR REPLACE VIEW CRC.MV_GEOSTA_MSS AS
SELECT
p.change_no,
 t.company_id ID/* �� */,
 t.cname ul_name/* ������������ �� �� �������� ��������� ����������� */,
 n.name ul_type/* ������������ */,
 cast(null as varchar2(3)) n_z_id/* ������������ �� ����������� �� ���� */,
 nt.name vid_mreja/* ������������ */,
 nu.name vid_usluga/* ������������ */,
 p.no razresh_no/* ������� ����� */,
 p.date_from razresh_data/* �� ���� */,
 p.date_start zapo_deynost_data/* ���� �� ��������� �� ������� */,
 p.date_end prikl_deynost_data/* ���� �� ����������� �� ������� */,
 p.description chest_lenta/* �������� �����/������ */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                         where no = p.no and nvl(public_register_incl,0) = 1))
  join nom_nomenclatures nt on (p.nomencl_type_id = nt.id and nt.prog_name = 'RTYPE_MSS')
  left outer join nom_nomenclatures nu on (/*p.nomencl_type_id*/p.nomencl_id_net_purpose = nu.id)

where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');

prompt
prompt Creating view MV_IOOR_DVB_T
prompt ===========================
prompt
CREATE OR REPLACE VIEW CRC.MV_IOOR_DVB_T AS
SELECT distinct
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  case
    when p.initial_change_no is null then p.no
    else p.no||'-'||lpad(p.initial_change_no,3,'0')
  end vh_nomer,
  p.initial_date vh_data,
  p.date_end data_prik,
  pu.name prednaznach/* �������������� */,
  c.c_type gr_selo/* ����/���� */,
  c.c_name nas_mesto/* ������������ */,
  c.district oblast/* ������ */,
  /*f.address_text*/cast(null as varchar2(3)) address_txt,
  /*f.channel_lower_limit*/cast(null as varchar2(3)) dolna_gra,
  /*f.channel_upper_limit*/cast(null as varchar2(3)) gorna_gra,
  f.transmission_channel_number rab_kanal
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and nvl(public_register_incl,0) = 1)
                                 )
  join nom_nomenclatures pt on (p.nomencl_type_id = pt.id and pt.prog_name = /*'RTYPE_101FM'*/'RTYPE_101DVB')
  left outer join nom_nomenclatures pu on (p.nomencl_id_net_purpose = pu.id)
  left outer join radio_nets_dvbt_tdab f on (request_routines.last_perm_with_technodata(p.id,pt.prog_name) = f.perm_ioor_id)
  left outer join nom_cities c on (f.city_id = c.id)
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');

prompt
prompt Creating view MV_IOOR_GEOSTA_UL
prompt ===============================
prompt
create or replace view crc.mv_ioor_geosta_ul as
select
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  t.address ul_address/* ����� - ����� */,
  t.post_code ul_pk/* �������� ��� */,
  c.c_type ul_gr_selo/* ����/���� */,
  c.c_name ul_nas_mesto/* ������������ */,
  c.manicip ul_obshtina/* ������ */,
  c.district ul_oblast/* ������ */,
  t.bulstat eik,
  t.web_address web
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and nvl(public_register_incl,0) = 1)
                                 )
  join nom_nomenclatures nt on (p.nomencl_type_id = nt.id and nt.prog_name in ('RTYPE_BUL00000','RTYPE_BUL02000'))
  join nom_cities c on (t.city_id = c.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_IOOR_GSM_UMTS
prompt ==============================
prompt
CREATE OR REPLACE VIEW CRC.MV_IOOR_GSM_UMTS AS
SELECT distinct
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  case
    when p.initial_change_no is null then p.no
    else p.no||'-'||lpad(p.initial_change_no,3,'0')
  end vh_nomer,
  p.initial_date vh_data,
  p.date_end data_prik,
  pu.name prednaznach,
  case when pt.prog_name not like '%GSMR'
    then nvl(c.c_type,'���.')
    else nvl(c.c_type,'��.')
  end as gr_selo,
  case when pt.prog_name not like '%GSMR'
    then nvl(c.c_name,'��������� ��������')
    else /*nvl(c.c_name,'�������-����������')*/
      (select replace(stragg(RAILWAY_SECTION),',','<br>') railway_section_list
      from
          (select
              min(gsmr.station_no) min_station_no,
              gsmr.perm_ioor_id,
              gsmr.RAILWAY_SECTION
            from RADIO_GSMR_STATIONS gsmr
            group by gsmr.perm_ioor_id,gsmr.RAILWAY_SECTION
          order by min(gsmr.station_no)
          )
      where perm_ioor_id = request_routines.last_perm_with_technodata(p.id,pt.prog_name)
      )
  end as nas_mesto,
  c.district oblast,
  cast(null as varchar2(3)) ddescription,
  case
    when pt.prog_name  like '%GSM'
      and t.company_id in (2868,1361,113) --('��������','����� �������� ������','��������� ������������������ ��������')
      then '900 MHz<hr>1800 MHz'
    when pt.prog_name  like '%GSM'
      and t.company_id not in (2868,1361,113) --('��������','����� �������� ������','��������� ������������������ ��������')
      then '1800 MHz'
    when pt.prog_name like '%UMTS' then '2 GHz'
    when pt.prog_name like '%PAMR' then '420 MHz'
    when pt.prog_name like '%GSMR' then '876-880 MHz<hr>921-925 MHz'
    else null
  end chestot_obhvat,
  substr(pt.prog_name,5) network_type
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and nvl(public_register_incl,0) = 1)
                                 )
  join nom_nomenclatures pt on (p.nomencl_type_id = pt.id and pt.prog_name in ('MRS_GSM','MRS_UMTS','MRS_PAMR','MRS_GSMR'))
  left outer join nom_nomenclatures pu on (p.nomencl_id_net_purpose = pu.id)
  left outer join radio_spectrum_gsm_umts e on (e.perm_ioor_id = request_routines.last_perm_with_technodata(p.id,pt.prog_name) )
  left outer join nom_cities c on (c.id = e.city_id)
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');

prompt
prompt Creating view MV_IOOR_NOMERA
prompt ============================
prompt
CREATE OR REPLACE VIEW CRC.MV_IOOR_NOMERA AS
SELECT
  t.cname ul_name,
  n.name ul_type,
  case
    when p.initial_change_no is null then p.no
    else p.no||'-'||lpad(p.initial_change_no,3,'0')
  end resh_nomer,
  p.initial_date resh_data,
--  p.date_end data_prik,
  ntr.name vid_razreshenie
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and crc_abortion_no_date is null)--and nvl(public_register_incl,0)=1
                                 )
  join nom_nomenclatures nt on (p.nomencl_type_id = nt.id and nt.prog_name = 'TREP')
  join nom_nomenclatures ntr on (p.nomencl_perm_type_id = ntr.id )
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_IOOR_NOMERA_UL
prompt ===============================
prompt
create or replace view crc.mv_ioor_nomera_ul as
select
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  t.address ul_address/* ����� - ����� */,
  t.post_code ul_pk/* �������� ��� */,
  c.c_type ul_gr_selo/* ����/���� */,
  cast(null as varchar2(3)) DataId_86 /* ������������ */,
  c.c_name ul_nas_mesto/* ������������ */,
  c.manicip ul_obshtina/* ������ */,
  c.district ul_oblast/* ������ */,
  t.bulstat eik,
  t.web_address web
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and crc_abortion_no_date is null) --and nvl(public_register_incl,0)=1
                                 )
  join nom_nomenclatures nt on (p.nomencl_type_id = nt.id and nt.prog_name = 'TREP')
  join nom_cities c on (t.city_id = c.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_IOOR_PAGING
prompt ============================
prompt
CREATE OR REPLACE VIEW CRC.MV_IOOR_PAGING AS
SELECT
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  case
    when p.initial_change_no is null then p.no
    else p.no||'-'||lpad(p.initial_change_no,3,'0')
  end vh_nomer,
  p.initial_date vh_data,
  p.date_end data_prik,
  pu.name prednaznach,
  c.c_type gr_selo,
  c.c_name nas_mesto,
  c.district oblast,
  cast(null as varchar2(3)) ddescription,
  ch.name chestot_obhvat,
  (select count(*) from pmr_radio_net_frequencies f where f.pmr_pgng_trnk_id = e.id) broy
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and nvl(public_register_incl,0) = 1)
                                 )
  join nom_nomenclatures pt on (p.nomencl_type_id = pt.id and pt.prog_name = 'MRS_PAGING')
  left outer join nom_nomenclatures pu on (p.nomencl_id_net_purpose = pu.id)
  left outer join pmr_pgng_trnk_ttra_nets e on (e.perm_ioor_id = request_routines.last_perm_with_technodata(p.id,pt.prog_name) /*and e.public_register_incl = 1*/)
  left outer join pmr_service_territ_scopes ts on (e.id = ts.pmr_pgng_trnk_id)
  left outer join nom_cities c on (c.id = ts.city_id)
  left outer join nom_nomenclatures ch on (ch.id = e.NOMENCL_ID_FREQ_BAND)
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');

prompt
prompt Creating view MV_IOOR_PMR
prompt =========================
prompt
CREATE OR REPLACE VIEW CRC.MV_IOOR_PMR AS
SELECT
  t.company_id ID,
  e.id as pmr_net_id,
  t.cname ul_name,
  n.name ul_type,
  case
    when p.initial_change_no is null then p.no
    else p.no||'-'||lpad(p.initial_change_no,3,'0')
  end vh_nomer,
  p.initial_date vh_data,
  p.date_end data_prik,
  pu.name prednaznach,
  c.c_type gr_selo,
  c.c_name nas_mesto,
  c.district oblast,
  cast(null as varchar2(3)) ddescription,
  ch.name chestot_obhvat,
  (select count(*) from pmr_radio_net_frequencies f where f.pmr_pgng_trnk_id = e.id) broy
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and nvl(public_register_incl,0) = 1)
                                 )
  join nom_nomenclatures pt on (p.nomencl_type_id = pt.id and pt.prog_name in ('MRS_PMR','MRS_AIR'))
  left outer join nom_nomenclatures pu on (p.nomencl_id_net_purpose = pu.id)
  left outer join pmr_pgng_trnk_ttra_nets e on (e.perm_ioor_id = request_routines.last_perm_with_technodata(p.id,pt.prog_name)/* and e.public_register_incl = 1*/)
  left outer join pmr_service_territ_scopes ts on (e.id = ts.pmr_pgng_trnk_id)
  left outer join nom_cities c on (c.id = ts.city_id)
  left outer join nom_nomenclatures ch on (ch.id = e.NOMENCL_ID_FREQ_BAND)
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');

prompt
prompt Creating view MV_IOOR_P_TO_MP
prompt =============================
prompt
CREATE OR REPLACE VIEW CRC.MV_IOOR_P_TO_MP AS
SELECT
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  case
    when p.initial_change_no is null then p.no
    else p.no||'-'||lpad(p.initial_change_no,3,'0')
  end vh_nomer,
  p.initial_date vh_data,
  p.date_end data_prik,
  pu.name prednaznach/* �������������� */,
  c.c_type gr_selo,
  c.c_name nas_mesto,
  m.bandwidth_and_coverage chest_obhvat,
  m.blocks_count broi_blokove,
  m.total_spectrum obshto_spektar,
  substr(pt.prog_name,5) network_type
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and nvl(public_register_incl,0) = 1)
                                 )
  join nom_nomenclatures pt on (p.nomencl_type_id = pt.id and pt.prog_name in ('FRS_PMP_BWA','FRS_PMP_FWA'))
  left outer join nom_nomenclatures pu on (p.nomencl_id_net_purpose = pu.id)
  left outer join radio_nets_ptomp m on (request_routines.last_perm_with_technodata(p.id,pt.prog_name) = m.perm_ioor_id)
  left outer join nom_cities c on (m.city_id = c.id)
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');

prompt
prompt Creating view MV_IOOR_P_TO_P
prompt ============================
prompt
CREATE OR REPLACE VIEW CRC.MV_IOOR_P_TO_P AS
SELECT
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  case
    when p.initial_change_no is null then p.no
    else p.no||'-'||lpad(p.initial_change_no,3,'0')
  end vh_nomer,
  p.initial_date vh_data,
  p.date_end data_prik,
  pu.name prednaznach/* �������������� */,
  p.description chest_lenta
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and nvl(public_register_incl,0) = 1)
                                 )
  join nom_nomenclatures pt on (p.nomencl_type_id = pt.id and pt.prog_name = 'FRS_PP')
  left outer join nom_nomenclatures pu on (p.nomencl_id_net_purpose = pu.id)
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');

prompt
prompt Creating view MV_IOOR_RADIOCHES_UL
prompt ==================================
prompt
CREATE OR REPLACE VIEW CRC.MV_IOOR_RADIOCHES_UL AS
SELECT DISTINCT
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  t.address ul_address/* ����� - ����� */,
  t.post_code ul_pk/* �������� ��� */,
  c.c_type ul_gr_selo/* ����/���� */,
  cast(null as varchar2(3)) DataId_86 /* ������������ */,
  c.c_name ul_nas_mesto/* ������������ */,
  c.manicip ul_obshtina/* ������ */,
  c.district ul_oblast/* ������ */,
  t.bulstat eik,
  t.web_address web
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and nvl(public_register_incl,0) = 1)
                                 )
  join nom_cities c on (t.city_id = c.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_IOOR_RADIO_FM_ME
prompt =================================
prompt
CREATE OR REPLACE VIEW CRC.MV_IOOR_RADIO_FM_ME AS
SELECT
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  case
    when p.initial_change_no is null then p.no
    else p.no||'-'||lpad(p.initial_change_no,3,'0')
  end vh_nomer,
  p.initial_date vh_data,
  p.date_end data_prik,
  pu.name prednazn_mre/* �������������� */,
  c.c_type gr_selo/* ����/���� */,
  c.c_name nas_mesto/* ������������ */,
  c.district oblast/* ������ */,
  f.carrier_frequency nose_chestota
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and nvl(public_register_incl,0) = 1)
                                 and nvl(p.is_national,0)=0 and nvl(public_register_incl,0) = 1 )
  join nom_nomenclatures pt on (p.nomencl_type_id = pt.id and pt.prog_name = 'RTYPE_101FM')
  left outer join nom_nomenclatures pu on (p.nomencl_id_net_purpose = pu.id)
  left outer join radio_nets_fm f on (request_routines.last_perm_with_technodata(p.id,pt.prog_name) = f.perm_ioor_id)
  left outer join nom_cities c on (f.city_id = c.id)
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');

prompt
prompt Creating view MV_IOOR_RADIO_FM_NA
prompt =================================
prompt
CREATE OR REPLACE VIEW CRC.MV_IOOR_RADIO_FM_NA AS
SELECT
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  p.no vh_nomer,
  p.initial_date vh_data,
  p.date_end data_prik,
  pu.name prednaznach,
  '��������� ��������' terit_obhvat
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and nvl(public_register_incl,0) = 1)
                                 and nvl(p.is_national,0)=1 )
  join nom_nomenclatures pt on (p.nomencl_type_id = pt.id and pt.prog_name = 'RTYPE_101FM')
  left outer join nom_nomenclatures pu on (p.nomencl_id_net_purpose = pu.id)
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');

prompt
prompt Creating view MV_IOOR_SPUTNIK
prompt =============================
prompt
CREATE OR REPLACE VIEW CRC.MV_IOOR_SPUTNIK AS
SELECT
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  p.no vh_nomer,
  p.date_from vh_data,
  p.date_end data_prik,
  pu.name prednaznachenie,
  v.ctrl_station_location mestopol,
  g.t_freq_range Ches_predav,
  g.t_total_bandwidth Ches_len_predav,
  g.r_freq_range Ches_len_priem
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and nvl(public_register_incl,0) = 1)
                                 )
  join nom_nomenclatures pt on (p.nomencl_type_id = pt.id and pt.prog_name = 'SATS_BULSATS')
  left outer join nom_nomenclatures pu on (p.nomencl_id_net_purpose = pu.id)
  left outer join radio_nets_satellit v on (v.perm_ioor_id = request_routines.last_perm_with_technodata(p.id,pt.prog_name))
  left outer join radio_sat_ground_stations g on (g.sat_srv_net_id = v.id)
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');

prompt
prompt Creating view MV_IOOR_TELE_ME
prompt =============================
prompt
CREATE OR REPLACE VIEW CRC.MV_IOOR_TELE_ME AS
SELECT
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  case
    when p.initial_change_no is null then p.no
    else p.no||'-'||lpad(p.initial_change_no,3,'0')
  end vh_nomer,
  p.date_from vh_data,
  nvl(to_char(p.DATE_END,'DD.MM.YYY'), p.description) data_prik,
  pu.name prednazn_mre,
  c.c_type gr_selo,
  c.c_name nas_mesto,
  c.district oblast,
  v.carrier_frequency_at_transm nos_chestota,
  v.working_channel rab_kanal
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and nvl(public_register_incl,0) = 1 and company_id = t.company_id)
                                 and nvl(p.is_national,0)=0)
  join nom_nomenclatures pt on (p.nomencl_type_id = pt.id and pt.prog_name = 'RTYPE_101TVA')
  join nom_nomenclatures pst on (p.nomencl_status_id = pst.id and pst.prog_name = 'PSTAT_INS')
  left outer join nom_nomenclatures pu on (p.nomencl_id_net_purpose = pu.id)
  left outer join radio_nets_tv v on (v.perm_ioor_id = request_routines.last_perm_with_technodata(p.id,pt.prog_name))
  left outer join nom_cities c on (c.id = v.city_id)
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');

prompt
prompt Creating view MV_IOOR_TELE_NA
prompt =============================
prompt
CREATE OR REPLACE VIEW CRC.MV_IOOR_TELE_NA AS
SELECT
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  case
    when p.initial_change_no is null then p.no
    else p.no||'-'||lpad(p.initial_change_no,3,'0')
  end vh_nomer,
  p.initial_date vh_data,
  nvl(to_char(p.date_end,'dd.mm.yyyy'),p.description) data_prik,
  pu.name prednaznachenie,
  '��������� ��������' terit_obhvat
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and nvl(public_register_incl,0) = 1)
                                 and nvl(p.is_national,0)=1)
  join nom_nomenclatures pt on (p.nomencl_type_id = pt.id and pt.prog_name = 'RTYPE_101TVA')
  left outer join nom_nomenclatures pu on (p.nomencl_id_net_purpose = pu.id)
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');

prompt
prompt Creating view MV_IOOR_TEMP
prompt ==========================
prompt
CREATE OR REPLACE VIEW CRC.MV_IOOR_TEMP AS
SELECT distinct
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  p.no vh_nomer,
  p.date_from vh_data,
  p.date_start data_nach,
  nvl(to_char(p.DATE_END,'DD.MM.YYYY'), p.DESCRIPTION) data_prik,
  p.temp_scope_terr teritor,
  p.temp_scope_freq chestot_obhvat,
  p.temp_purpose prednaznach
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and nvl(public_register_incl,0) = 1)
                                 )
  join nom_nomenclatures pt on (p.nomencl_type_id = pt.id and pt.prog_name in ('FRS_TEMP','OLD_RTYPE_101TEMP','MRS_TEMP','SATS_TEMP','RTYPE_BUL_TEMP'))
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');

prompt
prompt Creating view MV_IOOR_TEMP_1
prompt ============================
prompt
CREATE OR REPLACE VIEW CRC.MV_IOOR_TEMP_1 AS
SELECT distinct
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  p.no vh_nomer,
  p.date_from vh_data,
  p.date_start data_nach,
  p.date_end data_prik,
  p.temp_scope_terr teritor,
  p.temp_scope_freq chestot_obhvat,
  p.temp_purpose prednaznach
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and nvl(public_register_incl,0) = 1)
                                 )
  join nom_nomenclatures pt on (p.nomencl_type_id = pt.id and pt.prog_name in ('FRS_TEMP','OLD_RTYPE_101TEMP','MRS_TEMP','SATS_TEMP','RTYPE_BUL_TEMP'))
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');

prompt
prompt Creating view MV_IOOR_TETRA
prompt ===========================
prompt
CREATE OR REPLACE VIEW CRC.MV_IOOR_TETRA AS
SELECT
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  p.no vh_nomer,
  p.initial_date vh_data,
  p.date_end data_prik,
  pu.name prednaznach,
  c.c_type gr_selo,
  c.c_name nas_mesto,
  c.district oblast,
  cast(null as varchar2(3)) ddescription,
  ch.name chestot_obhvat,
  (select count(*) from pmr_radio_net_frequencies f where f.pmr_pgng_trnk_id = e.id) broy
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and nvl(public_register_incl,0) = 1)
                                 )
  join nom_nomenclatures pt on (p.nomencl_type_id = pt.id and pt.prog_name = 'MRS_TETRA')
  left outer join nom_nomenclatures pu on (p.nomencl_id_net_purpose = pu.id)
  left outer join pmr_pgng_trnk_ttra_nets e on (e.perm_ioor_id = request_routines.last_perm_with_technodata(p.id,pt.prog_name) /*and e.public_register_incl = 1*/)
  left outer join pmr_service_territ_scopes ts on (e.id = ts.pmr_pgng_trnk_id)
  left outer join nom_cities c on (c.id = ts.city_id)
  left outer join nom_nomenclatures ch on (ch.id = e.NOMENCL_ID_FREQ_BAND)
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');

prompt
prompt Creating view MV_IOOR_TRUNK
prompt ===========================
prompt
CREATE OR REPLACE VIEW CRC.MV_IOOR_TRUNK AS
SELECT
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  p.no vh_nomer,
  p.initial_date vh_data,
  p.date_end data_prik,
  pu.name prednaznach,
  c.c_type gr_selo,
  c.c_name nas_mesto,
  c.district oblast,
  cast(null as varchar2(3)) ddescription,
  ch.name chestot_obhvat,
  (select count(*) from pmr_radio_net_frequencies f where f.pmr_pgng_trnk_id = e.id) broy
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and nvl(public_register_incl,0) = 1)
                                 )
  join nom_nomenclatures pt on (p.nomencl_type_id = pt.id and pt.prog_name = 'MRS_TRUNK')
  left outer join nom_nomenclatures pu on (p.nomencl_id_net_purpose = pu.id)
  left outer join pmr_pgng_trnk_ttra_nets e on (e.perm_ioor_id = request_routines.last_perm_with_technodata(p.id,pt.prog_name) /*and e.public_register_incl = 1*/)
  left outer join pmr_service_territ_scopes ts on (e.id = ts.pmr_pgng_trnk_id)
  left outer join nom_cities c on (c.id = ts.city_id)
  left outer join nom_nomenclatures ch on (ch.id = e.NOMENCL_ID_FREQ_BAND)
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');

prompt
prompt Creating view MV_IOOR_UEP_PROVIDERS
prompt ===================================
prompt
CREATE OR REPLACE VIEW CRC.MV_IOOR_UEP_PROVIDERS AS
SELECT
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  p.no vh_nomer,
  p.qep_provider_no,
  p.date_from vh_date,
  p.id perm_id,
  CASE c.c_type
    WHEN '������' THEN '������'
    WHEN '�����' THEN '�-�'
    else c.c_type
  end gr_selo,
  c.c_name nas_mesto,
  c.district oblast,
  t.address,
  --t.web_address,
  (select fv.char_v from uep_field_values fv
   where fv.perm_id = p.id
    and fv.field_id in (select id from uep_fields f where f.prog_name like 'TSP_SITE%')
  ) as web_address,
  pt.prog_name as uep_provider_type
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.public_register_incl,0) = 1)
  join nom_cities c on (t.city_id = c.id)
  join nom_nomenclatures pt on (p.nomencl_type_id = pt.id and pt.prog_name like 'QEP%')
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');

prompt
prompt Creating view MV_MARKET_SIGNIFICANT
prompt ===================================
prompt
CREATE OR REPLACE VIEW CRC.MV_MARKET_SIGNIFICANT AS
select id, resolution_no, resolution_date, company_name, company_type, eik, company_address, company_id, market_name,
       nom_market_id, requirements, description, user_created, date_created, user_updated, date_updated,seq_number
from
  ( select -- ���������� select
      msi.id,
      /*case when msi.resolution_link is not null then
        '<a href="'||trim(replace(replace(msi.resolution_link,chr(10),''),chr(13)))||'" target="_blank">������� � '||resolution_no||' �� '||to_char(resolution_date,'dd.mm.yyyy')||' �.</a>'
      else*/
        '������� � '||resolution_no||' �� '||to_char(resolution_date,'dd.mm.yyyy')||' �.'
      /*end*/ as resolution_no,
      resolution_date,

      coh.cname company_name,
      nn_cp.name company_type,
      coh.bulstat eik,
      coh.address||', �.���: '||coh.post_code||', '||nci.c_type||' '||nci.c_name||', ������:'||nci.manicip||', ������: '||nci.district company_address,
      msi.company_id,

      case when nn.description is not null then
        nn.name||'<br><br>'||nn.description
      else
        nn.name
      end market_name,

      nom_market_id,
      replace(replace(replace(msi.requirements,chr(10)||chr(13),'<br>'),chr(13)||chr(10),'<br>'),chr(10),'<br>') requirements,
      msi.description,

      msi.user_created,
      msi.date_created,
      msi.user_updated,
      msi.date_updated,
      msi.seq_number

    from market_significant_influence msi
    join nom_nomenclatures nn on
      msi.nom_market_id = nn.id
    join co_companies_h coh on
      msi.company_id = coh.company_id and
      /*sysdate between coh.ver_date_from and coh.ver_date_to*/
      coh.ver_date_from = ( SELECT MAX( ch1.ver_date_from)
                            FROM co_companies_h ch1
                            WHERE ch1.company_id = coh.company_id )
    join nom_nomenclatures nn_cp on
      coh.nomencl_c_type_id = nn_cp.id
    join nom_cities nci on (nci.id = coh.city_id)
);

prompt
prompt Creating view MV_NOMERA_116XYZ
prompt ==============================
prompt
create or replace view crc.mv_nomera_116xyz as
select
  r.code kod/* ��� */,
  r.service usluga/* ������ */,
  t.cname predostaven_na/* ������������ �� ����������� */,
  nvl(r.decision_no, pi.crc_resolution) decision_no/* ����� �� ������� */,
  nvl2(r.decision_no, r.decision_date, pi.crc_resolution_date) decision_date/* ���� �� ������� */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join tn_resources r on (t.company_id = r.company_id and r.pr_publication = 1 and r.req_id is null and r.req_id_denied_by is null)
  join nom_nomenclatures nc on (r.nomencl_id_res_type = nc.id and nc.code = '116xyz')
  left join co_permissions_ioor pi on (r.perm_ioor_id = pi.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_NOMERA_118XY
prompt =============================
prompt
create or replace view crc.mv_nomera_118xy as
select
  t.company_id ID/* ID */,
  t.cname ul_name/* �� */,
  n.name ul_type/* ��� */,
  r.code nomer_za_dostap /* ����� �� ������ */,
  nvl(r.decision_no, pi.crc_resolution) decision_no/* ����� �� ������� */,
  nvl2(r.decision_no, r.decision_date, pi.crc_resolution_date) decision_date/* ���� �� ������� */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join tn_resources r on (t.company_id = r.company_id and r.pr_publication = 1 and r.req_id is null and r.req_id_denied_by is null)
  join nom_nomenclatures nc on (r.nomencl_id_res_type = nc.id and nc.code = '118xy')
  left join co_permissions_ioor pi on (r.perm_ioor_id = pi.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_NOMERA_700
prompt ===========================
prompt
CREATE OR REPLACE VIEW CRC.MV_NOMERA_700 AS
SELECT
  t.company_id ID/* ID */,
  t.cname ul_name/* �� */,
  n.name ul_type/* ��� */,
  r.code kod/* ��� */,
  r.id_net net_id /* ������������� �� ������� */,
  upper(r.num_group) ab_nomera/* �������� ������ */,
  nvl(r.decision_no, pi.crc_resolution) decision_no/* ����� �� ������� */,
  nvl2(r.decision_no, r.decision_date, pi.crc_resolution_date) decision_date/* ���� �� ������� */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join tn_resources r on (t.company_id = r.company_id and r.pr_publication = 1 and r.req_id is null and r.req_id_denied_by is null)
  join nom_nomenclatures nc on (r.nomencl_id_res_type = nc.id and nc.code = '700')
  left join co_permissions_ioor pi on (r.perm_ioor_id = pi.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_NOMERA_800
prompt ===========================
prompt
CREATE OR REPLACE VIEW CRC.MV_NOMERA_800 AS
SELECT
  t.company_id ID/* ID */,
  t.cname ul_name/* �� */,
  n.name ul_type/* ��� */,
  r.code kod/* ��� */,
  r.id_net net_id /* ������������� �� ������� */,
  upper(r.num_group) ab_nomera/* �������� ������ */,
  nvl(r.decision_no, pi.crc_resolution) decision_no/* ����� �� ������� */,
  nvl2(r.decision_no, r.decision_date, pi.crc_resolution_date) decision_date/* ���� �� ������� */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join tn_resources r on (t.company_id = r.company_id and r.pr_publication = 1 and r.req_id is null and r.req_id_denied_by is null)
  join nom_nomenclatures nc on (r.nomencl_id_res_type = nc.id and nc.code = '800')
  left join co_permissions_ioor pi on (r.perm_ioor_id = pi.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_NOMERA_90
prompt ==========================
prompt
create or replace view crc.mv_nomera_90 as
select
  t.company_id ID/* �� */,
  t.cname ul_name/* ������������ �� �� �������� ��������� ����������� */,
  n.name ul_type/* ������������ */,
  r.code nomer_za_dostap/* ��� */,
  r.id_net net_id/* ������������� �� ������� */,
  nst.name tarifa_id/* ������������� �� ������ */,
  upper(r.num_group) ab_nomera/* �������� ������ */,
  nvl(r.decision_no, pi.crc_resolution) decision_no/* ����� �� ������� */,
  nvl2(r.decision_no, r.decision_date, pi.crc_resolution_date) decision_date/* ���� �� ������� */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join tn_resources r on (t.company_id = r.company_id and r.pr_publication = 1 and r.req_id is null and r.req_id_denied_by is null)
  join nom_nomenclatures nc on (r.nomencl_id_res_type = nc.id and nc.code = '90')
  left join co_permissions_ioor pi on (r.perm_ioor_id = pi.id)
  left join nom_nomenclatures nst on (r.nomencl_id_serv_type = nst.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_NOMERA_99X
prompt ===========================
prompt
create or replace view crc.mv_nomera_99x as
select
  t.company_id ID/* �� */,
  t.cname ul_name/* ������������ �� �� �������� ��������� ����������� */,
  n.name ul_type/* ������������ */,
  r.code kod/* ��� */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join tn_resources r on (t.company_id = r.company_id and r.pr_publication = 1 and r.req_id is null and r.req_id_denied_by is null)
  join nom_nomenclatures nc on (r.nomencl_id_res_type = nc.id and nc.code = '99x')
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_NOMERA_DOST_INTERNET
prompt =====================================
prompt
create or replace view crc.mv_nomera_dost_internet as
select
  t.company_id ID/* �� */,
  t.cname ul_name/* ������������ �� �� �������� ��������� ����������� */,
  n.name ul_type/* ������������ */,
  r.code nomer_za_dostap/* ��� */,
  nvl(r.decision_no, pi.crc_resolution) decision_no/* ����� �� ������� */,
  nvl2(r.decision_no, r.decision_date, pi.crc_resolution_date) decision_date/* ���� �� ������� */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join tn_resources r on (t.company_id = r.company_id and r.pr_publication = 1 and r.req_id is null and r.req_id_denied_by is null)
  join nom_nomenclatures nc on (r.nomencl_id_res_type = nc.id and nc.code = '���')
  left join co_permissions_ioor pi on (r.perm_ioor_id = pi.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_NOMERA_GEOGRAPH
prompt ================================
prompt
create or replace view crc.mv_nomera_geograph as
select
  t.company_id ID/* �� */,
  t.cname ul_name/* ������������ �� �� �������� ��������� ����������� */,
  n.name ul_type/* ������������ */,
  r.code kod/* ��� */,
  r.location nas_mesto/* �������� ����� */,
  r.num_group nom_grupa/* ������������ ����� */,
  nvl(r.decision_no, pi.crc_resolution) decision_no/* ����� �� ������� */,
  nvl2(r.decision_no, r.decision_date, pi.crc_resolution_date) decision_date/* ���� �� ������� */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join tn_resources r on (t.company_id = r.company_id and r.pr_publication = 1 and r.req_id is null and r.req_id_denied_by is null)
  join nom_nomenclatures nc on (r.nomencl_id_res_type = nc.id and nc.code = '��')
  left join co_permissions_ioor pi on (r.perm_ioor_id = pi.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_NOMERA_ISPC
prompt ============================
prompt
create or replace view crc.mv_nomera_ispc as
select
  t.company_id ID/* �� */,
  t.cname ul_name/* ������������ �� �� �������� ��������� ����������� */,
  n.name ul_type/* ������������ */,
  r.bin_dec_no ISPC /* ��� */,
  nvl(r.decision_no, pi.crc_resolution) decision_no/* ����� �� ������� */,
  nvl2(r.decision_no, r.decision_date, pi.crc_resolution_date) decision_date/* ���� �� ������� */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join tn_resources r on (t.company_id = r.company_id and r.pr_publication = 1 and r.req_id is null and r.req_id_denied_by is null)
  join nom_nomenclatures nc on (r.nomencl_id_res_type = nc.id and nc.code = 'ISPC')
  left join co_permissions_ioor pi on (r.perm_ioor_id = pi.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_NOMERA_IZBOR_OPERATOR
prompt ======================================
prompt
create or replace view crc.mv_nomera_izbor_operator as
select
  t.company_id ID/* �� */,
  t.cname ul_name/* ������������ �� �� �������� ��������� ����������� */,
  n.name ul_type/* ������������ */,
  r.code nomer_za_dostap/* ��� */,
  nvl(r.decision_no, pi.crc_resolution) decision_no/* ����� �� ������� */,
  nvl2(r.decision_no, r.decision_date, pi.crc_resolution_date) decision_date/* ���� �� ������� */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join tn_resources r on (t.company_id = r.company_id and r.pr_publication = 1 and r.req_id is null and r.req_id_denied_by is null)
  join nom_nomenclatures nc on (r.nomencl_id_res_type = nc.id and nc.code = '10xy')
  left join co_permissions_ioor pi on (r.perm_ioor_id = pi.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_NOMERA_M2M
prompt ===========================
prompt
CREATE OR REPLACE VIEW CRC.MV_NOMERA_M2M AS
SELECT
  t.company_id ID/* ID */,
  t.cname ul_name/* �� */,
  n.name ul_type/* ��� */,
  r.code kod/* ��� */,
  r.id_net net_id /* ������������� �� ������� */,
  upper(r.num_group) ab_nomera/* �������� ������ */,
  nvl(r.decision_no, pi.crc_resolution) decision_no/* ����� �� ������� */,
  nvl2(r.decision_no, r.decision_date, pi.crc_resolution_date) decision_date/* ���� �� ������� */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join tn_resources r on (t.company_id = r.company_id and r.pr_publication = 1 and r.req_id is null and r.req_id_denied_by is null)
  join nom_nomenclatures nc on (r.nomencl_id_res_type = nc.id and nc.code = 'M2M')
  left join co_permissions_ioor pi on (r.perm_ioor_id = pi.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_NOMERA_MNC
prompt ===========================
prompt
CREATE OR REPLACE VIEW CRC.MV_NOMERA_MNC AS
SELECT
  t.company_id ID/* ID */,
  t.cname ul_name/* �� */,
  n.name ul_type/* ��� */,
  r.code kod/* ��� */,
  nvl(r.decision_no, pi.crc_resolution) decision_no/* ����� �� ������� */,
  nvl2(r.decision_no, r.decision_date, pi.crc_resolution_date) decision_date/* ���� �� ������� */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join tn_resources r on (t.company_id = r.company_id and r.pr_publication = 1 and r.req_id is null and r.req_id_denied_by is null)
  join nom_nomenclatures nc on (r.nomencl_id_res_type = nc.id and nc.code = 'MNC')
  left join co_permissions_ioor pi on (r.perm_ioor_id = pi.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_NOMERA_MOBILNI_MR
prompt ==================================
prompt
create or replace view crc.mv_nomera_mobilni_mr as
select
  t.company_id ID/* �� */,
  t.cname ul_name/* ������������ �� �� �������� ��������� ����������� */,
  n.name ul_type/* ������������ */,
  r.code kod/* ��� */,
  nvl(r.decision_no, pi.crc_resolution) decision_no/* ����� �� ������� */,
  nvl2(r.decision_no, r.decision_date, pi.crc_resolution_date) decision_date/* ���� �� ������� */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join tn_resources r on (t.company_id = r.company_id and r.pr_publication = 1 and r.req_id is null and r.req_id_denied_by is null)
  join nom_nomenclatures nc on (r.nomencl_id_res_type = nc.id and nc.code = '�������')
  left join co_permissions_ioor pi on (r.perm_ioor_id = pi.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_NOMERA_NOMERA_USLUGI
prompt =====================================
prompt
create or replace view crc.mv_nomera_nomera_uslugi as
select
  r.code nomer/* ��� */,
  r.service usluga/* ������ */
from
  tn_resources r
  join nom_nomenclatures nc on (r.nomencl_id_res_type = nc.id and nc.code = '���')
where  r.pr_publication = 1 and r.req_id is null and r.req_id_denied_by is null;

prompt
prompt Creating view MV_NOMERA_NSPC
prompt ============================
prompt
create or replace view crc.mv_nomera_nspc as
select
  t.company_id ID/* �� */,
  t.cname ul_name/* ������������ �� �� �������� ��������� ����������� */,
  n.name ul_type/* ������������ */,
  r.zz||'-'||r.yy||'-'||r.xx NSPC/* ��� */,
  nvl(r.decision_no, pi.crc_resolution) decision_no/* ����� �� ������� */,
  nvl2(r.decision_no, r.decision_date, pi.crc_resolution_date) decision_date/* ���� �� ������� */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join tn_resources r on (t.company_id = r.company_id and r.pr_publication = 1 and r.req_id is null and r.req_id_denied_by is null)
  join nom_nomenclatures nc on (r.nomencl_id_res_type = nc.id and nc.code = 'NSPC')
  left join co_permissions_ioor pi on (r.perm_ioor_id = pi.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_NOMERA_POVREDI
prompt ===============================
prompt
create or replace view crc.mv_nomera_povredi as
select
  t.company_id ID/* �� */,
  t.cname ul_name/* ������������ �� �� �������� ��������� ����������� */,
  n.name ul_type/* ������������ */,
  r.code kod/* ��� */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join tn_resources r on (t.company_id = r.company_id and r.pr_publication = 1 and r.req_id is null and r.req_id_denied_by is null)
  join nom_nomenclatures nc on (r.nomencl_id_res_type = nc.id and nc.code = '��');

prompt
prompt Creating view MV_NOMERA_REG_USL
prompt ===============================
prompt
CREATE OR REPLACE VIEW CRC.MV_NOMERA_REG_USL AS
SELECT
  t.company_id ID/* ID */,
  t.cname ul_name/* �� */,
  n.name ul_type/* ��� */,
  r.code kod/* ��� */,
  r.code2 /* ����������� ������ ����� */,
  upper(r.num_group) nom_group/* ����� */,
  r.location /* �������� ����� */,
  nvl(r.decision_no, pi.crc_resolution) decision_no/* ����� �� ������� */,
  nvl2(r.decision_no, r.decision_date, pi.crc_resolution_date) decision_date/* ���� �� ������� */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join tn_resources r on (t.company_id = r.company_id and r.pr_publication = 1 and r.req_id is null and r.req_id_denied_by is null)
  join nom_nomenclatures nc on (r.nomencl_id_res_type = nc.id and nc.code = '��')
  left join co_permissions_ioor pi on (r.perm_ioor_id = pi.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_NOMERA_SN1
prompt ===========================
prompt
create or replace view crc.mv_nomera_sn1 as
select
  r.code kod/* ��� */,
  r.service usluga/* ������ */,
  t.cname predostaven_na/* ������������ �� ����������� */,
  nvl(r.decision_no, pi.crc_resolution) decision_no/* ����� �� ������� */,
  nvl2(r.decision_no, r.decision_date, pi.crc_resolution_date) decision_date/* ���� �� ������� */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join tn_resources r on (t.company_id = r.company_id and r.pr_publication = 1 and r.req_id is null and r.req_id_denied_by is null)
  join nom_nomenclatures nc on (r.nomencl_id_res_type = nc.id and nc.code = 'SN1')
  left join co_permissions_ioor pi on (r.perm_ioor_id = pi.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_POSHTI_NPU
prompt ===========================
prompt
create or replace view crc.mv_poshti_npu as
select
  t.company_id ul_id,
  case
    when t.change_no is not null then t.cert_no||'-'||lpad(t.change_no,3,'0')
    else t.cert_no
  end  vhod_nomer   /* ����� */,
  t.cert_date vhod_data/* ���� */,
  /*case n1.id
    when null then '��'
    else '��'
  end   posht_pratki\* ��/�� *\,
  case n2.id
    when null then '��'
    else '��'
  end kurier_uslugi\* ��/�� *\,
  case n3.id
    when null then '��'
    else '��'
  end priaka_post_reklama\* ��/�� *\,*/
  case when post_cert_req_routines.is_cert_serv_incl(t.id, 'NPU_MESS') = 1 then
    '��'
  else
    '��'
  end posht_pratki,
  case when post_cert_req_routines.is_cert_serv_incl(t.id, 'NPU_COUR') = 1 then
    '��'
  else
    '��'
  end kurier_uslugi,
  case when post_cert_req_routines.is_cert_serv_incl(t.id, 'NPU_PPR') = 1 then
    '��'
  else
    '��'
  end priaka_post_reklama,
  t.notes /*t.description*/ zabelejka/* ��������� */
from /*post_licences*/ post_certificates t
  /*join post_services s1 on (t.id = s1.pst_lic_id)
  join nom_nomenclatures n1 on (n1.id = s1.nomencl_id_serv_type and n1.prog_name = 'NPU_MESS')
  join post_services s2 on (t.id = s2.pst_lic_id)
  join nom_nomenclatures n2 on (n2.id = s2.nomencl_id_serv_type and n2.prog_name = 'NPU_COUR')
  join post_services s3 on (t.id = s3.pst_lic_id)
  join nom_nomenclatures n3 on (n3.id = s3.nomencl_id_serv_type and n3.prog_name = 'NPU_PPR')*/
where t.publish = 1;

prompt
prompt Creating view MV_POSHTI_NPU_UL
prompt ==============================
prompt
create or replace view crc.mv_poshti_npu_ul as
select
  t.company_id ID/* �� */,
  t.cname ul_name/* ������������ �� �� �������� ��������� ����������� */,
  n.name ul_type/* ������������ */,
  c.c_type ul_gr_selo/* ����/���� */,
  c.c_name ul_nas_mesto/* ������������ */,
  c.manicip ul_obshtina/* ������ */,
  c.district ul_oblast/* ������ */,
  t.address ul_address/* ����� - ����� */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join nom_cities c on (t.city_id = c.id)
  join co_comp_registers r on (t.company_id = r.company_id)
  join nom_nomenclatures rn on (r.nomencl_regist_id = rn.id and rn.prog_name = 'REGS_NPU')
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_POSHTI_UPU
prompt ===========================
prompt
create or replace view crc.mv_poshti_upu as
select
  t.company_id ul_id,
  case
    when t.change_no is not null then t.no||'-'||lpad(t.change_no,3,'0')
    else t.no
  end  vhod_nomer,
  t.date_from vhod_data/* ���� */,
  t.date_start nach_data/* ������� ���� �� ���������� */,
  t.date_end krai_data/* ������ ���� �� ���������� */,
  /*case n1.id*/
  case when post_licence_routines.is_post_lic_serv_incl(t.id, 'UPU_INS') = 1 then
  /*  when null then*/
    '��'
  else
    '��'
  end   posht_pratki/* ��/�� */,
  /*case n2.id
    when null then '��'
    else '��'*/
  case when post_licence_routines.is_post_lic_serv_incl(t.id, 'UPU_INS20') = 1 then
    '��'
  else
    '��'
  end posht_koleti/* ��/�� */,
  /*case n3.id
    when null then '��'
    else '��'*/
  case when post_licence_routines.is_post_lic_serv_incl(t.id, 'UPU_ADD') = 1 then
    '��'
  else
    '��'
  end dop_uslugi/* ��/�� */,

  /*case n4.id
    when null then '��'
    else '��'*/
  case when post_licence_routines.is_post_lic_serv_incl(t.id, 'UPU_MTRANS') = 1 then
    '��'
  else
    '��'
  end par_prev/* ��/�� */,
  cast(null as varchar2(3)) ter_obhvat/* ������������ ������ - ����� */,
  t.description zabelejka/* ��������� */
  /*t.**/
from post_licences t
  /*left outer join post_services s1 on (t.id = s1.pst_lic_id)
  left outer join nom_nomenclatures n1 on (n1.id = s1.nomencl_id_serv_type and n1.prog_name = 'UPU_INS')*/
  /*left outer join post_services s2 on (t.id = s2.pst_lic_id)
  left outer join nom_nomenclatures n2 on (n2.id = s2.nomencl_id_serv_type and n2.prog_name = 'UPU_INS20')
  left outer join post_services s3 on (t.id = s3.pst_lic_id)
  left outer join nom_nomenclatures n3 on (n3.id = s3.nomencl_id_serv_type and n3.prog_name = 'UPU_ADD')
  left outer join post_services s4 on (t.id = s4.pst_lic_id)
  left outer join nom_nomenclatures n4 on (n4.id = s4.nomencl_id_serv_type and n4.prog_name = 'UPU_MTRANS')*/
where t.publish = 1;

prompt
prompt Creating view MV_POSHTI_UPU_UL
prompt ==============================
prompt
create or replace view crc.mv_poshti_upu_ul as
select
  t.company_id ID/* �� */,
  t.cname ul_name/* ������������ �� �� �������� ��������� ����������� */,
  n.name ul_type/* ������������ */,
  c.c_type ul_gr_selo/* ����/���� */,
  c.c_name ul_nas_mesto/* ������������ */,
  c.manicip ul_obshtina/* ������ */,
  c.district ul_oblast/* ������ */,
  t.address ul_address/* ����� - ����� */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join nom_cities c on (t.city_id = c.id)
  join co_comp_registers r on (t.company_id = r.company_id)
  join nom_nomenclatures rn on (r.nomencl_regist_id = rn.id and rn.prog_name = 'REGS_UPU')
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_PREHV_PRAVA
prompt ============================
prompt
create or replace view crc.mv_prehv_prava as
select
  cast(null as varchar2(3)) UL_DAVA_NAME,
  cast(null as varchar2(3)) UL_DAVA_TYPE,
  cast(null as number(3)) RAZR_NOMER,
  to_date(null) DATE_FROM,
  to_date(null) DATE_TO,
  cast(null as varchar2(3)) UL_PRIOBR_NAME,
  cast(null as varchar2(3)) UL_PRIOBR_TYPE,
  cast(null as number(3)) PAZR_P_NOMER,
  to_date(null) DATE_P_FROM,
  cast(null as varchar2(3)) NOMER_DATA_RAZRESH,
  cast(null as varchar2(3)) GR_SELO,
  cast(null as varchar2(3)) NAS_MESTO,
  cast(null as varchar2(3)) OBSHTINA,
  cast(null as varchar2(3)) OBLAST,
  cast(null as number(3)) DOLNA_GR,
  cast(null as number(3)) GORNA_GR,
  cast(null as number(3)) OBSHTO,
  cast(null as varchar2(3)) POSOKA,
  to_date(null) OT,
  to_date(null) DO,
  cast(null as number(3)) SAS_RAZRESHITELNO
from dual
where 1=2;

prompt
prompt Creating view MV_RADIOLUB_FL
prompt ============================
prompt
create or replace view crc.mv_radiolub_fl as
select
  t.person_id ID/* �� */,
  t.name first_name/* ��� */,
  case t.addr_flag
    when 1 then t.address
    else null
  end   fl_address/* ����� - ����� */,
  case t.addr_flag
    when 1 then t.post_code
    else null
  end post_code/* �������� ��� */,
  case t.addr_flag
    when 1 then c.c_type
    else null
  end  gr_selo/* ����/���� */,
  case t.addr_flag
    when 1 then c.c_name
    else null
  end nas_mesto/* ������������ */,
  case t.addr_flag
    when 1 then c.manicip
    else null
  end obshtina/* ������ */,
  case t.addr_flag
    when 1 then c.district
    else null
  end oblast/* ������ */,
  li.lic_no raresh_no/* ����� */,
  li.lic_date raresh_data/* ���� */,
  li.rl_class rl_class/* ��������������� ���� */,
  m.mark opo_znak/* ������������� ���� - ��� */,
  case when rn.name = '��������' then
    null
  else
    rn.name
  end opo_vid/* ��� */,
  case rn.name
    when '��������' then '��'
    else '��'
  end    vremenen/* ��/�� */,
  m.date_from date_from/* �� */,
  m.date_to date_to/* �� */
from rl_person_h t
  left outer join nom_cities c on (t.city_id = c.id)
  left outer join ( select  x.person_id,
                            x.lic_no,
                            x.lic_date,
                            x.rl_class
                    from (select  rrl.person_id,
                                  rrl.lic_no,
                                  rrl.lic_date,
                                  rrl.rl_class,
                                  dense_rank() over (partition by rrl.person_id order by  case upper(trim(rrl.rl_class))
                                                                                            when '1' then 1
                                                                                            when 'A' then 2
                                                                                            when 'B' then 3
                                                                                            when 'C' then 4
                                                                                            when '2' then 5
                                                                                            when 'D' then 6
                                                                                          end) top_one
                          from rl_radioam_licences rrl
                          where nvl(rrl.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy')
                         ) x
                  where x.top_one = 1) li on
    li.person_id = t.person_id
  left outer join rl_radioam_identif_marks m on (m.person_id = t.person_id)

  left outer join table(app_routines.get_nomencl_list('RL_IDENTIF_MARKS_STATUS')) mark_status on m.nomencl_id_mark_status = mark_status.id

  left outer join nom_nomenclatures rn on (m.nomencl_id_mark_type = rn.id)

WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY') and
      t.public_reg = 1 and

      1 = case when m.id is not null then /*����� Mihaela Trichkova <mtrichkova@crc.bg> �� 21.6.2013 11:32*/
            case when mark_status.prog_name = 'RL_IDMARK_STATUS_VALID' then
              1
            else
              0
            end
          else
            1
          end;

prompt
prompt Creating view MV_RADIOLUB_UL
prompt ============================
prompt
CREATE OR REPLACE VIEW CRC.MV_RADIOLUB_UL AS
SELECT
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  t.address||', �.�.'||t.post_code||' '||c.c_type||c.c_name||', ������: '||c.manicip||', ������:'||c.district sedalishte,
  r.mark opo_znak,
  case when rn.name = '��������' then
    null
  else
    rn.name
  end opo_vid,
  case rn.name
    when '��������' then '��'
    else '��'
  end    vremenen/* ��/�� */,
  r.date_from date_from,
  r.date_to date_to,
  r.responsible_person otg_first_name
from co_companies_h t
  join ru_radioamateur_data r on (r.company_id = t.company_id)
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join nom_cities c on (t.city_id = c.id)
  join nom_nomenclatures rn on (r.nomencl_id_mark_type = rn.id)
  join nom_nomenclatures sn on (r.nomencl_id_mark_status = sn.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY') and
      sn.prog_name = 'RL_IDMARK_STATUS_VALID' /*����� Mihaela Trichkova <mtrichkova@crc.bg> �� 21.6.2013 11:32*/;

prompt
prompt Creating view MV_RENTED_RESOURCES
prompt =================================
prompt
create or replace view crc.mv_rented_resources as
select  geb_name,
  geb_type,
  geb_perm_ioor,
  geb_perm_date,
  geb_perm_date_end,
  res_name,
  res_type,
  res_perm_ioor,
  res_perm_date,
  right_terit,
  right_freq,
  right_numb_blocks,
  right_spctrum,
  right_date_start,
  right_date_end,
  descr
from rented_resources;

prompt
prompt Creating view MV_TRANSFERED_RIGHTS
prompt ==================================
prompt
create or replace view crc.mv_transfered_rights as
select
/*'��������' geb_name,
'���' geb_type,
'351' geb_perm_ioor,
to_date('29.5.2008','DD.MM.YYYY') geb_perm_date,
to_date('6.12.2015','DD.MM.YYYY') geb_perm_date_end,
'���� �������' res_name,
'���' res_type,
'1727' res_perm_ioor,
to_date('7.7.2011','DD.MM.YYYY') res_perm_date,
to_date('9.7.2012','DD.MM.YYYY') res_perm_date_end,
'���.' right_terit_grad_selo,
'��������� ��������' right_terit,
'3,5 GHz' right_freq,
'2' right_numb_blocks,
'21' right_spctrum,
to_date('9.7.2011','DD.MM.YYYY') right_date_start,
to_date('9.7.2012','DD.MM.YYYY') right_date_end
from dual
*/
res_name,
res_type,
res_perm_ioor,
res_perm_date,
res_perm_date_end,
geb_name,
geb_type,
geb_perm_ioor,
geb_perm_date,
geb_perm_date_end,
info
from MV_TRANSFERED_RIGHTS_N;

prompt
prompt Creating view MV_UEP_FIELD_VALUES
prompt =================================
prompt
CREATE OR REPLACE VIEW CRC.MV_UEP_FIELD_VALUES AS
SELECT
  t.company_id,
  f.f_number,
  f.f_name,
  f.f_lang,
  f.f_mandatory,
  f.f_is_group,
  f.f_seq_no,
  --f.f_type,
  f.para_id,
  to_char(substr(f.f_descr,1,4000)) as f_descr,
  --f.prog_name,
  --f.f_format,
  --fv.number_v,
  --fv.date_v,
  case when nvl(f.prog_name,'NONE') not like '%X509%'
  then
  '<div style="width:400px;">'||replace(replace(replace(
        fv.char_v,chr(13)),'  ','&nbsp;&nbsp;')
         ,chr(10)
        ,'<br>')
    ||'</div>'
  else  '<span style="font-size:10px;">'
      ||uep_routines.long_text_breaks(
          replace(replace(fv.char_v,chr(13)),chr(10))
          ,64,'<br />')
      ||'</span>'
  end as char_v,
  --fv.clob_v,
  --fv.field_id,
  --fv.req_id,
  fv.serv_id,
  fv.serv_perm_id va_serv_perm_id,
  fv.perm_id va_perm_id,
  p.id perm_id,
  para.prog_name para_prog_name
from  uep_fields f
  join uep_paragraphs para on (f.para_id = para.id
                              and para.prog_name in ('TSP_ROOT_CERT','TSP_OTHER'))
  join co_companies_h t on (1=1)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.public_register_incl,0) = 1)
  join nom_nomenclatures pt on (p.nomencl_type_id = pt.id and pt.prog_name like 'QEP%')
  left outer join (select val.*,
           (select perm_id from uep_services where id = val.serv_id) as serv_perm_id
      from uep_field_values val
      ) fv on (f.id = fv.field_id
           and ((p.id = fv.serv_perm_id and para.prog_name = 'TSP_ROOT_CERT')
             or (p.id = fv.perm_id and para.prog_name = 'TSP_OTHER')))
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');

prompt
prompt Creating view MV_UEP_FIELD_VALUES_CRC
prompt =====================================
prompt
CREATE OR REPLACE VIEW CRC.MV_UEP_FIELD_VALUES_CRC AS
SELECT
  f.f_number,
  f.f_name,
  f.f_lang,
  f.f_mandatory,
  f.f_is_group,
  f.f_seq_no,
  --f.f_type,
  f.para_id,
  to_char(substr(f.f_descr,1,4000)) as f_descr,
  --f.prog_name,
  --f.f_format,
  --fv.number_v,
  --fv.date_v,
  case when nvl(f.prog_name,'NONE') not like '%X509%'
  then
  '<div style="width:400px;">'||replace(replace(replace(
        fv.char_v,chr(13)),'  ','&nbsp;&nbsp;')
         ,chr(10)
        ,'<br>')
    ||'</div>'
  else  '<span style="font-size:10px;">'
      ||uep_routines.long_text_breaks(
          replace(replace(fv.char_v,chr(13)),chr(10))
          ,64,'<br />')
      ||'</span>'
  end as char_v,
  --fv.clob_v,
  --fv.field_id,
  --fv.req_id,
  --fv.serv_id,
  fv.perm_id,
  fv.req_id,
  para.prog_name para_prog_name
from uep_field_values fv
  right join uep_fields f on (fv.field_id = f.id)
  join uep_paragraphs para on (f.para_id = para.id
                              and para.prog_name in ('CRC_ROOT_CERT','CRC_OPER_CERT'))
where  fv.perm_id||fv.req_id is null;

prompt
prompt Creating view MV_UVEDOMLENIA_KS
prompt ===============================
prompt
create or replace view crc.mv_uvedomlenia_ks as
select
t.company_id ul_id/* �� */,
(select stragg(' '||ndt.name)from  ste_notif_dev_types sndt
                join nom_nomenclatures ndt
                  on (sndt.nomencl_id_dev_type = ndt.id)
               where sndt.ste_notif_id = t.id) vid_aparat,
t.location mestopol,
s.name || nvl2(t.other_event, ' (' || t.other_event || ')', null) sabitie,
t.cov_date_from date_from,
t.cov_date_to date_to
from ste_notifications t
  join ste_notif_dev_types d on (t.id = d.ste_notif_id)
  join nom_nomenclatures s on (t.nomencl_id_ste = s.id)
where trunc(sysdate) between t.cov_date_from and t.cov_date_to;

prompt
prompt Creating view MV_UVEDOMLENIA_KS_UL
prompt ==================================
prompt
create or replace view crc.mv_uvedomlenia_ks_ul as
select
t.company_id ID/* �� */,
t.cname ul_name/* ������������ �� �� �������� ��������� ����������� */,
n.name ul_type/* ������������ */,
t.address ul_address/* ����� - ����� */,
t.post_code ul_pk/* �������� ��� */,
c.c_type ul_gr_selo/* ����/���� */,
c.c_name ul_nas_mesto/* ������������ */,
c.manicip ul_obshtina/* ������ */,
c.district ul_oblast/* ������ */
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join nom_cities c on (t.city_id = c.id)
  join co_comp_registers r on (t.company_id = r.company_id)
  join nom_nomenclatures rn on (r.nomencl_regist_id = rn.id and rn.prog_name = 'REGS_NSHORT')
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_UVEDOMLENIA_LK
prompt ===============================
prompt
create or replace view crc.mv_uvedomlenia_lk as
select
t.company_id ul_id /* �� */,
t.first_name lk_name /* ��� */,
t.second_name lk_prezime/* ������� */,
t.last_name lk_familia/* ������� */,
t.tel_code tel_kod/* ���. ��� */,
t.tel tel/* ������� �� ������� */,
t.email e_mail/* E-mail */,
t.address lk_address/* ����� - ����� */,
t.post_code lk_pk/* �������� ��� */,
c.c_type lk_gr_selo/* ����/���� */,
c.c_name lk_nas_mesto/* ������������ */,
c.manicip lk_obshtina/* ������ */,
c.district lk_oblast/* ������ */
from co_contact_persons t join nom_cities c on (t.city_id = c.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY')
 and t.public_reg_incl = 1;

prompt
prompt Creating view MV_UVEDOMLENIA_UL
prompt ===============================
prompt
create or replace view crc.mv_uvedomlenia_ul as
select
/*t.id*/t.company_id id,
t.cname ul_name,
n.name ul_type,
t.address ul_address,
t.post_code ul_pk,
CASE c.c_type
    WHEN '������' THEN '������'
    WHEN '�����' THEN '�-�'
    else c.c_type
end ul_gr_selo,
c.c_name ul_nas_mesto,
c.manicip ul_obshtina,
c.district ul_oblast,
t.bulstat eik,
t.web_address web
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join nom_cities c on (t.city_id = c.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY')
and (exists (select 1 from pec_notif_nets ne where ne.company_id = t.company_id and ne.nomencl_id_status in (48,49))
    or
    exists (select 1 from pec_notif_services se where se.company_id = t.company_id and se.nomencl_id_status in (48,49)))
order by ul_name;

prompt
prompt Creating view MV_UVE_UL_MREJI
prompt =============================
prompt
CREATE OR REPLACE VIEW CRC.MV_UVE_UL_MREJI AS
SELECT
t.company_id ul_id,
t.cname ul_name,
n.name ul_type,
s.inscription_date date_nadlejno,
s.descr_pr usl_mre_descr,
CASE c.c_type
    WHEN '������' THEN '������'
    WHEN '�����' THEN '�-�'
    else c.c_type
end gr_selo,
c.c_name nas_mesto,
c.manicip obshtina,
c.district oblast,
nvl(a.stard_date,s.start_date) predpolag_data
FROM co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join pec_notif_nets s on (t.company_id = s.company_id)
  join nom_nomenclatures stat on (s.nomencl_id_status = stat.id and stat.prog_name in ('NSSTAT_INS','NSSTAT_SINS'))
  join pec_notif_net_area a on (s.id = a.pec_nt_net_id and (a.end_date is null or a.end_date > trunc(sysdate)))
  join nom_cities c on (a.city_id = c.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view MV_UVE_UL_USLUGI
prompt ==============================
prompt
CREATE OR REPLACE VIEW CRC.MV_UVE_UL_USLUGI AS
SELECT
t.company_id ul_id,
t.cname ul_name,
n.name ul_type,
s.inscription_date date_nadlejno,
case
  when instr(s.descr_pr,'2.2')<>0 then substr(s.descr_pr,1,instr(s.descr_pr,'-')-1)
  else s.descr_pr
end usl_mre_descr,
CASE c.c_type
    WHEN '������' THEN '������'
    WHEN '�����' THEN '�-�'
    else c.c_type
end gr_selo,
c.c_name nas_mesto,
c.manicip obshtina,
c.district oblast,
nvl(a.stard_date,s.start_date) predpolag_data
FROM co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join pec_notif_services s on (t.company_id = s.company_id)
  join nom_nomenclatures stat on (s.nomencl_id_status = stat.id and stat.prog_name in ('NSSTAT_INS','NSSTAT_SINS'))
  join pec_notif_serv_area a on (s.id = a.pec_nt_srv__id and (a.end_date is null or a.end_date > trunc(sysdate)))
  join nom_cities c on (a.city_id = c.id)
WHERE nvl(t.ver_date_to,to_date('01.01.2500','DD.MM.YYYY')) = to_date('01.01.2500','DD.MM.YYYY');

prompt
prompt Creating view V_CO_COMPANY_ACTUAL_INFO
prompt ======================================
prompt
create or replace view crc.v_co_company_actual_info as
select  cc.id cc_id
      , cc.uri
      , cc_h."ID",cc_h."CNAME",cc_h."BULSTAT",cc_h."FIRM_DEL_NO",cc_h."FIRM_DEL_YEAR"
      , cc_h."FIRM_DEL_CORT",cc_h."ADDRESS", cc_h."VER_DATE_FROM", cc_h."VER_DATE_TO", cc_h."USER_CREATED"
      , cc_h."DATE_CREATED", cc_h."USER_UPDATED", cc_h."DATE_UPDATED", cc_h."COMPANY_ID", cc_h."NOMENCL_C_TYPE_ID"
      , cc_h."CITY_ID",cc_h."IBAN",cc_h."BIC",cc_h."WEB_ADDRESS"
      , cc_h.trade_mark, cc_h.country
      , nn.name type_name
      , nn.description type_name_en
      , nc.c_type city_type
      , nc.c_name city_name
      , nc.post_code
      , nc.manicip
      , nc.district
      , nr.r_name
from    co_companies cc
      , co_companies_h cc_h
      , nom_nomenclatures nn
      , nom_cities nc
      , nom_rayons nr
where   cc_h.company_id = cc.id
and     cc_h.nomencl_c_type_id = nn.id
and     cc_h.city_id = nc.id(+)
and     cc_h.nomencl_rayons_id = nr.id(+)
and     cc_h.ver_date_from = (select max(ch.ver_date_from)
                              from   co_companies_h ch
                              where  ch.company_id = cc.id)
and     nvl(cc_h.is_person,0) = 0;

prompt
prompt Creating view V_ALL_FREQUENCES
prompt ==============================
prompt
CREATE OR REPLACE VIEW CRC.V_ALL_FREQUENCES AS
SELECT 'SWAM' net_type, f.CNAME,f.type_name,rm.bandwidth FREQUENCE,rm.address_text,c.c_type,c.c_name,c.district
FROM radio_nets_dmr_swam rm
--JOIN radio_drm_swam_bandw_list b ON (rm.id = b.rndmrswam_id)
JOIN co_permissions_ioor p ON (p.id = rm.perm_ioor_id
                               AND p.nomencl_status_id =
                               (SELECT ID FROM nom_nomenclatures n WHERE n.prog_name = 'PSTAT_INS'))
JOIN v_co_company_actual_info f ON (p.company_id = f.cc_id)
LEFT OUTER JOIN nom_cities c ON (rm.city_id = c.id)
UNION ALL
SELECT 'FM',f.CNAME,f.type_name,to_number(translate(rm.carrier_frequency,'1,MHZmhzGg','1.')),rm.address_text,c.c_type,c.c_name,c.district
FROM radio_nets_fm rm
JOIN co_permissions_ioor p ON (p.id = rm.perm_ioor_id
                               AND p.nomencl_status_id =
                               (SELECT ID FROM nom_nomenclatures n WHERE n.prog_name = 'PSTAT_INS'))
JOIN v_co_company_actual_info f ON (p.company_id = f.cc_id)
LEFT OUTER JOIN nom_cities c ON (rm.city_id = c.id)
UNION ALL
SELECT 'MWAM',f.CNAME,f.type_name,to_number(translate(rm.carrier_frequency,'1,MHZmhzGg','1.')),to_char(null) address_text,to_char(null) c_type,to_char(null) c_name,to_char(null) district
FROM radio_nets_lwam_mwam rm
JOIN co_permissions_ioor p ON (p.id = rm.perm_ioor_id
                               AND p.nomencl_status_id =
                               (SELECT ID FROM nom_nomenclatures n WHERE n.prog_name = 'PSTAT_INS'))
JOIN v_co_company_actual_info f ON (p.company_id = f.cc_id)
UNION ALL
SELECT 'PtoP',f.CNAME,f.type_name,rm.a_transmission_carrier_freq,rm.a_rr_station_address,to_char(null) c_type,to_char(null) c_name,to_char(null) district
FROM radio_nets_ptop rm
JOIN co_permissions_ioor p ON (p.id = rm.perm_ioor_id
                               AND p.nomencl_status_id =
                               (SELECT ID FROM nom_nomenclatures n WHERE n.prog_name = 'PSTAT_INS'))
JOIN v_co_company_actual_info f ON (p.company_id = f.cc_id)

UNION ALL
SELECT 'PtoP',f.CNAME,f.type_name,rm.b_transmission_carrier_freq,rm.b_rr_station_address,to_char(null) c_type,to_char(null) c_name,to_char(null) district
FROM radio_nets_ptop rm
JOIN co_permissions_ioor p ON (p.id = rm.perm_ioor_id
                               AND p.nomencl_status_id =
                               (SELECT ID FROM nom_nomenclatures n WHERE n.prog_name = 'PSTAT_INS'))
JOIN v_co_company_actual_info f ON (p.company_id = f.cc_id)

UNION ALL
SELECT 'PtoMP',f.CNAME,f.type_name,rm.spectrum1_lower_limit,c.c_name,to_char(null) c_type,to_char(null) c_name,to_char(null) district
FROM radio_nets_ptomp rm
LEFT OUTER JOIN nom_cities c ON (rm.city_id = c.id)
JOIN co_permissions_ioor p ON (p.id = rm.perm_ioor_id
                               AND p.nomencl_status_id =
                               (SELECT ID FROM nom_nomenclatures n WHERE n.prog_name = 'PSTAT_INS'))
JOIN v_co_company_actual_info f ON (p.company_id = f.cc_id)

UNION ALL
SELECT 'PtoMP',f.CNAME,f.type_name,rm.spectrum1_upper_limit,c.c_name,to_char(null) c_type,to_char(null) c_name,to_char(null) district
FROM radio_nets_ptomp rm
LEFT OUTER JOIN nom_cities c ON (rm.city_id = c.id)
JOIN co_permissions_ioor p ON (p.id = rm.perm_ioor_id
                               AND p.nomencl_status_id =
                               (SELECT ID FROM nom_nomenclatures n WHERE n.prog_name = 'PSTAT_INS'))
JOIN v_co_company_actual_info f ON (p.company_id = f.cc_id)

UNION ALL
SELECT 'TV',f.CNAME,f.type_name,to_number(rm.carrier_frequency_at_transm),rm.address_text,c.c_type,c.c_name,c.district
FROM radio_nets_tv rm
JOIN co_permissions_ioor p ON (p.id = rm.perm_ioor_id
                               AND p.nomencl_status_id =
                               (SELECT ID FROM nom_nomenclatures n WHERE n.prog_name = 'PSTAT_INS'))
JOIN v_co_company_actual_info f ON (p.company_id = f.cc_id)
LEFT OUTER JOIN nom_cities c ON (rm.city_id = c.id)
/*UNION ALL
SELECT 'SAT',f.CNAME,f.type_name,to_number(rm.t_freq_range),to_char(NULL),c.c_type,c.c_name,c.district
FROM radio_sat_ground_stations rm
join radio_nets_satellit rst on (rst.id = rm.sat_srv_net_id)
JOIN co_permissions_ioor p ON (p.id = rst.perm_ioor_id
                               AND p.nomencl_status_id =
                               (SELECT ID FROM nom_nomenclatures n WHERE n.prog_name = 'PSTAT_INS'))
JOIN v_co_company_actual_info f ON (p.company_id = f.cc_id)
LEFT OUTER JOIN nom_cities c ON (rm.city_id = c.id)

*/UNION ALL
SELECT 'RVD',f.CNAME,f.type_name,to_number(rm.freq_band),rm.location ,to_char(null) c_type,to_char(null) c_name,to_char(null) district
FROM radio_services_rvd rm
JOIN co_permissions_ioor p ON (p.id = rm.perm_ioor_id
                               AND p.nomencl_status_id =
                               (SELECT ID FROM nom_nomenclatures n WHERE n.prog_name = 'PSTAT_INS'))
JOIN v_co_company_actual_info f ON (p.company_id = f.cc_id)

UNION ALL
SELECT 'GSM',f.CNAME,f.type_name,rm.lower_limit,'',c.c_type,c.c_name,c.district
FROM radio_spectrum_gsm_umts rm
JOIN co_permissions_ioor p ON (p.id = rm.perm_ioor_id
                               AND p.nomencl_status_id =
                               (SELECT ID FROM nom_nomenclatures n WHERE n.prog_name = 'PSTAT_INS'))
JOIN v_co_company_actual_info f ON (p.company_id = f.cc_id)
LEFT OUTER JOIN nom_cities c ON (rm.city_id = c.id)

UNION ALL
SELECT 'GSM',f.CNAME,f.type_name,rm.top_limit,'',c.c_type,c.c_name,c.district
FROM radio_spectrum_gsm_umts rm
JOIN co_permissions_ioor p ON (p.id = rm.perm_ioor_id
                               AND p.nomencl_status_id =
                               (SELECT ID FROM nom_nomenclatures n WHERE n.prog_name = 'PSTAT_INS'))
JOIN v_co_company_actual_info f ON (p.company_id = f.cc_id)
LEFT OUTER JOIN nom_cities c ON (rm.city_id = c.id)

UNION ALL
SELECT 'NMT',f.CNAME,f.type_name,rm.lower_limit,'',c.c_type,c.c_name,c.district
FROM radio_spectrums_nmt rm
JOIN co_permissions_ioor p ON (p.id = rm.perm_ioor_id
                               AND p.nomencl_status_id =
                               (SELECT ID FROM nom_nomenclatures n WHERE n.prog_name = 'PSTAT_INS'))
JOIN v_co_company_actual_info f ON (p.company_id = f.cc_id)
LEFT OUTER JOIN nom_cities c ON (rm.city_id = c.id);

prompt
prompt Creating view V_CO_PERMISSIONS_IOOR_NOPROJ
prompt ==========================================
prompt
create or replace view crc.v_co_permissions_ioor_noproj as
select
t."ID",
t."NO",
t."CHANGE_NO",
t."DATE_FROM",
t."CRC_RESOLUTION",
t."CRC_RESOLUTION_DATE",
t."DATE_START",
t."DATE_END",
t."DESCRIPTION",
t."YEARS",
t."CRC_ABORTION_NO_DATE",
t."ABORTION_DATE",
t."RECEIVED",
t."REQ_ID",
t."COMPANY_ID",
t."PERM_IOOR_ID",
t."NOMENCL_TYPE_ID",
t."NOMENCL_STATUS_ID",
t."APPL2_SINGLE_TARIF",
t."APPL2_SINGLE_TARIF_VAL",
t."APPL2_YEAR_TARIF",
t."APPL2_YEAR_TARIF_VAL",
t."NOMENCL_ID_NET_PURPOSE",
t."YEARS_TXT",
t."TAX_FREE",
t."LICENCE_NO",
t."LICENCE_DATE",
t."INITIAL_DATE",
t."PUBLIC_REGISTER_INCL",
t."ABORT_REQ_ID",
t."TEMPORARY",
t."LICENCE_NO_CHNG",
t."LICENCE_DATE_CHNG",
t."LICENCE_NO_CEM",
t."LICENCE_DATE_CEM",
t."PERM_NO_CEM",
t."PERM_DATE_CEM",
t."FILE_NAME",
t."MIME_TYPE",
t."DESCR",
t."PUBLISH",
t."GEOST_COMMITMENTS",
t."GEOST_SYSTEM_CONSTRUCTION_DATE",
t."CRC_ABORTION_DATE_TO",
t."TREP",
t."APPL2_YEAR_TARIF_1",
t."APPL2_YEAR_TARIF_2",
t."APPL2_YEAR_TARIF_VAL_1",
t."APPL2_YEAR_TARIF_VAL_2",
t."NOMENCL_REASON_ID",
t."IS_NATIONAL",
t."PROGRAMS",
t."PERIOD_EXTENSION",
t."APPL2_REQUEST",
t."PAYMENT_FLAG",
t."AKT_NO_DATE",
t."INITIAL_CHANGE_NO",
t."LETTER_NO",
t."LETTER_DATE",
t."NOMENCL_PERM_TYPE_ID",
t."APPL2_YEAR_TARIF_1_0",
t."APPL2_YEAR_TARIF_1_1",
t."APPL2_YEAR_TARIF_1_2",
t."APPL2_YEAR_TARIF_1_3",
t."APPL2_YEAR_TARIF_1_4",
t."APPL2_YEAR_TARIF_1_5",
t."APPL2_YEAR_TARIF_1_6",
t."APPL2_YEAR_TARIF_1_7",
t."APPL2_YEAR_TARIF_1_8",
t."APPL2_YEAR_TARIF_1_9",
t."APPL2_YEAR_TARIF_VAL_1_0",
t."APPL2_YEAR_TARIF_VAL_1_1",
t."APPL2_YEAR_TARIF_VAL_1_2",
t."APPL2_YEAR_TARIF_VAL_1_3",
t."APPL2_YEAR_TARIF_VAL_1_4",
t."APPL2_YEAR_TARIF_VAL_1_5",
t."APPL2_YEAR_TARIF_VAL_1_6",
t."APPL2_YEAR_TARIF_VAL_1_7",
t."APPL2_YEAR_TARIF_VAL_1_8",
t."APPL2_YEAR_TARIF_VAL_1_9",
t."QEP_PROVIDER_NO",
t."TEMP_SCOPE_TERR",
t."TEMP_SCOPE_FREQ",
t."TEMP_PURPOSE"
from CRC.CO_PERMISSIONS_IOOR t
where t.nomencl_status_id not in (select id from NOM_NOMENCLATURES where prog_name = 'PROJECT');

prompt
prompt Creating view V_CO_PERSON_ACTUAL_INFO
prompt =====================================
prompt
create or replace view crc.v_co_person_actual_info as
select  cc.id cc_id
      , cc.uri
      , cc_h."ID",cc_h."CNAME",cc_h."BULSTAT",cc_h."FIRM_DEL_NO",cc_h."FIRM_DEL_YEAR"
      , cc_h."FIRM_DEL_CORT",cc_h."ADDRESS", cc_h."VER_DATE_FROM", cc_h."VER_DATE_TO", cc_h."USER_CREATED"
      , cc_h."DATE_CREATED", cc_h."USER_UPDATED", cc_h."DATE_UPDATED", cc_h."COMPANY_ID", cc_h."NOMENCL_C_TYPE_ID"
      , cc_h."CITY_ID",cc_h."IBAN",cc_h."BIC",cc_h."WEB_ADDRESS"
      , nn.name type_name
      , nc.c_type city_type
      , nc.c_name city_name
      , nc.post_code
      , nc.manicip
      , nc.district
from    co_companies cc
      , co_companies_h cc_h
      , nom_nomenclatures nn
      , nom_cities nc
where   cc_h.company_id = cc.id
and     cc_h.nomencl_c_type_id = nn.id
and     cc_h.city_id = nc.id(+)
and     cc_h.ver_date_from = (select max(ch.ver_date_from)
                              from   co_companies_h ch
                              where  ch.company_id = cc.id)
and     nvl(cc_h.is_person,0) = 1;

prompt
prompt Creating view V_REQS_WITHOUT_VHOD_NO
prompt ====================================
prompt
create or replace view crc.v_reqs_without_vhod_no as
select 'CO_REQUESTS' as table_name,
        t.id,
        t.eventisid,
        ( select h.eventisid
          from CO_REQUESTS h
          where h.req_id_prev is null
          start with h.id = t.id
          connect by h.id = prior h.req_id_prev) as root_id
from CO_REQUESTS t
where eventisid is not null and
      (t.vhod_no is null
      or -- ���� � �� ��������� �� ����������, ����� �� ���� ������ ����� �� �����������
       t.vhod_no is not null
       and t.req_id_prev is not null
       and not exists (select 1 from mail_log m where m.co_requests_id = t.id)
      )

union

select 'PEC_CERTIFICATE_REQUESTS' as table_name,
          t.id,
          t.eventisid,
          NULL as root_id
from PEC_CERTIFICATE_REQUESTS t
where eventisid is not null and
      t.vhod_no is null

union

select 'PEC_NOTIFICATIONS' as table_name,
        t.id,
        t.eventisid,
        ( select h.eventisid
          from PEC_NOTIFICATIONS h
          where h.pec_notif_id_prev is null
          start with h.id = t.id
          connect by h.id = prior h.pec_notif_id_prev ) as root_id
from PEC_NOTIFICATIONS t
where eventisid is not null and
      (t.no is null
      or -- ���� � �� ��������� �� ����������, ����� �� ���� ������ ����� �� �����������
       t.no is not null
       and t.pec_notif_id_prev is not null
       and not exists (select 1 from mail_log m where m.pec_notifications_id = t.id)
      )

union

select 'POST_CERTIFICATE_REQUESTS' as table_name,
        t.id,
        t.eventisid,
        NULL  as root_id
from POST_CERTIFICATE_REQUESTS t
where eventisid is not null and
      t.vhod_no is null

union

select 'POST_NOTIFICATIONS' as table_name,
        t.id,
        t.eventisid,
        ( select h.eventisid
          from POST_NOTIFICATIONS h
          where h.post_notif_id  is null
          start with h.id = t.id
          connect by h.id = prior h.post_notif_id ) as root_id
from POST_NOTIFICATIONS t
where eventisid is not null and
      (t.no is null
      or -- ���� � �� ��������� �� ����������, ����� �� ���� ������ ����� �� �����������
       t.no is not null
       and t.post_notif_id is not null
       and not exists (select 1 from mail_log m where m.post_notifications_id = t.id)
      )

union

select 'POST_REQUESTS' as table_name,
        t.id,
        t.eventisid,
        ( select h.eventisid
          from POST_REQUESTS h
          where h.post_req_id_prev is null
          start with h.id = t.id
          connect by h.id = prior h.post_req_id_prev) as root_id
from POST_REQUESTS t
where eventisid is not null and
      (t.vhod_no is null
      or -- ���� � �� ��������� �� ����������, ����� �� ���� ������ ����� �� �����������
       t.vhod_no is not null
       and t.post_req_id_prev is not null
       and not exists (select 1 from mail_log m where m.post_requests_id = t.id)
      )

union

select 'RL_REQ_RADIOAMATIORS' as table_name,
        t.id,
        t.eventisid,
        ( select h.eventisid
          from RL_REQ_RADIOAMATIORS h
          where h.req_id_prev is null
          start with h.id = t.id
          connect by h.id = prior h.req_id_prev) as root_id
from RL_REQ_RADIOAMATIORS t
where eventisid is not null and
      t.vhod_no is null

union

select 'RU_RADIOAMATEUR_REQUESTS' as table_name,
        t.id,
        t.eventisid,
        ( select h.eventisid
          from RU_RADIOAMATEUR_REQUESTS h
          where h.req_id_prev is null
          start with h.id = t.id
          connect by h.id = prior h.req_id_prev) as root_id
from RU_RADIOAMATEUR_REQUESTS t
where eventisid is not null and
      t.vhod_no is null

union

select 'STE_NOTIFICATIONS' as table_name,
        t.id,
        t.eventisid,
        NULL as root_id
from STE_NOTIFICATIONS t
where eventisid is not null and
      t.no is null;

prompt
prompt Creating view V_REQUEST_STATUS_BAR
prompt ==================================
prompt
create or replace view crc.v_request_status_bar as
select
/* ������ ��������� �� css-������� �� ���������� �� ����� */
/* ��������� */
case
when n.prog_name in ('ENTER')
then '<table width="100%" cellspacing="1" cellpadding="0" border="0"><tr>'
   ||'<td class="yellow">���������</td>'
   ||'<td class="gray">�����������</td>'
   ||'<td class="gray">�������</td>'
   ||'</tr></table>'
/* ��������� �� */
when n.prog_name in ('INPROCESS')
then '<table width="100%" cellspacing="1" cellpadding="0" border="0"><tr>'
   ||'<td class="green">���������</td>'
   ||'<td class="yellow">�����������</td>'
   ||'<td class="gray">�������</td>'
   ||'</tr></table>'
/* �������� */
when n.prog_name in ('RSTAT_REF')
then '<table width="100%" cellspacing="1" cellpadding="0" border="0"><tr>'
   ||'<td class="green">���������</td>'
   ||'<td class="green">�����������</td>'
   ||'<td class="red">��������</td>'
   ||'</tr></table>'
/* ������� �� ��������� */
when n.prog_name in ('RSTAT_RET')
then '<table width="100%" cellspacing="1" cellpadding="0" border="0"><tr>'
   ||'<td class="green">���������</td>'
   ||'<td class="green">�����������</td>'
   ||'<td class="blue">������� �� ���������</td>'
   ||'</tr></table>'
/* �������� ���������� */
when n.prog_name in ('RSTAT_PERM')
then '<table width="100%" cellspacing="1" cellpadding="0" border="0"><tr>'
   ||'<td class="green">���������</td>'
   ||'<td class="green">�����������</td>'
   ||'<td class="green">�������� ����������</td>'
   ||'</tr></table>'
/* ������� */
when n.prog_name in ('RSTAT_PUBLISHED')
then '<table width="100%" cellspacing="1" cellpadding="0" border="0"><tr>'
   ||'<td class="green">���������</td>'
   ||'<td class="green">�����������</td>'
   ||'<td class="green">�������</td>'
   ||'</tr></table>'
end stat_bar
,n.prog_name
,n.seq_number
,n.id
from nom_nomenclatures n
where n.nom_types_id = (select id from nom_nomenclature_types where prog_name='REQUEST_STATUS');

prompt
prompt Creating view V_UEP_FIELDS_NOLOB
prompt ================================
prompt
create or replace view crc.v_uep_fields_nolob as
select
t."ID",
t."F_NUMBER",
t."F_NAME",
t."F_LANG",
t."F_MANDATORY",
t."F_IS_GROUP",
t."F_SEQ_NO",
t."F_TYPE",
t."PARA_ID",
to_char(dbms_lob.substr(t."F_DESCR",4000,1)) as f_descr,
t."PROG_NAME",
t."F_FORMAT"
from CRC.UEP_FIELDS t;


spool off
