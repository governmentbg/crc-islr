create or replace view rl_person_h as
select
t.id, t.egn, t.byrthday, t.address, t.addr_flag, t.tel_code, t.tel, t.fax, t.email,
t.ver_date_from, t.ver_date_to, t.user_created, t.date_created, t.user_updated, t.date_updated,
t.person_id, t.address_lat, t.city_id, t.post_code, t.name, t.name_lat
,xapp_routines.filesize('rl_person_h','PHOTO',t.id) as "PHOTO", public_reg,
CITY_ID_CONT,
POST_CODE_CONT,
ADDRESS_CONT,
TEL_CODE_CONT,
TEL_CONT,
FAX_CONT,
EMAIL_CONT,
ADDRESS_LAT_CONT

from rl_person_h@CRCDB.INT.CRC.BG t;