CREATE OR REPLACE VIEW MV_IOOR_DVB_T AS
SELECT distinct
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  case
    when p.initial_change_no is null then p.no
    else p.no||'-'||lpad(p.initial_change_no,3,'0')
  end vh_nomer,
  p.initial_date vh_data,
  p.date_end data_prik,
  pu.name prednaznach/* �������������� */,
  c.c_type gr_selo/* ����/���� */,
  c.c_name nas_mesto/* ������������ */,
  c.district oblast/* ������ */,
  /*f.address_text*/cast(null as varchar2(3)) address_txt,
  /*f.channel_lower_limit*/cast(null as varchar2(3)) dolna_gra,
  /*f.channel_upper_limit*/cast(null as varchar2(3)) gorna_gra,
  f.transmission_channel_number rab_kanal
  , st.name status
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and nvl(public_register_incl,0) = 1)
                                 )
  join nom_nomenclatures pt on (p.nomencl_type_id = pt.id and pt.prog_name = /*'RTYPE_101FM'*/'RTYPE_101DVB')
  join nom_nomenclatures st on p.nomencl_status_id = st.id and st.prog_name <> 'PROJECT'
  left outer join nom_nomenclatures pu on (p.nomencl_id_net_purpose = pu.id)
  left outer join radio_nets_dvbt_tdab f on (request_routines.last_perm_with_technodata(p.id,pt.prog_name) = f.perm_ioor_id)
  left outer join nom_cities c on (f.city_id = c.id)
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');
