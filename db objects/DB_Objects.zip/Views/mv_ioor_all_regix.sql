create or replace view mv_ioor_all_regix as
select 'DRM - ���� �����' net_type,id, ul_name, ul_type, vh_nomer, vh_data, to_date(null) data_nach,  data_prik, prednaznach, gr_selo, null nas_mesto, null oblast, status
,null dolna_gra, null gorna_gra, null rab_kanal, null chestot_obhvat, null ddescription, null broy, null  broi_blokove, null obshto_spektar, null network_type, null chest_lenta, null nose_chestota,null terit_obhvat
,null mestopol,null ches_predav,null ches_len_predav,null ches_len_priem
from mv_ioor_drm
union
-- mv_ioor_dvb_t
select 'DVB-T',id, ul_name, ul_type, vh_nomer, vh_data, to_date(null) data_nach,  data_prik, prednaznach, gr_selo, nas_mesto, oblast,status,
dolna_gra,  gorna_gra, rab_kanal, null chestot_obhvat, null ddescription, null broy, null  broi_blokove, null obshto_spektar, null network_type, null chest_lenta, null nose_chestota,null terit_obhvat
,null mestopol,null ches_predav,null ches_len_predav,null ches_len_priem
from mv_ioor_dvb_t
union
-- mv_ioor_gsm_umts
select network_type/*'GSM UMTS PAMR'*/,id, ul_name, ul_type, vh_nomer, vh_data, to_date(null) data_nach,  data_prik, prednaznach, gr_selo, nas_mesto, oblast,status,
null,null,null, chestot_obhvat , null ddescription, null broy, null  broi_blokove, null obshto_spektar, null network_type, null chest_lenta, null nose_chestota,null terit_obhvat
,null mestopol,null ches_predav,null ches_len_predav,null ches_len_priem
from mv_ioor_gsm_umts
union
-- mv_ioor_industry
select '�� �������������� �����',id, ul_name, ul_type, vh_nomer, vh_data, data_nach, to_date(data_prik,'dd.mm.yyyy') data_prik, '�� ���������� �����' prednaznach, null gr_selo,null nas_mesto,teritor,status,
null,null,null, chestot_obhvat, null ddescription, null broy, null  broi_blokove, null obshto_spektar, null network_type, null chest_lenta, null nose_chestota,null terit_obhvat
,null mestopol,null ches_predav,null ches_len_predav,null ches_len_priem
from mv_ioor_industry
union
--mv_ioor_nomera
--select '������',null id,ul_name, ul_type, null vh_nomer, null vh_data, null data_nach, null data_prik,vid_razreshenie,  null gr_selo,null nas_mesto,null teritor,
--'�������: '||resh_nomer ||'/'|| resh_data from mv_ioor_nomera
--union
-- mv_ioor_paging
select '���������� ���������',id, ul_name, ul_type, vh_nomer, vh_data, null data_nach,  data_prik, prednaznach, gr_selo, nas_mesto, oblast,status,
null,null,null, chestot_obhvat, ddescription, broy, null  broi_blokove, null obshto_spektar, null network_type, null chest_lenta, null nose_chestota,null terit_obhvat
,null mestopol,null ches_predav,null ches_len_predav,null ches_len_priem
from mv_ioor_paging
union
--  mv_ioor_pmr
select 'PMR', id, ul_name, ul_type, vh_nomer, vh_data, null data_nach,  data_prik, prednaznach, gr_selo, nas_mesto, oblast,status,
null,null,null, chestot_obhvat, ddescription, broy, null  broi_blokove, null obshto_spektar, null network_type, null chest_lenta, null nose_chestota,null terit_obhvat
,null mestopol,null ches_predav,null ches_len_predav,null ches_len_priem
from mv_ioor_pmr
union
-- mv_ioor_p_to_mp
select 'FWA � ������ 26 GHz', id, ul_name, ul_type, vh_nomer, vh_data,null data_nach,  data_prik, prednaznach, gr_selo, nas_mesto, null oblast,status,
null,null,null, chest_obhvat , null ddescription, null broy,  broi_blokove, obshto_spektar, network_type, null chest_lenta, null nose_chestota,null terit_obhvat
,null mestopol,null ches_predav,null ches_len_predav,null ches_len_priem
from mv_ioor_p_to_mp
  where network_type like '%FWA%'
union
-- mv_ioor_p_to_mp
select 'BWA � ������ 3.6 GHz', id, ul_name, ul_type, vh_nomer, vh_data,null data_nach,  data_prik, prednaznach, gr_selo, nas_mesto, null oblast,status,
null,null,null, chest_obhvat , null ddescription, null broy,  broi_blokove, obshto_spektar, network_type, null chest_lenta, null nose_chestota,null terit_obhvat
,null mestopol,null ches_predav,null ches_len_predav,null ches_len_priem
from mv_ioor_p_to_mp
 where network_type like '%BWA%'
union
-- mv_ioor_p_to_p
select '����� ��� �����', id, ul_name, ul_type, vh_nomer, vh_data, null data_nach,  data_prik, prednaznach, null gr_selo, null nas_mesto, null oblast,status,
null,null,null, null chestot_obhvat , null ddescription, null broy,null  broi_blokove,null obshto_spektar, null network_type, chest_lenta, null nose_chestota,null terit_obhvat
,null mestopol,null ches_predav,null ches_len_predav,null ches_len_priem
from mv_ioor_p_to_p
union
-- mv_ioor_radio_fm_me
select 'FM - ������', id, ul_name, ul_type, vh_nomer, vh_data, null data_nach,  data_prik, prednazn_mre, gr_selo, nas_mesto, oblast,status,
null dolna_gra, null gorna_gra, null rab_kanal, null chestot_obhvat, null ddescription, null broy, null  broi_blokove, null obshto_spektar, null network_type, null chest_lenta, nose_chestota,null terit_obhvat
,null mestopol,null ches_predav,null ches_len_predav,null ches_len_priem
from mv_ioor_radio_fm_me
union
-- mv_ioor_radio_fm_na
select 'FM - ����������', id, ul_name, ul_type, vh_nomer, vh_data, null data_nach,  data_prik, prednaznach, null gr_selo, null nas_mesto, null oblast,status,
null dolna_gra, null gorna_gra, null rab_kanal, null chestot_obhvat, null ddescription, null broy, null  broi_blokove, null obshto_spektar, null network_type, null chest_lenta, null nose_chestota,terit_obhvat
,null mestopol,null ches_predav,null ches_len_predav,null ches_len_priem
from mv_ioor_radio_fm_na
union
--
select '����������',id, ul_name, ul_type, vh_nomer, vh_data,  null data_nach,  data_prik, prednaznachenie, null gr_selo, null nas_mesto, null oblast,status,
null dolna_gra, null gorna_gra, null rab_kanal, null chestot_obhvat, null ddescription, null broy, null  broi_blokove, null obshto_spektar, null network_type, null chest_lenta, null nose_chestota,null terit_obhvat
,mestopol, ches_predav, ches_len_predav, ches_len_priem
from mv_ioor_sputnik
union
-- mv_ioor_tetra
select 'TETRA', id, ul_name, ul_type, vh_nomer, vh_data, null data_nach,  data_prik, prednaznach, gr_selo, nas_mesto, oblast,status,
null dolna_gra, null gorna_gra, null rab_kanal, chestot_obhvat, null ddescription, broy, null  broi_blokove, null obshto_spektar, null network_type, null chest_lenta, null nose_chestota,null terit_obhvat
,null mestopol,null ches_predav,null ches_len_predav,null ches_len_priem
from mv_ioor_tetra
union
-- mv_ioor_p_to_mp
select 'BWA � ������ 3.6 GHz', id, ul_name, ul_type, vh_nomer, vh_data,null data_nach,  data_prik, prednaznach, gr_selo, nas_mesto, null oblast,status,
null dolna_gra, null gorna_gra, null rab_kanal,  chest_obhvat, null ddescription, null broy,  broi_blokove, obshto_spektar, network_type, null chest_lenta, null nose_chestota,null terit_obhvat
,null mestopol,null ches_predav,null ches_len_predav,null ches_len_priem
from mv_ioor_p_to_mp
  where network_type like '%BWA%'
union
-- mv_ioor_trunk
select 'TRUNK', id, ul_name, ul_type, vh_nomer, vh_data, null data_nach, data_prik, prednaznach, gr_selo, nas_mesto, oblast,status,
null dolna_gra, null gorna_gra, null rab_kanal,  chestot_obhvat, null ddescription, broy, null  broi_blokove, null obshto_spektar, null network_type, null chest_lenta, null nose_chestota, null terit_obhvat
,null mestopol,null ches_predav,null ches_len_predav,null ches_len_priem
from mv_ioor_trunk
union
-- MV_IOOR_TEMP
select  '��������',  id, ul_name, ul_type, vh_nomer, vh_data, data_nach, to_date(data_prik,'dd.mm.yyyy') data_prik, prednaznach, null gr_selo, teritor nas_mesto, null oblast,status,
 null dolna_gra, null gorna_gra, null rab_kanal,  chestot_obhvat, null ddescription, null broy, null  broi_blokove, null obshto_spektar, null network_type, null chest_lenta, null nose_chestota, null terit_obhvat
,null mestopol,null ches_predav,null ches_len_predav,null ches_len_priem
from MV_IOOR_TEMP t
;
