CREATE OR REPLACE VIEW MV_IOOR_DRM AS
SELECT distinct
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  case
    when p.initial_change_no is null then p.no
    else p.no||'-'||lpad(p.initial_change_no,3,'0')
  end vh_nomer,
  p.initial_date vh_data,
  p.date_end data_prik,
  pu.name prednaznach/* �������������� */,
  '����� ����������� �� ��������� ��������' AS  gr_selo
  , st.name status
  , pt.name network_name
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and nvl(public_register_incl,0) = 1)
                                 )
  join nom_nomenclatures pt on (p.nomencl_type_id = pt.id and pt.prog_name = /*'RTYPE_101FM'*/'RTYPE_101DRM')
  join nom_nomenclatures st on p.nomencl_status_id = st.id and st.prog_name <> 'PROJECT'
  left outer join nom_nomenclatures pu on (p.nomencl_id_net_purpose = pu.id)
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');
