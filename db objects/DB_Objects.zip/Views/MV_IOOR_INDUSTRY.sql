CREATE OR REPLACE VIEW MV_IOOR_INDUSTRY AS
SELECT distinct
  t.company_id ID,
  t.cname ul_name,
  n.name ul_type,
  p.no vh_nomer,
  p.date_from vh_data,
  p.date_start data_nach,
  nvl(to_char(p.DATE_END,'DD.MM.YYYY'), p.DESCRIPTION) data_prik,
  p.temp_scope_terr teritor,
  p.temp_scope_freq chestot_obhvat,
  p.temp_purpose prednaznach
  , st.name status
from co_companies_h t
  join nom_nomenclatures n on (t.nomencl_c_type_id = n.id)
  join co_permissions_ioor p on (t.company_id = p.company_id
                                 and nvl(p.change_no,0) = (select max(nvl(change_no,0)) from co_permissions_ioor
                                                           where no = p.no and nvl(public_register_incl,0) = 1)
                                 )
  join nom_nomenclatures pt on (p.nomencl_type_id = pt.id and pt.prog_name in ('FRS_INDUSTRY'))
  join nom_nomenclatures st on p.nomencl_status_id = st.id and st.prog_name <> 'PROJECT'
where nvl(t.ver_date_to,to_date('01.01.2500','dd.mm.yyyy')) = to_date('01.01.2500','dd.mm.yyyy');
