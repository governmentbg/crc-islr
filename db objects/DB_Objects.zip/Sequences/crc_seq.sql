-----------------------------------------------------
-- Export file for user CRC                        --
-- Created by GBardarski on 18.5.2010 �., 12:25:27 --
-----------------------------------------------------

spool crc_seq.log

prompt
prompt Creating sequence ACT_SEQ
prompt =========================
prompt
create sequence ACT_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence ADD_INFO_SEQ
prompt ==============================
prompt
create sequence ADD_INFO_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 61
increment by 1
cache 20;

prompt
prompt Creating sequence B_SEQ
prompt =======================
prompt
create sequence B_SEQ
minvalue 1
maxvalue 9999999999999999999999999
start with 3
increment by 1
cache 20;

prompt
prompt Creating sequence CERTIFICAT_SEQ
prompt ================================
prompt
create sequence CERTIFICAT_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence CHANNEL_LI_SEQ
prompt ================================
prompt
create sequence CHANNEL_LI_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence CHANNEL_SEQ
prompt =============================
prompt
create sequence CHANNEL_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence CITY_SEQ
prompt ==========================
prompt
create sequence CITY_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 5
increment by 1
cache 20;

prompt
prompt Creating sequence CNT_PERS_SEQ
prompt ==============================
prompt
create sequence CNT_PERS_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 41
increment by 1
cache 20;

prompt
prompt Creating sequence CNT_PRS_RN_SEQ
prompt ================================
prompt
create sequence CNT_PRS_RN_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 663
increment by 1
cache 20;

prompt
prompt Creating sequence COLABORATE_SEQ
prompt ================================
prompt
create sequence COLABORATE_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence COMPANY_SEQ
prompt =============================
prompt
create sequence COMPANY_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 41
increment by 1
cache 20;

prompt
prompt Creating sequence COMP_H_RN_SEQ
prompt ===============================
prompt
create sequence COMP_H_RN_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 701
increment by 1
cache 20;

prompt
prompt Creating sequence COMP_H_SEQ
prompt ============================
prompt
create sequence COMP_H_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 63
increment by 1
cache 20;

prompt
prompt Creating sequence COM_REG_SEQ
prompt =============================
prompt
create sequence COM_REG_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 41
increment by 1
cache 20;

prompt
prompt Creating sequence CRTF_ZEDEP_SEQ
prompt ================================
prompt
create sequence CRTF_ZEDEP_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence CTY_TEL_CO_SEQ
prompt ================================
prompt
create sequence CTY_TEL_CO_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence DRMSBWLIST_SEQ
prompt ================================
prompt
create sequence DRMSBWLIST_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence EXAM_SEQ
prompt ==========================
prompt
create sequence EXAM_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence EXM_EQU_SEQ
prompt =============================
prompt
create sequence EXM_EQU_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence GSM_UMTS_SEQ
prompt ==============================
prompt
create sequence GSM_UMTS_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence GSM_UMTS_SEQ_1
prompt ================================
prompt
create sequence GSM_UMTS_SEQ_1
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence LOGGER_APX_ITEMS_SEQ
prompt ======================================
prompt
create sequence LOGGER_APX_ITEMS_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence LOGGER_LOGS_SEQ
prompt =================================
prompt
create sequence LOGGER_LOGS_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 21
increment by 1
cache 20;

prompt
prompt Creating sequence LOGIN_LOG_SEQ
prompt ===============================
prompt
create sequence LOGIN_LOG_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence MEA_REP_SEQ
prompt =============================
prompt
create sequence MEA_REP_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence MONITORING_SEQ_1
prompt ==================================
prompt
create sequence MONITORING_SEQ_1
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence NET_SERV_SEQ
prompt ==============================
prompt
create sequence NET_SERV_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 42
increment by 1
cache 20;

prompt
prompt Creating sequence NMT_SPCTR_SEQ
prompt ===============================
prompt
create sequence NMT_SPCTR_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence NOMENCL_SEQ
prompt =============================
prompt
create sequence NOMENCL_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 362
increment by 1
cache 20;

prompt
prompt Creating sequence NOM_REQ_T_ATT_D_SEQ
prompt =====================================
prompt
create sequence NOM_REQ_T_ATT_D_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 20
increment by 1
cache 20;

prompt
prompt Creating sequence NOM_TYPES_SEQ
prompt ===============================
prompt
create sequence NOM_TYPES_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 282
increment by 1
cache 20;

prompt
prompt Creating sequence PBUL00000_SEQ
prompt ===============================
prompt
create sequence PBUL00000_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence PBUL020_SEQ
prompt =============================
prompt
create sequence PBUL020_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence PEC_CERT_SEQ
prompt ==============================
prompt
create sequence PEC_CERT_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 21
increment by 1
cache 20;

prompt
prompt Creating sequence PEC_CRT_FI_SEQ
prompt ================================
prompt
create sequence PEC_CRT_FI_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence PEC_NET_AR_SEQ
prompt ================================
prompt
create sequence PEC_NET_AR_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 201
increment by 1
cache 20;

prompt
prompt Creating sequence PEC_NN_ADD_SEQ
prompt ================================
prompt
create sequence PEC_NN_ADD_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 261
increment by 1
cache 20;

prompt
prompt Creating sequence PEC_NOTIF_SEQ
prompt ===============================
prompt
create sequence PEC_NOTIF_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 301
increment by 1
cache 20;

prompt
prompt Creating sequence PEC_NS_ADD_SEQ
prompt ================================
prompt
create sequence PEC_NS_ADD_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence PEC_NSNAI_SEQ
prompt ===============================
prompt
create sequence PEC_NSNAI_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence PEC_NTF__1_SEQ
prompt ================================
prompt
create sequence PEC_NTF__1_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence PEC_NTF__1_SEQ_1
prompt ==================================
prompt
create sequence PEC_NTF__1_SEQ_1
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence PEC_NTF_FI_SEQ
prompt ================================
prompt
create sequence PEC_NTF_FI_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 261
increment by 1
cache 20;

prompt
prompt Creating sequence PEC_NT_NET_SEQ
prompt ================================
prompt
create sequence PEC_NT_NET_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 281
increment by 1
cache 20;

prompt
prompt Creating sequence PEC_NT_SRV_SEQ
prompt ================================
prompt
create sequence PEC_NT_SRV_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 181
increment by 1
cache 20;

prompt
prompt Creating sequence PEC_SRV_AR_SEQ
prompt ================================
prompt
create sequence PEC_SRV_AR_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 121
increment by 1
cache 20;

prompt
prompt Creating sequence PEC_SRV_NE_SEQ
prompt ================================
prompt
create sequence PEC_SRV_NE_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 101
increment by 1
cache 20;

prompt
prompt Creating sequence PERM_IOOR_SEQ
prompt ===============================
prompt
create sequence PERM_IOOR_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 101
increment by 1
cache 20;

prompt
prompt Creating sequence PERSON_H_SEQ
prompt ==============================
prompt
create sequence PERSON_H_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence PERSON_SEQ
prompt ============================
prompt
create sequence PERSON_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence PGNG_TRNK_SEQ
prompt ===============================
prompt
create sequence PGNG_TRNK_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence PMR_COLABORATE_USE_SEQ
prompt ========================================
prompt
create sequence PMR_COLABORATE_USE_SEQ
minvalue 1
maxvalue 9999999999999999999999999
start with 61
increment by 1
cache 20;

prompt
prompt Creating sequence PMR_PGNG_TRNK_TTRA_NETS_SEQ
prompt =============================================
prompt
create sequence PMR_PGNG_TRNK_TTRA_NETS_SEQ
minvalue 1
maxvalue 9999999999999999999999999
start with 201
increment by 1
cache 20;

prompt
prompt Creating sequence PMR_RADIO_NET_FREQUENCIES_SEQ
prompt ===============================================
prompt
create sequence PMR_RADIO_NET_FREQUENCIES_SEQ
minvalue 1
maxvalue 9999999999999999999999999
start with 101
increment by 1
cache 20;

prompt
prompt Creating sequence PMR_RADIO_STATIONS_SEQ
prompt ========================================
prompt
create sequence PMR_RADIO_STATIONS_SEQ
minvalue 1
maxvalue 9999999999999999999999999
start with 121
increment by 1
cache 20;

prompt
prompt Creating sequence PMR_SERVICE_TER_SCOPES_SEQ
prompt ============================================
prompt
create sequence PMR_SERVICE_TER_SCOPES_SEQ
minvalue 1
maxvalue 9999999999999999999999999
start with 161
increment by 1
cache 20;

prompt
prompt Creating sequence POS_PARAM_SEQ
prompt ===============================
prompt
create sequence POS_PARAM_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence POST_CERTI_SEQ
prompt ================================
prompt
create sequence POST_CERTI_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 381
increment by 1
cache 20;

prompt
prompt Creating sequence POST_CERT_REQ_SEQ
prompt ===================================
prompt
create sequence POST_CERT_REQ_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 41
increment by 1
cache 20;

prompt
prompt Creating sequence POST_NOTIF_SEQ
prompt ================================
prompt
create sequence POST_NOTIF_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 241
increment by 1
cache 20;

prompt
prompt Creating sequence POST_PERM_SEQ
prompt ===============================
prompt
create sequence POST_PERM_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence POST_RQ_SEQ
prompt =============================
prompt
create sequence POST_RQ_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 41
increment by 1
cache 20;

prompt
prompt Creating sequence PRINT_DOC_SEQ
prompt ===============================
prompt
create sequence PRINT_DOC_SEQ
minvalue 1
maxvalue 99999999999999999
start with 21
increment by 1
cache 20;

prompt
prompt Creating sequence PST_BEARER_SEQ
prompt ================================
prompt
create sequence PST_BEARER_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 201
increment by 1
cache 20;

prompt
prompt Creating sequence PST_LIC_SEQ
prompt =============================
prompt
create sequence PST_LIC_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence PST_SRV_SEQ
prompt =============================
prompt
create sequence PST_SRV_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 361
increment by 1
cache 20;

prompt
prompt Creating sequence RAD_DAT_SEQ
prompt =============================
prompt
create sequence RAD_DAT_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence RAD_D_REP_SEQ
prompt ===============================
prompt
create sequence RAD_D_REP_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence RAD_ID_MAR_SEQ
prompt ================================
prompt
create sequence RAD_ID_MAR_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence RADIONETFM_SEQ
prompt ================================
prompt
create sequence RADIONETFM_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence RADIONETTV_SEQ
prompt ================================
prompt
create sequence RADIONETTV_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence RADIO_RVD_SEQ
prompt ===============================
prompt
create sequence RADIO_RVD_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence RADIO_ST_SEQ
prompt ==============================
prompt
create sequence RADIO_ST_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence RAD_LIC_SEQ
prompt =============================
prompt
create sequence RAD_LIC_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence RADNETPTMP_SEQ
prompt ================================
prompt
create sequence RADNETPTMP_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence RADNETPTOP_SEQ
prompt ================================
prompt
create sequence RADNETPTOP_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence RAD_REP_SEQ
prompt =============================
prompt
create sequence RAD_REP_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence RAD_REQ_RP_SEQ
prompt ================================
prompt
create sequence RAD_REQ_RP_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence RAM_REQU_SEQ
prompt ==============================
prompt
create sequence RAM_REQU_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence RDAMT_UL_SEQ
prompt ==============================
prompt
create sequence RDAMT_UL_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence REPORT_BLOB_SEQ
prompt =================================
prompt
create sequence REPORT_BLOB_SEQ
minvalue 1
maxvalue 9999999999999999999999999
start with 2878
increment by 1
cache 20;

prompt
prompt Creating sequence REPRES_RN_SEQ
prompt ===============================
prompt
create sequence REPRES_RN_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 761
increment by 1
cache 20;

prompt
prompt Creating sequence REPRES_SEQ
prompt ============================
prompt
create sequence REPRES_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 81
increment by 1
cache 20;

prompt
prompt Creating sequence REQ_FILE_1_SEQ
prompt ================================
prompt
create sequence REQ_FILE_1_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence REQ_FILE_SEQ
prompt ==============================
prompt
create sequence REQ_FILE_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 201
increment by 1
cache 20;

prompt
prompt Creating sequence REQ_SEQ
prompt =========================
prompt
create sequence REQ_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 221
increment by 1
cache 20;

prompt
prompt Creating sequence RES_ZEDEP_SEQ
prompt ===============================
prompt
create sequence RES_ZEDEP_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence RL_PERSON_H_SEQ
prompt =================================
prompt
create sequence RL_PERSON_H_SEQ
minvalue 1
maxvalue 9999999999999999999999999
start with 81
increment by 1
cache 20;

prompt
prompt Creating sequence RL_PERSONS_SEQ
prompt ================================
prompt
create sequence RL_PERSONS_SEQ
minvalue 1
maxvalue 9999999999999999999999999
start with 81
increment by 1
cache 20;

prompt
prompt Creating sequence RL_RADIOAMATEUR_DATA_SEQ
prompt ==========================================
prompt
create sequence RL_RADIOAMATEUR_DATA_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 21
increment by 1
cache 20;

prompt
prompt Creating sequence RL_RADIOAM_IDENTIF_MARKS_SEQ
prompt ==============================================
prompt
create sequence RL_RADIOAM_IDENTIF_MARKS_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 21
increment by 1
cache 20;

prompt
prompt Creating sequence RL_RADIOAM_LICENCES_SEQ
prompt =========================================
prompt
create sequence RL_RADIOAM_LICENCES_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 21
increment by 1
cache 20;

prompt
prompt Creating sequence RL_RADIOAM_REPORTS_SEQ
prompt ========================================
prompt
create sequence RL_RADIOAM_REPORTS_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 21
increment by 1
cache 20;

prompt
prompt Creating sequence RL_RADIOAM_REQUEST_REPORTS_SEQ
prompt ================================================
prompt
create sequence RL_RADIOAM_REQUEST_REPORTS_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 41
increment by 1
cache 20;

prompt
prompt Creating sequence RL_REQ_ATT_FILES_SEQ
prompt ======================================
prompt
create sequence RL_REQ_ATT_FILES_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 21
increment by 1
cache 20;

prompt
prompt Creating sequence RL_REQ_RADIOAMATIORS_SEQ
prompt ==========================================
prompt
create sequence RL_REQ_RADIOAMATIORS_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 41
increment by 1
cache 20;

prompt
prompt Creating sequence RL_RQ_RA_SEQ
prompt ==============================
prompt
create sequence RL_RQ_RA_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence RNDMRSWAM_SEQ
prompt ===============================
prompt
create sequence RNDMRSWAM_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence RNDVBTDAB_SEQ
prompt ===============================
prompt
create sequence RNDVBTDAB_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence RN_FREQ_SEQ
prompt =============================
prompt
create sequence RN_FREQ_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence RNLWAMMWAM_SEQ
prompt ================================
prompt
create sequence RNLWAMMWAM_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence RU_RADIOAMATEUR_DATA_SEQ
prompt ==========================================
prompt
create sequence RU_RADIOAMATEUR_DATA_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 21
increment by 1
cache 20;

prompt
prompt Creating sequence RU_RADIOAMATEUR_REQUESTS_SEQ
prompt ==============================================
prompt
create sequence RU_RADIOAMATEUR_REQUESTS_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 21
increment by 1
cache 20;

prompt
prompt Creating sequence RU_REQ_ATT_FILES_SEQ
prompt ======================================
prompt
create sequence RU_REQ_ATT_FILES_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 21
increment by 1
cache 20;

prompt
prompt Creating sequence RVD_EQUIP_SEQ
prompt ===============================
prompt
create sequence RVD_EQUIP_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence RVD_WRK_FR_SEQ
prompt ================================
prompt
create sequence RVD_WRK_FR_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence S_APP_USR_SEQ
prompt ===============================
prompt
create sequence S_APP_USR_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1281
increment by 1
cache 20
order;

prompt
prompt Creating sequence SAT_SRV_NE_SEQ
prompt ================================
prompt
create sequence SAT_SRV_NE_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence S_AUD_REC_SEQ
prompt ===============================
prompt
create sequence S_AUD_REC_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 42841
increment by 1
cache 20
order;

prompt
prompt Creating sequence SEC_PR_HLP_SEQ
prompt ================================
prompt
create sequence SEC_PR_HLP_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 601
increment by 1
cache 20;

prompt
prompt Creating sequence SERIAL_NUM_SEQ
prompt ================================
prompt
create sequence SERIAL_NUM_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 7
increment by 1
cache 20;

prompt
prompt Creating sequence S_HELP_SEQ
prompt ============================
prompt
create sequence S_HELP_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 161
increment by 1
cache 20;

prompt
prompt Creating sequence S_ORG_RESP_SEQ
prompt ================================
prompt
create sequence S_ORG_RESP_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20
order;

prompt
prompt Creating sequence S_R_COMP_P_SEQ
prompt ================================
prompt
create sequence S_R_COMP_P_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 601
increment by 1
cache 20
order;

prompt
prompt Creating sequence S_R_COMP_T_SEQ
prompt ================================
prompt
create sequence S_R_COMP_T_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 121
increment by 1
cache 20
order;

prompt
prompt Creating sequence S_RESTR_L_SEQ
prompt ===============================
prompt
create sequence S_RESTR_L_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20
order;

prompt
prompt Creating sequence S_RESTR_RL_SEQ
prompt ================================
prompt
create sequence S_RESTR_RL_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 161
increment by 1
cache 20
order;

prompt
prompt Creating sequence S_R_RL_PAR_SEQ
prompt ================================
prompt
create sequence S_R_RL_PAR_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 101
increment by 1
cache 20
order;

prompt
prompt Creating sequence S_R_RL_P_V_SEQ
prompt ================================
prompt
create sequence S_R_RL_P_V_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 61
increment by 1
cache 20
order;

prompt
prompt Creating sequence S_RST_COMP_SEQ
prompt ================================
prompt
create sequence S_RST_COMP_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 541
increment by 1
cache 20
order;

prompt
prompt Creating sequence S_SEC_PROF_SEQ
prompt ================================
prompt
create sequence S_SEC_PROF_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 261
increment by 1
cache 20
order;

prompt
prompt Creating sequence S_SEC_PR_R_SEQ
prompt ================================
prompt
create sequence S_SEC_PR_R_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 121
increment by 1
cache 20
order;

prompt
prompt Creating sequence SSN_GR_STA_SEQ
prompt ================================
prompt
create sequence SSN_GR_STA_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence SSN_GSR_CH_SEQ
prompt ================================
prompt
create sequence SSN_GSR_CH_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence SSN_GST_CH_SEQ
prompt ================================
prompt
create sequence SSN_GST_CH_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence STE_NOTIF_SEQ
prompt ===============================
prompt
create sequence STE_NOTIF_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence STE_NTF_BN_SEQ
prompt ================================
prompt
create sequence STE_NTF_BN_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence S_US_PRO_SEQ
prompt ==============================
prompt
create sequence S_US_PRO_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 581
increment by 1
cache 20
order;

prompt
prompt Creating sequence TAR_ONE_TA_SEQ
prompt ================================
prompt
create sequence TAR_ONE_TA_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence TAR_RED_R_SEQ
prompt ===============================
prompt
create sequence TAR_RED_R_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence TAR_RL_PAR_SEQ
prompt ================================
prompt
create sequence TAR_RL_PAR_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence TAR_TAX_YE_SEQ
prompt ================================
prompt
create sequence TAR_TAX_YE_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence TAR_TAX_ZO_SEQ
prompt ================================
prompt
create sequence TAR_TAX_ZO_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence TERM_FILE_SEQ
prompt ===============================
prompt
create sequence TERM_FILE_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence TERMIN_SEQ
prompt ============================
prompt
create sequence TERMIN_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence TERR_SCOPE_SEQ
prompt ================================
prompt
create sequence TERR_SCOPE_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence TN_RESOUR_SEQ
prompt ===============================
prompt
create sequence TN_RESOUR_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence TR_FRQ_RA_SEQ
prompt ===============================
prompt
create sequence TR_FRQ_RA_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence TRN_RIGHTS_SEQ
prompt ================================
prompt
create sequence TRN_RIGHTS_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence TRNS_LST_SEQ
prompt ==============================
prompt
create sequence TRNS_LST_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence TR_PRM_IOR_SEQ
prompt ================================
prompt
create sequence TR_PRM_IOR_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence TR_TARIF_SEQ
prompt ==============================
prompt
create sequence TR_TARIF_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence TR_ZON_POP_SEQ
prompt ================================
prompt
create sequence TR_ZON_POP_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence USER_COMP_SEQ
prompt ===============================
prompt
create sequence USER_COMP_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence ZON_TER_SEQ
prompt =============================
prompt
create sequence ZON_TER_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;


spool off
