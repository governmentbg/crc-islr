-- Create sequence 
create sequence APEX_NAVIGATION_TREE_SEQ
minvalue 1
maxvalue 9999999999999999999999999
start with 141
increment by 1
cache 20;