package validateCertificateImpl;

import java.io.*;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

@WebService()
public class ValidateCertificte {

    @WebMethod(operationName = "validateMe")
    public String validateMe(@WebParam(name = "x509certtificate") String x509certtificate) {
        // ако има проблем трябва да си призная ....
        try {
            MyCertificateValidator validator = new MyCertificateValidator();
            validator.loadCertificate(x509certtificate);
            return validator.process();
        } catch (Exception e) {
            // това не трябваше да става ...
            // признавам си грешката
            StringWriter sw = new StringWriter();
            sw.write("ГРЕШКА/ERROR!\n"//
                    + "Свържете се с 'Подръжката' и им покажете следното/"//
                    + "You should contact the 'Support Team' and show them this:\n\n");
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            pw.flush();
            return sw.toString();
        }
    }
}
