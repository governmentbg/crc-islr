package validateCertificateImpl;

import java.io.*;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.logging.Level;
import java.util.logging.Logger;
import sun.misc.BASE64Decoder;

public class MyCertificateValidator {

    // низ->byte-ове
    static final BASE64Decoder decoder = new BASE64Decoder();
    // byte-ове->object
    static final CertificateFactory certifateFactory;

    static {
        try {
            certifateFactory = CertificateFactory.getInstance("X.509");
        } catch (CertificateException ex) {
            throw new RuntimeException(" не мога да създам 'фабрика' за сетификат-формат X.509");
        }
    }
    // представянията на сертификата
    private String x509certtificate;
    private X509Certificate x509;

    // зарежда
    public void loadCertificate(String x509certtificate) {
        this.x509certtificate = x509certtificate;
        String tmpCert = x509certtificate;
        // до base64-низ
        tmpCert = tmpCert.replaceAll("^[-]+BEGIN CERTIFICATE[-]+", "");
        tmpCert = tmpCert.replaceAll("[-]+END CERTIFICATE[-]+$", "");
        // до поток
        InputStream is;
        try {
            is = new ByteArrayInputStream(decoder.decodeBuffer(tmpCert));
        } catch (IOException ex) {
            throw new RuntimeException(" не мога заредя byte-поток от base64-низ ", ex);
        }
        // до обект
        try {
            x509 = (X509Certificate) certifateFactory.generateCertificate(is);
        } catch (CertificateException ex) {
            throw new RuntimeException(" не мога заредя обект(X509Certificate) от byte-поток ", ex);
        }
    }

    // оценява валиден ли е сертификата
    public String process() {
        throw new UnsupportedOperationException("Няма имплементация/Not yet implemented");
    }
}
