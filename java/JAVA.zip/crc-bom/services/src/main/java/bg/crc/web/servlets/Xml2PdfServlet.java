/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.web.servlets;

import bg.crc.web.AServlet;
import bg.crc.xml2pdf.beans.DocumentBean;
import bg.crc.xml2pdf.readers.XmlDocumentReader;
import bg.crc.xml2pdf.writers.PdfDocumentWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Date;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.io.IOUtils;

/**
 * преобразуване на xml до pdf
 *
 * @author cstoykov
 */
@WebServlet(name = "Xml2PdfServlet", urlPatterns = {"/Xml2PdfServlet"})
@MultipartConfig(fileSizeThreshold = 1024 * 1024,
        maxFileSize = 1024 * 1024 * 5,
        maxRequestSize = 1024 * 1024 * 5 * 2)
public class Xml2PdfServlet extends AServlet {

    // изчитам данните от XML
    private static final long serialVersionUID = 1L;

    @Override
    protected void workload(HttpServletRequest request, HttpServletResponse response, String journalId) throws Exception {
        // <input type="file" name="file"/> 
        // <input type="text" name="encoding" value="utf-8"/>

        Date now = new Date();

        // Content-Type: : application/pdf
        response.setContentType("application/pdf");

        // Content-disposition : attachment; filename=<?>.<longDate>.pdf
        {
            String fileName = journalId + ".pdf";
            if (request.getPart("file") != null) {
                String temp = request.getPart("file").getSubmittedFileName();
                if (temp != null && !temp.trim().isEmpty()) {
                    fileName = temp;
                    fileName = fileName.replaceAll("[.][Xx][Mm][Ll]$", ".c" + now.getTime() + ".pdf");
                }
            }
            response.setHeader("Content-disposition", "attachment; filename=" + fileName);
        }

        // temp file
        File xml = createTempFile(journalId + ".xml", now);
        File pdf = createTempFile(journalId + ".pdf", now);

        // copy to temp file
        try (InputStream is = request.getPart("file").getInputStream()) {
            try (FileOutputStream fos = new FileOutputStream(xml)) {
                IOUtils.copyLarge(is, fos, new byte[BUFFER_SIZE]);
            }
        }

        // encoding
        String encoding = request.getParameter("encoding");
        if (encoding == null && encoding.trim().isEmpty()) {
            encoding = "utf-8";
        }

        // xml 2 pdf
        try (InputStream tmp = new FileInputStream(xml)) {
            try (InputStreamReader isr = new InputStreamReader(tmp, encoding)) {
                DocumentBean db = new XmlDocumentReader().read(isr);
                new PdfDocumentWriter().write(db, pdf);
            }
        }

        // result
        try (InputStream is = new FileInputStream(pdf)) {
            try (OutputStream os = response.getOutputStream()) {
                IOUtils.copyLarge(is, os, new byte[BUFFER_SIZE]);
                os.flush();
            }
        }
    }
}
