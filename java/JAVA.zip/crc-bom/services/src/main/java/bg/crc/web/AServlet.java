package bg.crc.web;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * <pre>
 * Общ код за услугите
 * <ol>
 * <li>управление на грешките</li>
 * <li>журнал</li>
 * <li>разщиряема реализация</li>
 * </ol>
 * </pre>
 *
 * @author cstoykov
 */
public abstract class AServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected static final int BUFFER_SIZE = 8 * 1024;
    
    protected final SimpleDateFormat yyyy = new SimpleDateFormat("yyyy");
    protected final SimpleDateFormat MM = new SimpleDateFormat("MM");
    protected final SimpleDateFormat dd = new SimpleDateFormat("dd");

    protected File tempFolder = null;

    protected File createTempFile(String name, Date now) {
        if (tempFolder == null) {
            tempFolder = new File(System.getProperty("java.io.tmpdir"));
            tempFolder = new File(tempFolder, yyyy.format(now));
            tempFolder = new File(tempFolder, MM.format(now));
            tempFolder = new File(tempFolder, dd.format(now));
            tempFolder.mkdirs();
        }
        return new File(tempFolder, name);
    }

    protected File createTempFile(String name) {
        return createTempFile(name, new Date());
    }

    /**
     * детаилно описание на грешката
     *
     * @param thr
     * @return
     */
    public static String writeThrowable(Throwable thr) {
        StringWriter sw = new StringWriter();
        thr.printStackTrace(new PrintWriter(sw, true));
        return sw.toString();
    }

    // полезната работа
    protected abstract void workload(HttpServletRequest request, HttpServletResponse response, String journalId)
            throws Exception;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String journalId = UUID.randomUUID() + "";
        Logger log = Logger.getLogger(this.getClass().getName());
        log.log(Level.FINE, "{0} : start", new Object[]{journalId});

        try {
            // полезната работа
            workload(request, response, journalId);

        } catch (Exception e) {
            log.log(Level.SEVERE, journalId + " : unexpected", e);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, journalId + " : unexpected\r\n" + writeThrowable(e));
        } finally {
            log.log(Level.FINE, "{0} : end", new Object[]{journalId});
        }
    }

}
