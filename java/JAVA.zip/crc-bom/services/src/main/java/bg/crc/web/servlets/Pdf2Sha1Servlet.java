/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.web.servlets;

import bg.crc.pdfsign.x509.X509Extractor;
import bg.crc.web.AServlet;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.io.IOUtils;

/**
 * преобразуване на pdf до sha1
 *
 * @author cstoykov
 */
@WebServlet(name = "Pdf2Sha1Servlet", urlPatterns = {"/Pdf2Sha1Servlet"})
@MultipartConfig(fileSizeThreshold = 1024 * 1024,
        maxFileSize = 1024 * 1024 * 5,
        maxRequestSize = 1024 * 1024 * 5 * 2)
public class Pdf2Sha1Servlet extends AServlet {

    // изчитам данните от XML
    private static final long serialVersionUID = 1L;

    @Override
    protected void workload(HttpServletRequest request, HttpServletResponse response, String journalId) throws Exception {
        // <input type="file" name="file"/>

        Date now = new Date();

        response.setContentType("text/plain");
        
        // Content-disposition : attachment; filename=<?>.<longDate>.sha1.txt
        {
            String fileName = journalId + ".txt";
            if (request.getPart("file") != null) {
                String temp = request.getPart("file").getSubmittedFileName();
                if (temp != null && !temp.trim().isEmpty()) {
                    fileName = temp;
                    fileName = fileName + ".sha1.txt";
                }
            }
            response.setHeader("Content-disposition", "attachment; filename=" + fileName);
        }

        // temp file
        File pdf = createTempFile(journalId + ".pdf", now);

        // copy to temp file
        try (InputStream is = request.getPart("file").getInputStream()) {
            try (FileOutputStream fos = new FileOutputStream(pdf)) {
                IOUtils.copyLarge(is, fos, new byte[BUFFER_SIZE]);
            }
        }

        String sha1 = X509Extractor.pdfCheckSum(pdf);

        try (OutputStream os = response.getOutputStream()) {
            os.write(sha1.getBytes());
        }
    }
}
