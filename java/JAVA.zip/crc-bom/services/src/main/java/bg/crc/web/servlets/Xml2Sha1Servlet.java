/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.web.servlets;

import bg.crc.web.AServlet;
import bg.crc.xml2pdf.readers.XmlDocumentReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Date;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.io.IOUtils;

/**
 * преобразуване на xml до sha1
 *
 * @author cstoykov
 */
@WebServlet(name = "Xml2Sha1Servlet", urlPatterns = {"/Xml2Sha1Servlet"})
@MultipartConfig(fileSizeThreshold = 1024 * 1024,
        maxFileSize = 1024 * 1024 * 5,
        maxRequestSize = 1024 * 1024 * 5 * 2)
public class Xml2Sha1Servlet extends AServlet {

    // изчитам данните от XML
    private static final long serialVersionUID = 1L;

    @Override
    protected void workload(HttpServletRequest request, HttpServletResponse response, String journalId) throws Exception {
        // <input type="file" name="file"/>

        Date now = new Date();

        response.setContentType("text/plain");

        // Content-disposition : attachment; filename=<?>.<longDate>.sha1.txt
        {
            String fileName = journalId + ".txt";
            if (request.getPart("file") != null) {
                String temp = request.getPart("file").getSubmittedFileName();
                if (temp != null && !temp.trim().isEmpty()) {
                    fileName = temp;
                    fileName = fileName + ".sha1.txt";
                }
            }
            response.setHeader("Content-disposition", "attachment; filename=" + fileName);
        }

        // temp file
        File xml = createTempFile(journalId + ".xml", now);

        // copy to temp file
        try (InputStream is = request.getPart("file").getInputStream()) {
            try (FileOutputStream fos = new FileOutputStream(xml)) {
                IOUtils.copyLarge(is, fos, new byte[BUFFER_SIZE]);
            }
        }

        // encoding
        String encoding = request.getParameter("encoding");
        if (encoding == null && encoding.trim().isEmpty()) {
            encoding = "utf-8";
        }

        String sha1 = null;
        try (InputStream tmp = new FileInputStream(xml)) {
            try (InputStreamReader isr = new InputStreamReader(tmp, encoding)) {
                sha1 = new XmlDocumentReader().read(isr).sha1();
            }
        }

        try (OutputStream os = response.getOutputStream()) {
            os.write(sha1.getBytes());
        }
    }
}
