/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.web.servlets;

import bg.crc.pdfsign.x509.X509Extractor;
import bg.crc.web.AServlet;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.security.cert.Certificate;
import java.util.Base64;
import java.util.Date;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.io.IOUtils;

/**
 *
 * @author cstoykov
 */
@WebServlet(name = "PdfCertificatesServlet", urlPatterns = {"/PdfCertificatesServlet"})
@MultipartConfig(fileSizeThreshold = 1024 * 1024,
        maxFileSize = 1024 * 1024 * 5,
        maxRequestSize = 1024 * 1024 * 5 * 2)
public class PdfCertificatesServlet extends AServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void workload(HttpServletRequest request, HttpServletResponse response, String journalId) throws Exception {
        //<input type="file" name="file" />

        Date now = new Date();

        // Content-Type: : application/pdf
        response.setContentType("application/x-pem-file");

        // Content-disposition : attachment; filename=<?>.<longDate>.pdf
        {
            String fileName = journalId + ".pdf";
            if (request.getPart("file") != null) {
                String temp = request.getPart("file").getSubmittedFileName();
                if (temp != null && !temp.trim().isEmpty()) {
                    fileName = temp;
                    fileName = fileName.replaceAll("[.][pP][dD][fF]$", ".pem");
                }
            }
            response.setHeader("Content-disposition", "attachment; filename=" + fileName);
        }

        // temp file 
        File inPdf = createTempFile(journalId + ".in.pdf", now);
        File outPem = createTempFile(journalId + ".out.pem", now);

        // copy to temp file 
        try (InputStream is = request.getPart("file").getInputStream()) {
            try (FileOutputStream fos = new FileOutputStream(inPdf)) {
                IOUtils.copyLarge(is, fos, new byte[8 * 1024]);
            }
        }

        // 
        try (FileOutputStream fos = new FileOutputStream(outPem)) {
            try (OutputStreamWriter osw = new OutputStreamWriter(fos)) {
                for (Certificate cert : X509Extractor.pdfCertificate(inPdf)) {
                    osw.append("-----BEGIN CERTIFICATE-----").append("\r\n");
                    osw.append(Base64.getMimeEncoder().encodeToString(cert.getEncoded())).append("\r\n");
                    osw.append("-----END CERTIFICATE-----").append("\r\n");
                }
            }
            fos.flush();
        }

        // result
        try (InputStream is = new FileInputStream(outPem)) {
            try (OutputStream os = response.getOutputStream()) {
                IOUtils.copyLarge(is, os, new byte[BUFFER_SIZE]);
                os.flush();
            }
        }
    }

}
