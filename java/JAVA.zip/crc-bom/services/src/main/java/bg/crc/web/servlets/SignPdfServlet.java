/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.web.servlets;

import bg.crc.pdfsign.p12.P12Wrapper;
import bg.crc.pdfsign.sign.PdfSigner;
import bg.crc.web.AServlet;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.KeyStore;
import java.util.Date;
import javax.naming.InitialContext;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.io.IOUtils;

/**
 *
 * @author cstoykov
 */
@WebServlet(name = "SignPdfServlet", urlPatterns = {"/SignPdfServlet"})
@MultipartConfig(fileSizeThreshold = 1024 * 1024,
        maxFileSize = 1024 * 1024 * 5,
        maxRequestSize = 1024 * 1024 * 5 * 2)
public class SignPdfServlet extends AServlet {

    private static final long serialVersionUID = 1L;

    // inline
    private static String _default(String text, String template, String defaulT) {
        if (text == null || !text.matches(template)) {
            text = defaulT;
        }
        return text;
    }

    // inline 
    private static String _default(String text) {
        return _default(text, "^[1-9][0-9]*$", "1");
    }

    private KeyStore.PrivateKeyEntry _pke;

    // inline
    // динамично оптимиране
    private KeyStore.PrivateKeyEntry _pke() {
        if (_pke == null) {
            try {
                // jndi 
                InitialContext context = new InitialContext();
                //<ResourceLink global="p12/keystore" name="p12/keystore" type="java.lang.String"/>
                String keystore = (String) context.lookup("java:comp/env/p12/keystore");
                File keystoreFile = new File(keystore);
                //<ResourceLink global="p12/keystore-pass" name="p12/keystore-pass" type="java.lang.String"/>
                String keystorePass = (String) context.lookup("java:comp/env/p12/keystore-pass");
                //<ResourceLink global="p12/alias" name="p12/alias" type="java.lang.String"/>
                String alias = (String) context.lookup("java:comp/env/p12/alias");
                //<ResourceLink global="p12/alias-pass" name="p12/alias-pass" type="java.lang.String"/>
                String aliasPass = (String) context.lookup("java:comp/env/p12/alias-pass");
                try (FileInputStream fis = new FileInputStream(keystoreFile)) {
                    P12Wrapper p12w = P12Wrapper.keystore(fis, (message) -> keystorePass.toCharArray());
                    _pke = p12w.privateKeyEntry(alias, (message) -> aliasPass.toCharArray());
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return _pke;
    }

    @Override
    protected void workload(HttpServletRequest request, HttpServletResponse response, String journalId) throws Exception {
        //<input type="file" name="file" />
        //<input type="text" value="1" name="x" pattern="[1-9][0-9]*" />
        //<input type="text" value="1" name="y" pattern="[1-9][0-9]*" />
        //<input type="text" value="1" name="w" pattern="[1-9][0-9]*" />
        //<input type="text" value="1" name="h" pattern="[1-9][0-9]*" />
        //<input type="text" name="page" value="1" pattern=".*" />
        //<input type="text" name="signature" value="" pattern=".*" />

        Date now = new Date();

        // Content-Type: : application/pdf
        response.setContentType("application/pdf");

        // Content-disposition : attachment; filename=<?>.<longDate>.pdf
        {
            String fileName = journalId + ".pdf";
            if (request.getPart("file") != null) {
                String temp = request.getPart("file").getSubmittedFileName();
                if (temp != null && !temp.trim().isEmpty()) {
                    fileName = temp;
                    // махам [.s214325435.pdf] частта, ако има ...
                    fileName = fileName.replaceAll("([.]s\\d+)?[.][pP][dD][fF]$", ".s" + now.getTime() + ".pdf");
                }
            }
            response.setHeader("Content-disposition", "attachment; filename=" + fileName);
        }

        // 
        String x = _default(request.getParameter("x"));
        String y = _default(request.getParameter("y"));
        String w = _default(request.getParameter("w"));
        String h = _default(request.getParameter("h"));
        String page = _default(request.getParameter("page"));
        String signature = _default(request.getParameter("signature"), ".+", "");

        // temp file 
        File inPdf = createTempFile(journalId + ".in.pdf", now);
        File outPdf = createTempFile(journalId + ".out.pdf", now);

        // copy to temp file 
        try (InputStream is = request.getPart("file").getInputStream()) {
            try (FileOutputStream fos = new FileOutputStream(inPdf)) {
                IOUtils.copyLarge(is, fos, new byte[8 * 1024]);
            }
        }

        // get private key 
        KeyStore.PrivateKeyEntry pke = _pke();

        // sign temp file
        {
            PdfSigner pdfSigner = new PdfSigner()
                    .dimension(Integer.valueOf(w), Integer.valueOf(h))
                    .position(Integer.valueOf(x), Integer.valueOf(y))
                    .page(Integer.valueOf(page))
                    .tempFolder(tempFolder)
                    .signature(signature);
            pdfSigner.sign(inPdf, outPdf, pke);
        }

        // result
        try (InputStream is = new FileInputStream(outPdf)) {
            try (OutputStream os = response.getOutputStream()) {
                IOUtils.copyLarge(is, os, new byte[BUFFER_SIZE]);
                os.flush();
            }
        }
    }
}
