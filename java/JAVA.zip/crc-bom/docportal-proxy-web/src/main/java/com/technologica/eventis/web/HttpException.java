/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.technologica.eventis.web;

/**
 * @author cstoykov
 */
public class HttpException extends RuntimeException {

    // 
    private final int httpStatus;

    public HttpException(int httpStatus) {
        this.httpStatus = httpStatus;
    }

    public HttpException(int httpStatus, String string) {
        super(string);
        this.httpStatus = httpStatus;
    }

    public HttpException(int httpStatus, String string, Throwable thrwbl) {
        super(string, thrwbl);
        this.httpStatus = httpStatus;
    }

    public HttpException(int httpStatus, Throwable thrwbl) {
        super(thrwbl);
        this.httpStatus = httpStatus;
    }

    public HttpException(int httpStatus, String string, Throwable thrwbl, boolean bln, boolean bln1) {
        super(string, thrwbl, bln, bln1);
        this.httpStatus = httpStatus;
    }

    public int getHttpStatus() {
        return httpStatus;
    } 
}
