/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.technologica.eventis.web.dummies;

import com.technologica.eventis.web.AServlet;
import com.technologica.eventis.web.HttpException;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Base64;
import java.util.logging.Level;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.java.Log;

/**
 *
 * @author cstoykov
 */
@WebServlet(name = "CheckDocumentServlet", urlPatterns = {"/CheckDocumentServlet"})
@Log
public class CheckDocumentServlet extends AServlet {

//--По HTTPS с метод POST и Basic HTTP Authentication се пращат application/x-www-form-urlencoded следните параметри:
//--- id - вътрешно/временно ID върнато от предходната услуга 
//-- 
//--В отговор на заявката се получава 200 OK и utf-8 текст за регистрационен номер като :
//--- текстът е „NA“ за още неиздаден регистрационен номер;
//--- текстът е издадения регистрационен номер.
//-- 
//--Очакваните (клиентски) грешки са 400 Bad Request, 404 Not Found и 401 Unauthorized.
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String error = "?!";
        try {

            error = "check input";
            {
                // Basic HTTP Authentication
                final String authorization = request.getHeader("Authorization");
                if (authorization == null) {
                    throw new HttpException(401, "bad Authorization : null");
                } else {
                    if (authorization.toLowerCase().startsWith("basic")) {
                        // Authorization: Basic base64credentials
                        String base64Credentials = authorization.replaceFirst("Basic ", "");
                        byte[] credDecoded = Base64.getDecoder().decode(base64Credentials);
                        String credentials = new String(credDecoded);
                        // credentials = username:password
                        final String[] values = credentials.split("[:]", 2);

                        // фиктивна проверка
                        if (!values[0].equalsIgnoreCase(values[1])) {
                            throw new HttpException(401, "bad Authorization : bad combination user/pass");
                        }
                    } else {
                        throw new HttpException(401, "bad Authorization : expected basic");
                    }
                }
                // id - вътрешно/временно ID върнато от предходната услуга 
                _paramNotNull(request, "id");
                _paramMatch(request, "[0-9]{1,128}", "id");

            }

            // с някава вероятност хвърлям грешка 500
            error = "random error 500";
            if (_random.nextDouble() >= 0.95) {
                throw new RuntimeException("No luck!");
            }

            // с някава вероятност хвърлям грешка 404
            error = "random error 404";
            if (_random.nextDouble() >= 0.50) {
                throw new HttpException(404, "bad id : not found");
            }

            // TODO : с някава вероятност генерирам забавяне
            // полезна работа
            error = "workload";
            response.setContentType("text/plain");
            try (OutputStream os = response.getOutputStream()) {
                if (_random.nextBoolean()) {
                    // NA 
                    os.write(("NA").getBytes());
                } else {
                    // 01-01-1/23.02.2021 
                    os.write(("0" + _random.nextInt(10) + "-0" + _random.nextInt(10) + "-" + _random.nextInt(1000) + "/23.02.2021").getBytes());
                }
            }

        } catch (HttpException http) {
            // очаквани (клиентски) грешки
            log.log(Level.WARNING, "expected error : " + error, http);
            response.setContentType("text/plain");
            response.sendError(http.getHttpStatus(), http.getMessage());
        } catch (Exception e) {
            // неочаквани (сървър) грешки
            log.log(Level.WARNING, "unexpected error : " + error, e);
            response.setContentType("text/plain");
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, error);
        }

    }

}
