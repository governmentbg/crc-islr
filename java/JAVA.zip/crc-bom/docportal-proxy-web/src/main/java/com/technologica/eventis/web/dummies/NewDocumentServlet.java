/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.technologica.eventis.web.dummies;

import com.technologica.eventis.web.AServlet;
import com.technologica.eventis.web.HttpException;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Base64;
import java.util.logging.Level;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.java.Log;

/**
 * <pre>
 * По HTTPS с метод POST и Basic HTTP Authentication се пращат application/x-www-form-urlencoded следните параметри:
 * - subject - относно на документа
 * - doctype - вид документ (1 или 2), където :
 * -- "1" за вид документ "заявление за издаване" който се очаква да бъде регистриран
 * -- "2" за вид документ "заявление за изменение", който се очаква да бъде регистриран
 * - bulstat - булстат на подателя на заявлението
 * - organization - име на фирмата на подателя
 * - egn - егн на подателя
 * - person - име на подателя на кирилица
 * - body -  криптографски защитен link към документа в РЛ
 * - register - true - да се регистрира ли документа
 * - rootid - преписка към която да се прикачи документа (0 или ...), където :
 * -- "0" да започне нова преписка
 * -- ...
 *
 * В отговор на заявката се получава 200 OK и utf-8 текст със вътрешно/временно ID.  *
 * Очакваните (клиентски) грешки са 400 Bad Request и 401 Unauthorized.
 * </pre>
 *
 * @author cstoykov
 */
@WebServlet(name = "NewDocumentServlet", urlPatterns = {"/NewDocumentServlet"})
@Log
public class NewDocumentServlet extends AServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String error = "?!";
        try {

            error = "check input";
            {
                // Basic HTTP Authentication
                final String authorization = request.getHeader("Authorization");
                if (authorization == null) {
                    if (_random.nextBoolean()) {
                        throw new HttpException(401, "bad Authorization : null");
                    }
                } else {
                    if (authorization.toLowerCase().startsWith("basic")) {
                        // Authorization: Basic base64credentials
                        String base64Credentials = authorization.replaceFirst("Basic ", "");
                        byte[] credDecoded = Base64.getDecoder().decode(base64Credentials);
                        String credentials = new String(credDecoded);
                        // credentials = username:password
                        final String[] values = credentials.split("[:]", 2);

                        // фиктивна проверка
                        if (!values[0].equalsIgnoreCase(values[1])) {
                            throw new HttpException(401, "bad Authorization : bad combination user/pass");
                        }
                    } else {
                        throw new HttpException(401, "bad Authorization : expected basic");
                    }
                }
                // subject - относно на документа 
                _paramNotNull(request, "subject");
                _paramMatch(request, ".{1,1024}", "subject");
                // doctype - вид документ (1 или 2) 
                _paramNotNull(request, "doctype");
                _paramMatch(request, "[12]", "doctype");
                // bulstat - булстат на подателя на заявлението
                _paramNotNull(request, "bulstat");
                _paramMatch(request, "[0-9]{9}|[0-9]{13}", "bulstat");
                // organization - име на фирмата на подателя
                _paramNotNull(request, "organization");
                _paramMatch(request, ".{1,1024}", "organization");
                // egn - егн на подателя
                _paramNotNull(request, "egn");
                _paramMatch(request, "[0-9]{10,10}", "egn");
                // person - име на подателя на кирилица
                _paramNotNull(request, "person");
                _paramMatch(request, ".{1,1024}", "person");
                // body -  криптографски защитен link към документа в РЛ
                _paramNotNull(request, "body");
                _paramMatch(request, ".{1,1024}", "body");
                // register - true - да се регистрира ли документа
                _paramNotNull(request, "register");
                _paramMatch(request, "true", "register");
                // rootid - преписка към която да се прикачи документа (0 или ...) 
                _paramNotNull(request, "rootid");
                _paramMatch(request, "0", "rootid");
            }

            // с някава вероятност хвърлям грешка
            error = "random error";
            if (_random.nextDouble() >= 0.95) {
                throw new RuntimeException("No luck!");
            }

            // TODO : с някава вероятност генерирам забавяне
            // полезна работа
            error = "workload";
            response.setContentType("text/plain");
            try (OutputStream os = response.getOutputStream()) {
                os.write(("" + _random.nextInt(1_000_000)).getBytes());
            }

        } catch (HttpException http) {
            // очаквани (клиентски) грешки
            log.log(Level.WARNING, "expected error : " + error, http);
            response.setContentType("text/plain");
            response.sendError(http.getHttpStatus(), http.getMessage());
        } catch (Exception e) {
            // неочаквани (сървър) грешки
            log.log(Level.WARNING, "unexpected error : " + error, e);
            response.setContentType("text/plain");
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, error);
        }
    }
}
