/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.technologica.eventis.web.proxies;

import com.technologica.eventis.web.AServlet;
import com.technologica.eventis.web.HttpException;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.java.Log;

import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;

/**
 * <pre>
 * --По HTTPS с метод POST и Basic HTTP Authentication се пращат application/x-www-form-urlencoded следните параметри:
 * --- id - вътрешно/временно ID върнато от предходната услуга
 * --
 * --В отговор на заявката се получава 200 OK и utf-8 текст за регистрационен номер като :
 * --- текстът е „NA“ за още неиздаден регистрационен номер;
 * --- текстът е издадения регистрационен номер.
 * --
 * --Очакваните (клиентски) грешки са 400 Bad Request, 404 Not Found и 401 Unauthorized.
 * </pre>
 *
 * @author cstoykov
 */
@WebServlet(name = "ProxyCheckDocumentServlet", urlPatterns = {"/ProxyCheckDocumentServlet"})
@Log
public class ProxyCheckDocumentServlet extends AServlet {

    // GET / POST
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        UUID _id = UUID.randomUUID();
        log.log(Level.INFO, String.format("%s : start", _id));
        String error = "?!";
        try {

            error = "check/read input";
            String _url, _user, _pass, id;
            {
                // _url
                _url = _paramNotNull(request, "_url");
                _paramUrl(request, "_url");
                log.log(Level.INFO, String.format("%s : _url = %s", _id, _logEscape(_url)));

                // header[Authentication]
                _headerNotNull(request, "Authorization");
                _headerMatch(request, PATERN_BASICAUTH, "Authorization");
                _user = _authorizationUser(request);
                _pass = _authorizationPass(request);
                log.log(Level.INFO, String.format("%s : _user = %s", _id, _logEscape(_user)));
                //log.log(Level.INFO, String.format("%s : _pass = %s", _id, _pass));

                // id - относно на документа 
                id = _paramNotNull(request, "id");
                _paramMatch(request, "[0-9]{1,1024}", "id");
                log.log(Level.INFO, String.format("%s : id = %s", _id, _logEscape(id)));
            }

            error = "prepare http post";
            HttpPost post = new HttpPost(_url);

            // add request parameters or form parameters
            List<NameValuePair> urlParameters = new ArrayList<>();
            urlParameters.add(new BasicNameValuePair("id", id));

            // user/pass
            post.setHeader("Authorization", "Basic " + Base64.getEncoder().encodeToString((_user + ":" + _pass).getBytes(CHARSET_UTF8)));

            // http body is query-string utf-8 encoded
            post.setEntity(new UrlEncodedFormEntity(urlParameters, CHARSET_UTF8));

            try (CloseableHttpClient httpClient = HttpClientBuilder
                    .create()
                    // hostname don't matter
                    .setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE)
                    // server certificated don't matter
                    .setSSLContext(SSLContexts.custom().loadTrustMaterial(null, (certificate, authType) -> true).build())
                    // 
                    .setDefaultRequestConfig(RequestConfig.custom()
                            // the time to establish the connection with the remote host
                            .setConnectTimeout(2 * 1000)
                            // the time to wait for a connection from the connection manager/pool
                            .setConnectionRequestTimeout(2 * 1000)
                            // the time waiting for data – after establishing the connection; 
                            // maximum time of inactivity between two data packets
                            .setSocketTimeout(30 * 1000)
                            .build())
                    .build()) {

                error = "make http post";
                try (CloseableHttpResponse httpResponse = httpClient.execute(post)) {

                    // 200, 4**
                    int httpStatus = httpResponse.getStatusLine().getStatusCode();
                    log.log(Level.INFO, String.format("%s : httpStatus = %s", _id, _logEscape("" + httpStatus)));

                    String httpBody = EntityUtils.toString(httpResponse.getEntity());
                    log.log(Level.INFO, String.format("%s : httpBody = %s", _id, _logEscape(httpBody)));

                    if (httpStatus == 200) {
                        response.setContentType("text/plain");
                        try (OutputStream os = response.getOutputStream()) {
                            os.write(httpBody.getBytes());
                        }
                    } else {
                        response.sendError(httpStatus, "[proxy:" + _id + "]");
                    }
                }
            }
        } catch (HttpException http) {
            // очаквани (клиентски) грешки 
            log.log(Level.WARNING, String.format("%s : expected error for proxy", _id), http);
            response.setContentType("text/plain");
            response.sendError(http.getHttpStatus(), http.getMessage());
        } catch (Exception e) {
            // неочаквани (сървър) грешки
            log.log(Level.SEVERE, String.format("%s : unexpected error for proxy : " + error, _id), e);
            response.setContentType("text/plain");
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, error);
        } finally {
            log.log(Level.INFO, String.format("%s : end", _id));
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
