/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import org.apache.http.HttpHeaders;

import org.apache.http.NameValuePair;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;

/**
 * https://www.baeldung.com/httpclient-4-basic-authentication
 *
 * @author cstoykov
 */
public class DemoProxyCheck {

    public static void main(String[] args) throws Exception {
        List<String> messages = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            HttpPost post = new HttpPost("http://localhost:9180/eventis-web/ProxyCheckDocumentServlet");
            post.setHeader(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString(("user:user").getBytes()));

            // add request parameters or form parameters
            List<NameValuePair> urlParameters = new ArrayList<>();
            urlParameters.add(new BasicNameValuePair("_url", "http://localhost:9180/eventis-web/CheckDocumentServlet"));
            urlParameters.add(new BasicNameValuePair("id", "1234"));

            CredentialsProvider provider = new BasicCredentialsProvider();
            provider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials("user", "user"));
            post.setEntity(new UrlEncodedFormEntity(urlParameters));

            try (CloseableHttpClient httpClient = HttpClientBuilder
                    .create()
                    .setDefaultCredentialsProvider(provider)
                    .setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE)
                    .setSSLContext(SSLContexts.custom().loadTrustMaterial(null, (certificate, authType) -> true).build()).build()) {
                try (CloseableHttpResponse response = httpClient.execute(post)) {
                    messages.add(response.getStatusLine().getStatusCode() + " : "
                            + (response.getStatusLine().getStatusCode() == 200 ? EntityUtils.toString(response.getEntity()) : "..."));
                }
            }
        }
        messages.forEach((msg) -> System.out.println(msg));
    }
}
