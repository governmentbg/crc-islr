/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author cstoykov
 */
public class GoCountCsv {
    
    public static void main(String[] args) throws Exception {
        CountCsv.main(
                "C:\\Users\\cstoykov\\Downloads\\adapter-opmet-v2.2021-01-21.0.log",
                "C:\\Users\\cstoykov\\Downloads\\adapter-opmet-v2.log"
        ); 
    }
    
}
