
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.StreamTokenizer;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Анализ на WARN съобщения null {@code
 * 00:18:17.322 [Thread-108648] WARN  c.b.i.a.opmetv2.OpmetHttpServlet - 542946348 : {host=10.203.12.6,port=4100} : bad message in bulletin : message = TextMessage{text = "TNCE 202355Z AUTO 08010KT 030V100 //// // ///////// 25/20 Q1015\r\n     RE//="}, bulletin = BulletinBean{type = "SA", country = "CA", no = "33", airport = "KWBC", date = "210000", bbbGroup = null, body = "METAR\r\nTBPB NIL=\r\nTDPD NIL=\r\nTDPR NIL=\r\nTFFF NIL=\r\nTFFG NIL=\r\nTFFJ NIL=\r\nTFFR NIL=\r\nTGPY NIL=\r\nTGPZ NIL=\r\nTLPC NIL=\r\nTLPL NIL=\r\nTNCA 210000Z 08013KT 9999 FEW019 26/21 Q1012 NOSIG=\r\nTNCB 202355Z AUTO 08010KT 050V110 9999 FEW023/// 25/21 Q1012=\r\nTNCC NIL=\r\nTNCE 202355Z AUTO 08010KT 030V100 //// // ///////// 25/20 Q1015\r\n     RE//=\r\nTNCM 210000Z 07008KT 9999 FEW020 26/21 Q1016 NOSIG=\r\nTTCP NIL=\r\nTTPP NIL=\r\nTVSM NIL=\r\nTVSU NIL=\r\nTVSV NIL=\r\n"}
 * 00:18:17.322 [Thread-108648] WARN  c.b.i.a.opmetv2.OpmetHttpServlet - 542946348 : {host=10.203.12.6,port=4100} : bad message in bulletin : message = TextMessage{text = "TNCM 210000Z 07008KT 9999 FEW020 26/21 Q1016 NOSIG="}, bulletin = BulletinBean{type = "SA", country = "CA", no = "33", airport = "KWBC", date = "210000", bbbGroup = null, body = "METAR\r\nTBPB NIL=\r\nTDPD NIL=\r\nTDPR NIL=\r\nTFFF NIL=\r\nTFFG NIL=\r\nTFFJ NIL=\r\nTFFR NIL=\r\nTGPY NIL=\r\nTGPZ NIL=\r\nTLPC NIL=\r\nTLPL NIL=\r\nTNCA 210000Z 08013KT 9999 FEW019 26/21 Q1012 NOSIG=\r\nTNCB 202355Z AUTO 08010KT 050V110 9999 FEW023/// 25/21 Q1012=\r\nTNCC NIL=\r\nTNCE 202355Z AUTO 08010KT 030V100 //// // ///////// 25/20 Q1015\r\n     RE//=\r\nTNCM 210000Z 07008KT 9999 FEW020 26/21 Q1016 NOSIG=\r\nTTCP NIL=\r\nTTPP NIL=\r\nTVSM NIL=\r\nTVSU NIL=\r\nTVSV NIL=\r\n"}
 * 00:18:17.322 [Thread-108648] WARN  c.b.i.a.opmetv2.OpmetHttpServlet - 542946348 : {host=10.203.12.6,port=4100} : bad message in bulletin : message = TextMessage{text = "TTCP NIL="}, bulletin = BulletinBean{type = "SA", country = "CA", no = "33", airport = "KWBC", date = "210000", bbbGroup = null, body = "METAR\r\nTBPB NIL=\r\nTDPD NIL=\r\nTDPR NIL=\r\nTFFF NIL=\r\nTFFG NIL=\r\nTFFJ NIL=\r\nTFFR NIL=\r\nTGPY NIL=\r\nTGPZ NIL=\r\nTLPC NIL=\r\nTLPL NIL=\r\nTNCA 210000Z 08013KT 9999 FEW019 26/21 Q1012 NOSIG=\r\nTNCB 202355Z AUTO 08010KT 050V110 9999 FEW023/// 25/21 Q1012=\r\nTNCC NIL=\r\nTNCE 202355Z AUTO 08010KT 030V100 //// // ///////// 25/20 Q1015\r\n     RE//=\r\nTNCM 210000Z 07008KT 9999 FEW020 26/21 Q1016 NOSIG=\r\nTTCP NIL=\r\nTTPP NIL=\r\nTVSM NIL=\r\nTVSU NIL=\r\nTVSV NIL=\r\n"}
 * 00:18:17.322 [Thread-108648] WARN  c.b.i.a.opmetv2.OpmetHttpServlet - 542946348 : {host=10.203.12.6,port=4100} : bad message in bulletin : message = TextMessage{text = "TTPP NIL="}, bulletin = BulletinBean{type = "SA", country = "CA", no = "33", airport = "KWBC", date = "210000", bbbGroup = null, body = "METAR\r\nTBPB NIL=\r\nTDPD NIL=\r\nTDPR NIL=\r\nTFFF NIL=\r\nTFFG NIL=\r\nTFFJ NIL=\r\nTFFR NIL=\r\nTGPY NIL=\r\nTGPZ NIL=\r\nTLPC NIL=\r\nTLPL NIL=\r\nTNCA 210000Z 08013KT 9999 FEW019 26/21 Q1012 NOSIG=\r\nTNCB 202355Z AUTO 08010KT 050V110 9999 FEW023/// 25/21 Q1012=\r\nTNCC NIL=\r\nTNCE 202355Z AUTO 08010KT 030V100 //// // ///////// 25/20 Q1015\r\n     RE//=\r\nTNCM 210000Z 07008KT 9999 FEW020 26/21 Q1016 NOSIG=\r\nTTCP NIL=\r\nTTPP NIL=\r\nTVSM NIL=\r\nTVSU NIL=\r\nTVSV NIL=\r\n"}
 * 00 }
 *
 * @author cstoykov
 */
public class CountCsv {

    public static void main(String... files) throws Exception {
        // файл по файл
        for (String file : files) {
            System.out.println("-------------------------------");
            System.out.println("file = " + file);
            // буферирам, за да чета по бързо и ред по ред
            try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "utf-8"))) {
                // статистики
                Map<String, Long> stats = new TreeMap<>();
                // ред по ред
                String line;
                while ((line = br.readLine()) != null) {
                    // редове
                    stats.put("*", stats.getOrDefault("*", 0L) + 1L);
                    if (line.matches("^\\d{2}:\\d{2}:\\d{2}[.]\\d{3} .Thread-\\d+. .*")) {
                        // съобщения почват с "00:00:12.573 [Thread-108648] " 
                        stats.put("msg", stats.getOrDefault("msg", 0L) + 1L);

                        // предупрежденията започват с "00:18:17.322 [Thread-108648] WARN "
                        if (line.matches("^\\d{2}:\\d{2}:\\d{2}[.]\\d{3} .Thread-\\d+. WARN .*")) {
                            stats.put("msg/WARN", stats.getOrDefault("msg/WARN", 0L) + 1L);

                            // предупрежденията започват с "00:18:17.322 [Thread-108648] WARN c.b.i.a.opmetv2.OpmetHttpServlet .*"
                            if (line.matches("^\\d{2}:\\d{2}:\\d{2}[.]\\d{3} .Thread-\\d+. WARN \\s*c.b.i.a.opmetv2.OpmetHttpServlet .*")) {
                                stats.put("msg/WARN/OpmetHttpServlet", stats.getOrDefault("msg/WARN/OpmetHttpServlet", 0L) + 1L);

                                // предупрежденията започват с "00:18:17.322 [Thread-108648] WARN c.b.i.a.opmetv2.OpmetHttpServlet .*" 
                                List<String> parts = Arrays.asList(line.split("(\\s+[:]\\s+)"));
                                for (String part : parts) {
                                    String temp = part.trim();
                                    if (temp.startsWith("bad ")) {
                                        stats.put("msg/WARN/OpmetHttpServlet/" + temp, stats.getOrDefault("msg/WARN/OpmetHttpServlet/" + temp, 0L) + 1L);
                                    }
                                }

                            }

                        }
                    }
                }

                // какво намерих
                for (String key : stats.keySet()) {
                    System.out.println(" stats[" + key + "] = " + stats.get(key));
                }
            }
        }
    }
}
