/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.xml2pdf;

import bg.crc.xml2pdf.beans.DocumentBean;
import java.io.File;
import java.io.OutputStream;
import java.io.Writer;

/**
 * записване на документ
 *
 * @author cstoykov
 */
public interface IDocumentWriter {

    /**
     * запис на документ в символен поток
     *
     * @param documentBean документ
     * @param writer символен поток
     */
    void write(DocumentBean documentBean, Writer writer);

    /**
     * запис на документ в бинарен поток
     *
     * @param documentBean документ
     * @param stream бинарен поток
     */
    void write(DocumentBean documentBean, OutputStream stream);

    /**
     * запис на документ в бинарен файл
     *
     * @param documentBean документ
     * @param file файл
     */
    void write(DocumentBean documentBean, File file);
}
