/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.xml2pdf.readers;

import bg.crc.xml2pdf.IDocumentReader;
import bg.crc.xml2pdf.beans.DocumentBean;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.Reader;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Objects;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;
import lombok.extern.java.Log;

/**
 * прочитане от XML
 *
 * https://docs.oracle.com/cd/E13222_01/wls/docs92/xml/stax.html
 *
 * @author cstoykov
 */
@Log
public class XmlDocumentReader implements IDocumentReader {

    private static final int BUFFER_SIZE = 8 * 1024;

    /**
     * четене от xml поток
     *
     * @param xmlReader
     * @param documentBean
     * @throws XMLStreamException
     */
    protected void read(XMLEventReader xmlReader, DocumentBean documentBean) throws XMLStreamException {
        Map<String, String> record = null;
        LinkedList<String> path = new LinkedList<>();
        while (xmlReader.hasNext()) {
            XMLEvent e = xmlReader.nextEvent();
            // TODO: пренапиши със switch/case
            if (e.isStartElement()) {
                path.addFirst(e.asStartElement().getName().getLocalPart());
                System.out.println("path = " + path);
                if (path.size() >= 2
                        && "ROWSET".equals(path.get(1))) {
                    // path = [CO_REQUESTS, ROWSET, ...]  
                    String table = path.get(0);
                    if (documentBean.getColumns().get(table) == null) {
                        documentBean.getColumns().put(table, new LinkedHashMap<>());
                        documentBean.getTables().put(table, table);
                        documentBean.getDatasets().put(table, new LinkedList<>());
                    }
                } else if (path.size() >= 3
                        && "TABLE_ROW".equals(path.get(0))
                        && "ROWSET".equals(path.get(2))) {
                    // path = [TABLE_ROW, CO_REQUESTS, ROWSET, ...]
                    record = new LinkedHashMap<>();
                } else if (path.size() >= 4
                        && "TABLE_ROW".equals(path.get(1))
                        && "ROWSET".equals(path.get(3))) {
                    // path = [ID, TABLE_ROW, CO_REQUESTS, ROWSET, ...] 
                    String column = path.get(0);
                    String table = path.get(2);
                    if (documentBean.getColumns().get(table).get(column) == null) {
                        documentBean.getColumns().get(table).put(column, column);
                    }
                }
            } else if (e.isCharacters()) {
                if (path.size() >= 3
                        && "TABLE_DESCRIPTION".equals(path.get(0))
                        && "ROWSET".equals(path.get(2))) {
                    // path = [TABLE_DESCRIPTION, CO_REQUESTS, ROWSET, ...]
                    String text = e.asCharacters().getData();
                    String table = path.get(1);
                    String oldText = documentBean.getTables().put(table, text);
                    if (oldText != null && !oldText.equals(text)) {
                        log.warning("(?!) table-description(" + table + ") : old = " + oldText + ", new = " + text);
                    }
                } else if (path.size() >= 5
                        && "COLUMN_DESCRIPTION".equals(path.get(0))
                        && "TABLE_ROW".equals(path.get(2))
                        && "ROWSET".equals(path.get(4))) {
                    // path = [COLUMN_DESCRIPTION, ID, TABLE_ROW, CO_REQUESTS, ROWSET, ...]
                    String text = e.asCharacters().getData();
                    String column = path.get(1);
                    String table = path.get(3);
                    String oldValue = documentBean.getColumns().get(table).put(column, text);
                    if (oldValue != null && !oldValue.equals(text)) {
                        log.warning("(?!) column-description : table = " + table + ", column = " + column + ", old = " + oldValue + ", new = " + text);
                    }
                } else if (path.size() >= 5
                        && "COLUMN_VALUE".equals(path.get(0))
                        && "TABLE_ROW".equals(path.get(2))
                        && "ROWSET".equals(path.get(4))) {
                    // path = [COLUMN_VALUE, ID, TABLE_ROW, CO_REQUESTS, ROWSET, ...]
                    String text = e.asCharacters().getData();
                    String column = path.get(1);
                    String table = path.get(3);
                    Objects.requireNonNull(record, "record is null?!").put(column, text);
                }
            } else if (e.isEndElement()) {
                if (path.size() >= 3
                        && "TABLE_ROW".equals(path.get(0))
                        && "ROWSET".equals(path.get(2))) {
                    // path = [TABLE_ROW, CO_REQUESTS, ROWSET, ...]
                    String table = path.get(1);
                    documentBean.getDatasets().get(table).add(record);
                    record = null;
                }
                path.removeFirst();
            }
        }
    }

    @Override
    public DocumentBean read(Reader reader) {
        DocumentBean result = new DocumentBean();
        try (BufferedReader br = new BufferedReader(reader, BUFFER_SIZE)) {
            XMLInputFactory factory = XMLInputFactory.newInstance();
            factory.setProperty(XMLInputFactory.IS_NAMESPACE_AWARE, true);
            XMLEventReader eventReader = factory.createXMLEventReader(br);
            read(eventReader, result);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
        return result;
    }

    @Override
    public DocumentBean read(InputStream stream) {
        DocumentBean result = new DocumentBean();
        try (BufferedInputStream bis = new BufferedInputStream(stream, BUFFER_SIZE)) {
            XMLInputFactory factory = XMLInputFactory.newInstance();
            factory.setProperty(XMLInputFactory.IS_NAMESPACE_AWARE, true);
            XMLEventReader eventReader = factory.createXMLEventReader(bis);
            read(eventReader, result);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
        return result;
    }

    @Override
    public DocumentBean read(File file) {
        DocumentBean result = new DocumentBean();
        try (FileInputStream fis = new FileInputStream(file);
                BufferedInputStream bis = new BufferedInputStream(fis, BUFFER_SIZE);) {
            XMLInputFactory factory = XMLInputFactory.newInstance();
            factory.setProperty(XMLInputFactory.IS_NAMESPACE_AWARE, true);
            XMLEventReader eventReader = factory.createXMLEventReader(bis);
            read(eventReader, result);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
        return result;
    }
}
