/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.xml2pdf.writers;

import bg.crc.xml2pdf.IDocumentWriter;
import bg.crc.xml2pdf.beans.DocumentBean;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.Writer;
import lombok.extern.java.Log;

/**
 * https://www.baeldung.com/java-pdf-creation
 * http://www.java2s.com/Code/Java/PDF-RTF/DemonstratesthecreatingPDFinportraitlandscape.htm
 * https://developers.itextpdf.com/question/how-resize-pdfptable-fit-page
 *
 * @author cstoykov
 */
@Log
public class PdfDocumentWriter implements IDocumentWriter {// шрифт с кирилица

    @Override
    public void write(DocumentBean documentBean, Writer reader) {
        throw new UnsupportedOperationException("Not supported for PDF.");
    }

    @Override
    public void write(DocumentBean documentBean, OutputStream stream) {
        try {
            PdfBuilder pdfBuilder = new PdfBuilder(documentBean);
            pdfBuilder.build(stream);
        } catch (RuntimeException re) {
            throw re;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void write(DocumentBean documentBean, File file) {
        // backup 
        if (file.exists()) {
            File backupFile = new File(file.getParentFile(), file.getName() + "." + System.currentTimeMillis() + ".bak");
            if (!file.renameTo(backupFile)) {
                log.warning("backup : " + file);
            }
        }
        try (FileOutputStream fos = new FileOutputStream(file)) {
            PdfBuilder pdfBuilder = new PdfBuilder(documentBean);
            pdfBuilder.build(fos);
        } catch (RuntimeException re) {
            throw re;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
