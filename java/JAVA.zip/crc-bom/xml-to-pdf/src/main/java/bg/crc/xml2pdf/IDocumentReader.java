/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.xml2pdf;

import bg.crc.xml2pdf.beans.DocumentBean;
import java.io.File;
import java.io.InputStream;
import java.io.Reader;

/**
 * прочитане документ
 *
 * @author cstoykov
 */
public interface IDocumentReader {

    /**
     * @param reader символен поток
     * @return документ
     */
    DocumentBean read(Reader reader);

    /**
     * @param stream бинарен поток
     * @return документ
     */
    DocumentBean read(InputStream stream);

    /**
     * @param file файл
     * @return документ
     */
    DocumentBean read(File file);
}
