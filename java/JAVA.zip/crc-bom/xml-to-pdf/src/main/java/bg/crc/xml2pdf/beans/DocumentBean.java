/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.xml2pdf.beans;

import java.security.MessageDigest;
import java.util.Base64;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 *
 * @author cstoykov
 */
@lombok.Data
@lombok.extern.java.Log
public class DocumentBean {

    // етикет за таблица 
    // [TABLE_DESCRIPTION, <table-name>, ROWSET, ...] 
    protected final Map<String, String> tables = new LinkedHashMap<>();

    // етикет за колона от таблица
    // [COLUMN_DESCRIPTION, <column-name>, TABLE_ROW, <table-name>, ROWSET,...]
    protected final Map<String, Map<String, String>> columns = new LinkedHashMap<>();

    // запис от таблица
    // [COLUMN_VALUE, ID, TABLE_ROW, CO_REQUESTS, ROWSET, ...]
    protected final Map<String, List<Map<String, String>>> datasets = new LinkedHashMap<>();

    /**
     * нова таблица
     *
     * @param tableKey име на таблица
     * @return същия обект
     */
    public DocumentBean addTable(String tableKey) {
        if (!tables.containsKey(tableKey)) {
            tables.put(tableKey, tableKey);
        }
        if (!columns.containsKey(tableKey)) {
            columns.put(tableKey, new LinkedHashMap<>());
        }
        if (!datasets.containsKey(tableKey)) {
            datasets.put(tableKey, new LinkedList<>());
        }
        return this;
    }

    /**
     * нов етикет за таблица
     *
     * @param tableKey име на таблица
     * @param newTableLabel етикет на таблица
     * @return същия обект
     */
    public DocumentBean addTableLabel(String tableKey, String newTableLabel) {
        DocumentBean.this.addTable(tableKey);
        String oldTableLabel = tables.put(tableKey, newTableLabel);
        if (oldTableLabel != null && !oldTableLabel.equals(newTableLabel)) {
            log.warning(String.format("table = %s, oldLabel = %s, newLabel =%s", tableKey, oldTableLabel, newTableLabel));
        }
        return this;
    }

    /**
     * нов етикет за колона от таблица
     *
     * @param tableKey
     * @param columnKey
     * @param newColumnLabel
     * @return
     */
    public DocumentBean addColumnLabel(String tableKey, String columnKey, String newColumnLabel) {
        DocumentBean.this.addTable(tableKey);
        if (!columns.get(tableKey).containsKey(columnKey)) {
            columns.get(tableKey).put(columnKey, newColumnLabel);
        } else {
            String oldColumnLabel = columns.get(tableKey).put(columnKey, newColumnLabel);
            if (oldColumnLabel != null && !oldColumnLabel.equals(newColumnLabel)) {
                log.warning(String.format("table = %s, column = %s, oldLabel = %s, newLabel =%s",
                        tableKey, columnKey, oldColumnLabel, newColumnLabel));
            }
        }
        return this;
    }

    /**
     * нова запис за таблица
     *
     * @param tableKey
     * @param record
     * @return
     */
    public DocumentBean addRecord(String tableKey, Map<String, String> record) {
        DocumentBean.this.addTable(tableKey);
        // проверявам, че има такива колони вече
        // 1) липсващи ( column.key[] - record.key[] ) 
        TreeSet<String> missing = new TreeSet<>(this.columns.getOrDefault(tableKey, Collections.EMPTY_MAP).keySet());
        missing.removeAll(record.keySet());
        if (!missing.isEmpty()) {
            log.warning("missing keys : " + missing);
        }
        // 2) липсващи ( column.key[] - record.key[] )
        TreeSet<String> more = new TreeSet<>(record.keySet());
        more.removeAll(this.columns.getOrDefault(tableKey, Collections.EMPTY_MAP).keySet());
        if (!more.isEmpty()) {
            log.warning("additional keys : " + more);
        }
        // добавям запис
        this.datasets.get(tableKey).add(new TreeMap<>(record));
        return this;
    }
 
    /** 
     * @return sha1(this)
     */
    public String sha1() {
        try {
            MessageDigest sha1 = MessageDigest.getInstance("SHA1");

            for (Map.Entry<String, String> table : this.tables.entrySet()) {
                sha1.update(String.format("|table[%s]=[%s]", table.getKey(), table.getValue()).getBytes("utf-8"));
            }
            
            for (Map.Entry<String, List<Map<String, String>>> dataset : this.datasets.entrySet()) {
                sha1.update(String.format("|dataset[%s]=[%s]", dataset.getKey(), dataset.getValue()).getBytes("utf-8"));
            }
            
            for (Map.Entry<String, Map<String, String>> column : this.columns.entrySet()) {
                sha1.update(String.format("|column[%s]=[%s]", column.getKey(), column.getValue()).getBytes("utf-8"));
            }

            return Base64.getEncoder().encodeToString(sha1.digest());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
