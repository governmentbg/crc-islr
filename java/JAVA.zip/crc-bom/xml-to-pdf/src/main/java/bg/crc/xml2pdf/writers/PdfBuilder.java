/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.xml2pdf.writers;

import bg.crc.xml2pdf.beans.DocumentBean;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;
import lombok.Data;
import org.apache.commons.io.IOUtils;

/**
 * направи ми PDF
 *
 * @author cstoykov
 */
@Data
public class PdfBuilder {

    // отместваме в А4 на страницата
    protected final float offset = 30;

    // данни за показване
    protected final DocumentBean documentBean;

    // шрифт за кирилица
    protected BaseFont baseFont;

    {
        // TODO : премести в jar
        File temp = null;
        try {
            temp = new File(System.getProperty("java.io.tmpdir"));
            temp = new File(temp, "fonts"); 
            temp = new File(temp, "arial.ttf");
            if (!temp.exists()) {
                temp.getParentFile().mkdirs();
                try (InputStream is = PdfBuilder.class.getResourceAsStream("/fonts/arial.ttf")) {
                    try(OutputStream os = new FileOutputStream(temp)){ 
                        IOUtils.copy(is, os);
                    }
                }
            }
            baseFont = BaseFont.createFont(temp.toString(), BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
        } catch (DocumentException | IOException ex) {
            throw new RuntimeException("file = " + temp, ex);
        }
    }

    // шрифт за header
    protected Font headerFont = new Font(baseFont, 14f);

    {
        headerFont.setStyle(Font.BOLD | Font.ITALIC);
    }

    // шрифт за данните
    protected Font dataFont = new Font(baseFont, 12F);

    {
        dataFont.setStyle(Font.NORMAL);
    }

    // шрифт за бележки
    protected Font noteFont = new Font(baseFont, 10F);

    protected Document pdfDocument;
    protected int iDataset = 0;

    {
        dataFont.setStyle(Font.ITALIC);
    }

    /**
     * <table>
     * <tr><th colspan="2">table-label</th></tr>
     * <tr><th>column-label</th><td>value</td></tr>
     * <tr><th>column-label</th><td>value</td></tr>
     * <tr><td colspan="2">...</td></tr>
     * </table>
     *
     * @param table
     * @param dataset
     * @return
     */
    protected PdfPTable buildPdfTable(String table, Map<String, String> dataset) {
        PdfPTable pdfTable = new PdfPTable(2);
        pdfTable.setWidthPercentage(100);
        // table-label
        {
            PdfPCell tableNameCell = new PdfPCell(new Phrase(documentBean.getTables().getOrDefault(table, table), headerFont));
            tableNameCell.setColspan(2);
            tableNameCell.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tableNameCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            pdfTable.addCell(tableNameCell);
        }
        // ред по ред
        for (String column : documentBean.getColumns().get(table).keySet()) {
            // прескочи липсващи стойности
            if (dataset.get(column) == null || dataset.get(column).isEmpty()) {
                continue;
            }

            PdfPCell columnNameCell = new PdfPCell(new Phrase(documentBean.getColumns().get(table).getOrDefault(column, column), headerFont));
            columnNameCell.setBackgroundColor(BaseColor.LIGHT_GRAY);
            columnNameCell.setHorizontalAlignment(Element.ALIGN_LEFT);
            pdfTable.addCell(columnNameCell);

            PdfPCell columnValueCell = new PdfPCell(new Phrase(dataset.get(column), dataFont));
            columnValueCell.setBackgroundColor(BaseColor.WHITE);
            columnValueCell.setHorizontalAlignment(Element.ALIGN_LEFT);
            pdfTable.addCell(columnValueCell);
        }
        return pdfTable;
    }

    /**
     *
     * @throws DocumentException
     */
    protected void buildFirstPage() throws DocumentException {
        pdfDocument.newPage();
        Paragraph tmp = new Paragraph("Разписка", headerFont);
        tmp.setSpacingAfter(20F);
        pdfDocument.add(tmp);

        byte[] checksum = (Math.random() + "" + Math.random()).getBytes();
        tmp = new Paragraph("Контролна сума (base64): {" + documentBean.sha1() + "}", dataFont);
        tmp.setSpacingAfter(5F);
        pdfDocument.add(tmp);

        tmp = new Paragraph("Приложения", headerFont);
        tmp.setSpacingAfter(20F);
        pdfDocument.add(tmp);
        int iDataset = 1;
        for (String table : documentBean.getTables().keySet()) {
            for (Map<String, String> dataset : documentBean.getDatasets().get(table)) {
                tmp = new Paragraph(iDataset + ". [" + dataset.get("ID") + "] " + documentBean.getTables().getOrDefault(table, table), dataFont);
                tmp.setSpacingAfter(5F);
                pdfDocument.add(tmp);
                iDataset += 1;
            }
        }
    }

    /**
     * @param table
     * @param record
     */
    protected void buildDatasetPage(String table, Map<String, String> record) {
        try {
            iDataset += 1;
            pdfDocument.newPage();
            Paragraph tmp = new Paragraph(iDataset + ". [" + record.get("ID") + "] " + documentBean.getTables().getOrDefault(table, table), dataFont);
            tmp.setSpacingAfter(20F);
            pdfDocument.add(tmp);
            pdfDocument.add(buildPdfTable(table, record));
        } catch (Exception e) {
            throw new RuntimeException("unexpectd : table = " + table + ", record = " + record, e);
        }
    }

    /**
     * построй ми документ
     *
     * @param outputStream
     * @throws IOException
     * @throws DocumentException
     */
    public synchronized void build(OutputStream outputStream) throws IOException, DocumentException {
        iDataset = 0;

        pdfDocument = new Document(PageSize.A4);
        PdfWriter.getInstance(pdfDocument, outputStream);

        pdfDocument.open();
        pdfDocument.setMargins(offset, offset, offset * 2, offset);

        // първа страница 
        buildFirstPage();

        // поредна страница със таблица в нея 
        documentBean.getDatasets().forEach((k, v) -> v.forEach((d) -> buildDatasetPage(k, d)));

        pdfDocument.close();
    }

}
