/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.xml2pdf;

import bg.crc.xml2pdf.beans.DocumentBean;
import bg.crc.xml2pdf.readers.XmlDocumentReader;
import bg.crc.xml2pdf.writers.PdfDocumentWriter;
import java.awt.Desktop;
import java.io.File;
import java.io.InputStream;

/**
 * примерни файлове
 *
 * @author cstoykov
 */
public class HowTo {

    public static void main(String... args) throws Exception {  
        DocumentBean db;
        // всичките ми примери са последователно номерирани
        // /example.001.xml
        // /example.002.xml
        // ...
        for (int iExample = 1;; iExample++) {
            InputStream is = HowTo.class.getResourceAsStream(String.format("/example.%03d.xml", iExample));
            if (is == null) {
                break;
            }
            // изчитам данните от XML 
            try (InputStream tmp = is) {
                db = new XmlDocumentReader().read(tmp);
            }
            // записвам данните в PDF
            File temp = File.createTempFile("xml2pdf.", ".pdf");
            new PdfDocumentWriter().write(db, temp);
            // отвори PDF
            Desktop.getDesktop().open(temp);
        }
    }
}
