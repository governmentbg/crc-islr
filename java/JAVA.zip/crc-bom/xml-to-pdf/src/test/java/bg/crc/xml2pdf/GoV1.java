package bg.crc.xml2pdf;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;

/**
 * про
 *
 * @author cstoykov
 */
public class GoV1 {

    private static final Logger LOG = Logger.getLogger(GoV1.class.getName());

    // етикет за таблица 
    // [TABLE_DESCRIPTION, <table-name>, ROWSET, ...] 
    protected final Map<String, String> tables = new LinkedHashMap<>();

    // етикет за колона от таблица
    // [COLUMN_DESCRIPTION, <column-name>, TABLE_ROW, <table-name>, ROWSET,...]
    protected final Map<String, Map<String, String>> columns = new LinkedHashMap<>();

    // запис от таблица
    // [COLUMN_VALUE, ID, TABLE_ROW, CO_REQUESTS, ROWSET, ...]
    protected final Map<String, List<Map<String, String>>> datasets = new LinkedHashMap<>();

    // настоящия запис
    protected Map<String, String> record;

    // шрифт с кирилица
    protected BaseFont baseFont;

    {
        try {
            baseFont = BaseFont.createFont("C:/Windows/Fonts/Arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
        } catch (DocumentException | IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    // помощник : почиствам върешните структури
    protected void _clear() {
        this.columns.clear();
        this.datasets.clear();
        this.record = null;
        this.tables.clear();
    }

    // помощник : подреждам на общо основание
    protected List<String> _sort(Collection<String> list) {
        ArrayList<String> temp = new ArrayList<>(list);
        Collections.sort(temp);
        return temp;
    }

    /**
     * чете таблични данни от XML
     *
     * @param xmlReader char-поток
     *
     * @throws IOException грешка в четенето на потока
     * @throws XMLStreamException грешка в четенето на XML
     */
    public void readXml(Reader xmlReader) throws IOException, XMLStreamException {
        _clear();
        // https://docs.oracle.com/cd/E13222_01/wls/docs92/xml/stax.html
        XMLInputFactory factory = XMLInputFactory.newInstance();
        XMLEventReader r = factory.createXMLEventReader(xmlReader);
        LinkedList<String> path = new LinkedList<>();
        while (r.hasNext()) {
            XMLEvent e = r.nextEvent();
            // TODO: пренапиши със switch/case
            if (e.isStartElement()) {
                path.addFirst(e.asStartElement().getName().getLocalPart());
                System.out.println("path = " + path);
//------------------------------------------------------------------------------>>> начало на xml елемент
                if (path.size() >= 2
                        && "ROWSET".equals(path.get(1))) {
                    // path = [CO_REQUESTS, ROWSET, ...]  
                    String table = path.get(0);
                    if (columns.get(table) == null) {
                        columns.put(table, new LinkedHashMap<>());
                        tables.put(table, table);
                        datasets.put(table, new LinkedList<>());
                    }
                } else if (path.size() >= 3
                        && "TABLE_ROW".equals(path.get(0))
                        && "ROWSET".equals(path.get(2))) {
                    // path = [TABLE_ROW, CO_REQUESTS, ROWSET, ...]
                    record = new LinkedHashMap<>();
                } else if (path.size() >= 4
                        && "TABLE_ROW".equals(path.get(1))
                        && "ROWSET".equals(path.get(3))) {
                    // path = [ID, TABLE_ROW, CO_REQUESTS, ROWSET, ...] 
                    String column = path.get(0);
                    String table = path.get(2);
                    if (columns.get(table).get(column) == null) {
                        columns.get(table).put(column, column);
                    }
                }
//------------------------------------------------------------------------------<<< начало на xml елемент
            } else if (e.isCharacters()) {
                if (path.size() >= 3
                        && "TABLE_DESCRIPTION".equals(path.get(0))
                        && "ROWSET".equals(path.get(2))) {
                    // path = [TABLE_DESCRIPTION, CO_REQUESTS, ROWSET, ...]
                    String text = e.asCharacters().getData();
                    String table = path.get(1);
                    String oldText = tables.put(table, text);
                    if (oldText != null && !oldText.equals(text)) {
                        LOG.warning("(?!) table-description(" + table + ") : old = " + oldText + ", new = " + text);
                    }
                } else if (path.size() >= 5
                        && "COLUMN_DESCRIPTION".equals(path.get(0))
                        && "TABLE_ROW".equals(path.get(2))
                        && "ROWSET".equals(path.get(4))) {
                    // path = [COLUMN_DESCRIPTION, ID, TABLE_ROW, CO_REQUESTS, ROWSET, ...]
                    String text = e.asCharacters().getData();
                    String column = path.get(1);
                    String table = path.get(3);
                    String oldValue = columns.get(table).put(column, text);
                    if (oldValue != null && !oldValue.equals(text)) {
                        LOG.warning("(?!) column-description : table = " + table + ", column = " + column + ", old = " + oldValue + ", new = " + text);
                    }
                } else if (path.size() >= 5
                        && "COLUMN_VALUE".equals(path.get(0))
                        && "TABLE_ROW".equals(path.get(2))
                        && "ROWSET".equals(path.get(4))) {
                    // path = [COLUMN_VALUE, ID, TABLE_ROW, CO_REQUESTS, ROWSET, ...]
                    String text = e.asCharacters().getData();
                    String column = path.get(1);
                    String table = path.get(3);
                    record.put(column, text);
                }
            } else if (e.isEndElement()) {
//------------------------------------------------------------------------------>>> край на xml елемент
                if (path.size() >= 3
                        && "TABLE_ROW".equals(path.get(0))
                        && "ROWSET".equals(path.get(2))) {
                    // path = [TABLE_ROW, CO_REQUESTS, ROWSET, ...]
                    String table = path.get(1);
                    datasets.get(table).add(record);
                    record = null;
                }
//------------------------------------------------------------------------------<<< край на xml елемент
                path.removeFirst();
            } else if (e.isEndDocument()) {
                System.out.println("this.tables.size = " + this.tables.size());
                System.out.println("this.tables = " + this.tables);
                System.out.println("this.columns = " + this.columns);
            }
        }
    }

    // помощник : осреднени дължини
    private float[] _withAvg(String tableKey) {
        Map<String, String> columnNames = columns.get(tableKey);
        List<Map<String, String>> dataset = datasets.get(tableKey);
        float[] sum = new float[columnNames.size()];
        float[] count = new float[columnNames.size()];
        // взимам в предвид дължината на етикетите на всяка колона
        {
            int i = 0;
            for (String columnName : columnNames.keySet()) {
                count[i] += 1;
                sum[i] += columnNames.getOrDefault(columnName, "").length();
                i++;
            }
        }
        // взимам в предвид дължината на данните във всяка колоните
        for (Map<String, String> record : dataset) {
            int i = 0;
            for (String columnName : columnNames.keySet()) {
                if (record.getOrDefault(columnName, "").length() > 0) {
                    count[i] += 1;
                    sum[i] += record.getOrDefault(columnName, "").length();
                }
                i++;
            }
        }
        // средно аритметично
        for (int i = 0; i < columnNames.size(); i++) {
            sum[i] = sum[i] / count[i];
        }
        return sum;
    }

    // помощник : осреднени дължини
    private float[] _withMax(String tableKey) {
        Map<String, String> columnNames = columns.get(tableKey);
        List<Map<String, String>> dataset = datasets.get(tableKey);
        float[] max = new float[columnNames.size()];
        // взимам в предвид дължината на етикетите на всяка колона
        {
            int i = 0;
            for (String columnName : columnNames.keySet()) {
                max[i] = columnNames.getOrDefault(columnName, "").length();
                i++;
            }
        }
        // взимам в предвид дължината на данните във всяка колоните
        for (Map<String, String> record : dataset) {
            int i = 0;
            for (String columnName : columnNames.keySet()) {
                max[i] = Math.max(max[i], record.getOrDefault(columnName, "").length());
                i++;
            }
        }
        return max;
    }

    // помощник : осреднени дължини
    private float[] _withMin(String tableKey) {
        Map<String, String> columnNames = columns.get(tableKey);
        List<Map<String, String>> dataset = datasets.get(tableKey);
        float[] min = new float[columnNames.size()];
        // взимам в предвид дължината на етикетите на всяка колона
        {
            int i = 0;
            for (String columnName : columnNames.keySet()) {
                min[i] = columnNames.getOrDefault(columnName, "").length();
                i++;
            }
        }
        // взимам в предвид дължината на данните във всяка колоните
        for (Map<String, String> record : dataset) {
            int i = 0;
            for (String columnName : columnNames.keySet()) {
                min[i] = Math.min(min[i], record.getOrDefault(columnName, "").length());
                i++;
            }
        }
        return min;
    }

    // помощник : строи PDF таблица
    private PdfPTable _pdfTable(String tableKey) throws DocumentException, IOException {
        // http://what-when-how.com/itext-5/dealing-with-large-tables-itext-5/
        // 
        // +-------------------------------------------+
        // |                <table-name>               |
        // +------------------+------------------+-----+
        // | <column-name[0]> | <column-name[1]> | ... |
        // +------------------+------------------+-----+
        // | <record[0][0]>   | <record[0][1]>   | ... |
        // +------------------+------------------+-----+
        // | <record[1][0]>   | <record[1][1]>   | ... |
        // +------------------+------------------+-----+
        // | ...                                       |
        // +------------------+------------------+-----+

        Map<String, String> columnNames = columns.get(tableKey);
        List<Map<String, String>> dataset = datasets.get(tableKey);
        //---------------------------------------------------------
        PdfPTable pdfTable = new PdfPTable(_withAvg(tableKey));
        pdfTable.setSkipLastFooter(true);
        //pdfTable.setTotalWidth(PageSize.A4.rotate().getWidth()-10);
        //pdfTable.setLockedWidth(true);
        pdfTable.setWidthPercentage(100);

        // шрифт за header
        Font headerFont = new Font(baseFont, 8f);
        headerFont.setStyle(Font.BOLD | Font.ITALIC);

        // шрифт за данните
        Font dataFont = new Font(baseFont, 6F);
        dataFont.setStyle(Font.NORMAL);

        // <table-name>
        {
            PdfPCell tableNameCell = new PdfPCell(new Phrase(tables.getOrDefault(tableKey, tableKey), headerFont));
            tableNameCell.setColspan(columnNames.size());
            tableNameCell.setBackgroundColor(BaseColor.GRAY);
            tableNameCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            pdfTable.addCell(tableNameCell);
        }

        //  <column-name[0]>, <column-name[1]>, ...
        for (int i = 0; i < 2; i++) {
            for (String columnKey : columnNames.keySet()) {
                PdfPCell columnNameCell = new PdfPCell(new Phrase(columnNames.getOrDefault(columnKey, columnKey), dataFont));
                columnNameCell.setBackgroundColor(BaseColor.GRAY);
                pdfTable.addCell(columnNameCell);
            }
        }
        pdfTable.setHeaderRows(3);
        pdfTable.setFooterRows(1);

        // <record[i][0]>, <record[i][1]>, ...
        int index = 0;
        for (Map<String, String> record : dataset) {
            for (String columnKey : columnNames.keySet()) {
                PdfPCell recordNameCell = new PdfPCell(new Phrase(record.get(columnKey), dataFont));
                recordNameCell.setBackgroundColor(index % 2 == 0 ? BaseColor.WHITE : BaseColor.LIGHT_GRAY);
                recordNameCell.setNoWrap(false);
                pdfTable.addCell(recordNameCell);
            }
            index += 1;
        }
        return pdfTable;
    }

    /**
     * пише таблични данни в PDF
     *
     * @param pdfOutputStream byte-поток
     * @throws IOException
     * @throws DocumentException
     */
    public void writePdf(OutputStream pdfOutputStream) throws IOException, DocumentException {
        // https://www.baeldung.com/java-pdf-creation 
        // http://www.java2s.com/Code/Java/PDF-RTF/DemonstratesthecreatingPDFinportraitlandscape.htm
        // https://developers.itextpdf.com/question/how-resize-pdfptable-fit-page
        Document pdfDocument = new Document(PageSize.A4);
        PdfWriter.getInstance(pdfDocument, pdfOutputStream);

        Font pdfFont = new Font(baseFont, 16f);
        pdfDocument.open();

        // първа страница
        {
            pdfDocument.setPageSize(PageSize.A4);
            pdfDocument.newPage();
            Chunk chunk = new Chunk("todo : first page", pdfFont);
            pdfDocument.add(chunk);
        }

        pdfDocument.setPageSize(PageSize.A4.rotate());
        pdfDocument.setMargins(10F, 10F, 10F, 10F);
        pdfDocument.newPage();

        // поредна страница със таблица
        for (String table : _sort(tables.keySet())) {
            Chunk chunk = new Chunk(" ", pdfFont);
            pdfDocument.add(chunk);
            pdfDocument.add(_pdfTable(table));
        }
        pdfDocument.close();
    }

    public static void main(String... args) throws Exception {
        GoV1 tmp = new GoV1();
        // изчитам данните от XML
        try (
                InputStream is = GoV1.class.getResourceAsStream("/example.001.xml");
                InputStreamReader isr = new InputStreamReader(is, "utf-8");) {
            tmp.readXml(isr);
        }
        // записвам данните в PDF
        File temp = File.createTempFile("xml2pdf.", ".pdf");
        try (FileOutputStream fos = new FileOutputStream(temp)) {
            tmp.writePdf(fos);
        }
        Desktop.getDesktop().open(temp);
    }
}
