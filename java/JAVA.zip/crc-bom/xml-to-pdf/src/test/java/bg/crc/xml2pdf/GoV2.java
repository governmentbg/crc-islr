/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.xml2pdf;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Map;
import java.util.logging.Logger;

/**
 *
 * @author cstoykov
 */
public class GoV2 extends GoV1 {

    private static final Logger LOG = Logger.getLogger(GoV2.class.getName());

    @Override
    public void writePdf(OutputStream pdfOutputStream) throws IOException, DocumentException {
        // https://www.baeldung.com/java-pdf-creation 
        // http://www.java2s.com/Code/Java/PDF-RTF/DemonstratesthecreatingPDFinportraitlandscape.htm
        // https://developers.itextpdf.com/question/how-resize-pdfptable-fit-page
        Document pdfDocument = new Document(PageSize.A4);
        PdfWriter.getInstance(pdfDocument, pdfOutputStream);

        // шрифт за header
        Font headerFont = new Font(baseFont, 14f);
        headerFont.setStyle(Font.BOLD | Font.ITALIC);

        // шрифт за данните
        Font dataFont = new Font(baseFont, 12F);
        dataFont.setStyle(Font.NORMAL);

        pdfDocument.open();

        // TODO : първа страница 
        pdfDocument.setMargins(30F, 30F, 20F, 30F);
        pdfDocument.newPage();

        // поредна страница със таблица 
        for (String table : tables.keySet()) {
            for (Map<String, String> dataset : datasets.get(table)) {
                PdfPTable pdfTable = new PdfPTable(2);
                // +--------------+
                // | <table-name> |
                // +------+-------+
                // | name | value |
                // +------+-------+
                // <table-name>
                {
                    PdfPCell tableNameCell = new PdfPCell(new Phrase(tables.getOrDefault(table, table), headerFont));
                    tableNameCell.setColspan(2);
                    tableNameCell.setBackgroundColor(BaseColor.GRAY);
                    tableNameCell.setHorizontalAlignment(Element.ALIGN_LEFT);
                    pdfTable.addCell(tableNameCell);
                }
                for (String column : columns.get(table).keySet()) {
                    if (dataset.get(column) == null || dataset.get(column).isEmpty()) {
                        continue;
                    }
                    PdfPCell columnNameCell = new PdfPCell(new Phrase(columns.get(table).getOrDefault(column, column), headerFont));
                    columnNameCell.setBackgroundColor(BaseColor.GRAY);
                    columnNameCell.setHorizontalAlignment(Element.ALIGN_LEFT);
                    pdfTable.addCell(columnNameCell);

                    PdfPCell columnValueCell = new PdfPCell(new Phrase(dataset.get(column), dataFont));
                    columnValueCell.setBackgroundColor(BaseColor.WHITE);
                    columnValueCell.setHorizontalAlignment(Element.ALIGN_LEFT);
                    pdfTable.addCell(columnValueCell);
                }
                // 
                pdfDocument.newPage();
                pdfDocument.add(pdfTable);
                //pdfDocument.add(new Paragraph("Внимание! Показани са само колоните със стойности", pdfFont));
            }

        }

        pdfDocument.close();
    }

    public static void main(String... args) throws Exception {
        GoV2 tmp = new GoV2();
        // изчитам данните от XML 
        try (InputStream is = GoV2.class
                .getResourceAsStream("/example.002.xml");
                InputStreamReader isr = new InputStreamReader(is, "utf-8");) {
            tmp.readXml(isr);
        }
        // записвам данните в PDF
        File temp = File.createTempFile("xml2pdf.", ".pdf");
        try (FileOutputStream fos = new FileOutputStream(temp)) {
            tmp.writePdf(fos);
        }
        Desktop.getDesktop().open(temp);
    }
}
