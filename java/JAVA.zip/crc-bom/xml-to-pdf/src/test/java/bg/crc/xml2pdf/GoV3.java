/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.xml2pdf;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Base64;
import java.util.Map;
import java.util.logging.Logger;
import org.apache.commons.codec.binary.Hex;

/**
 *
 * @author cstoykov
 */
public class GoV3 extends GoV1 {

    private static final Logger LOG = Logger.getLogger(GoV3.class.getName());

    // шрифт за header
    protected Font headerFont = new Font(baseFont, 14f);

    {
        headerFont.setStyle(Font.BOLD | Font.ITALIC);
    }

    // шрифт за данните
    protected Font dataFont = new Font(baseFont, 12F);

    {
        dataFont.setStyle(Font.NORMAL);
    }

    // шрифт за данните
    protected Font noteFont = new Font(baseFont, 10F);

    {
        dataFont.setStyle(Font.ITALIC);
    }

    protected PdfPTable _pdfTableForTable(String table, Map<String, String> dataset) {
        PdfPTable pdfTable = new PdfPTable(2);
        pdfTable.setWidthPercentage(100);
        // +--------------+
        // | <table-name> |
        // +------+-------+
        // | name | value |
        // +------+-------+
        // <table-name>
//        {
//            PdfPCell tableNameCell = new PdfPCell(new Phrase(tables.getOrDefault(table, table), headerFont));
//            tableNameCell.setColspan(2);
//            tableNameCell.setBackgroundColor(BaseColor.LIGHT_GRAY);
//            tableNameCell.setHorizontalAlignment(Element.ALIGN_CENTER);
//            pdfTable.addCell(tableNameCell);
//        }
        for (String column : columns.get(table).keySet()) {
            if (dataset.get(column) == null || dataset.get(column).isEmpty()) {
                continue;
            }
            PdfPCell columnNameCell = new PdfPCell(new Phrase(columns.get(table).getOrDefault(column, column), headerFont));
            columnNameCell.setBackgroundColor(BaseColor.LIGHT_GRAY);
            columnNameCell.setHorizontalAlignment(Element.ALIGN_LEFT);
            pdfTable.addCell(columnNameCell);

            PdfPCell columnValueCell = new PdfPCell(new Phrase(dataset.get(column), dataFont));
            columnValueCell.setBackgroundColor(BaseColor.WHITE);
            columnValueCell.setHorizontalAlignment(Element.ALIGN_LEFT);
            pdfTable.addCell(columnValueCell);
        }
        return pdfTable;
    }

    /**
     * пише таблични данни в PDF
     *
     * @param pdfOutputStream byte-поток
     * @throws IOException
     * @throws DocumentException
     */
    public void writePdf(OutputStream pdfOutputStream) throws IOException, DocumentException {
        // https://www.baeldung.com/java-pdf-creation 
        // http://www.java2s.com/Code/Java/PDF-RTF/DemonstratesthecreatingPDFinportraitlandscape.htm
        // https://developers.itextpdf.com/question/how-resize-pdfptable-fit-page
        float offset = 30;
        Document pdfDocument = new Document(PageSize.A4);
        PdfWriter.getInstance(pdfDocument, pdfOutputStream);

        pdfDocument.open();
        pdfDocument.setMargins(offset, offset, offset * 2, offset);

        // TODO : първа страница 
        {
            pdfDocument.newPage();
            Paragraph tmp = new Paragraph("Разписка", headerFont);
            tmp.setSpacingAfter(20F);
            pdfDocument.add(tmp);
            //tmp = new Paragraph("Уникален идентификатор : " + UUID.randomUUID(), dataFont);
            //tmp.setSpacingAfter(5F);
            //pdfDocument.add(tmp);
            byte[] checksum = (Math.random() + "" + Math.random()).getBytes();
            tmp = new Paragraph("Контролана сума (base64): " + Base64.getEncoder().encodeToString(checksum), dataFont);
            tmp.setSpacingAfter(5F);
            pdfDocument.add(tmp);
            tmp = new Paragraph("Контролана сума (hex): " + Hex.encodeHexString(checksum), dataFont);
            tmp.setSpacingAfter(5F);
            pdfDocument.add(tmp);
            tmp = new Paragraph("(!) Контролана сума е sha256 пресметнато върху контролни суми на приложенията.", noteFont);
            tmp.setSpacingAfter(20F);
            pdfDocument.add(tmp);

            tmp = new Paragraph("Приложения", headerFont);
            tmp.setSpacingAfter(20F);
            pdfDocument.add(tmp);
            int iDataset = 1;
            for (String table : tables.keySet()) {
                for (Map<String, String> dataset : datasets.get(table)) {
                    tmp = new Paragraph(iDataset + ". [" + dataset.get("ID") + "] " + tables.getOrDefault(table, table), dataFont);
                    tmp.setSpacingAfter(5F);
                    pdfDocument.add(tmp);
                    iDataset += 1;
                }
            }
        }

        // поредна страница със таблица 
        int iDataset = 1;
        for (String table : tables.keySet()) {
            for (Map<String, String> dataset : datasets.get(table)) {
                pdfDocument.newPage();
                Paragraph tmp = new Paragraph(iDataset + ". [" + dataset.get("ID") + "] " + tables.getOrDefault(table, table), dataFont);
                tmp.setSpacingAfter(20F);
                pdfDocument.add(tmp);
                pdfDocument.add(_pdfTableForTable(table, dataset));
                byte[] checksum = (Math.random() + "" + Math.random()).getBytes();
                tmp = new Paragraph("Контролана сума (base64): " + Base64.getEncoder().encodeToString(checksum), dataFont);
                tmp.setSpacingAfter(5F);
                tmp.setSpacingBefore(20F);
                pdfDocument.add(tmp);
                tmp = new Paragraph("Контролана сума (hex): " + Hex.encodeHexString(checksum), dataFont);
                tmp.setSpacingAfter(5F);
                pdfDocument.add(tmp);
                tmp = new Paragraph("(!) Контролана сума е sha256 пресметнато върху последователността ключ, стойност, ключ, стойност, ... на приложението разделени с : ~!@#$%^&*()_+.", noteFont);
                tmp.setSpacingAfter(20F);
                pdfDocument.add(tmp);
                iDataset += 1;
            }
        }

        pdfDocument.close();
    }

    public void signPdf() {
        
    }

    public static void main(String... args) throws Exception {
      
    }
}
