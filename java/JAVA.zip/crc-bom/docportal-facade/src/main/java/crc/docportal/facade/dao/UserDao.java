/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crc.docportal.facade.dao;

import java.sql.CallableStatement;
import java.sql.Connection;

/**
 *
 * @author cstoykov
 */
public class UserDao extends BaseDao {

    /**
     * @param user
     * @param pass
     * @return
     */
    public boolean authorize(String user, String pass) {

        try (Connection ora = getDataSource().getConnection()) {
            ora.setAutoCommit(false);
            ora.setReadOnly(true);

            try (CallableStatement callable = ora.prepareCall("begin docportal_ws.authorize(:user, :pass, :authorized); end;")) {
                callable.clearBatch();
                callable.clearParameters();
                callable.clearWarnings();

                callable.setString("user", user);
                callable.setString("pass", pass);
                callable.registerOutParameter("expected", java.sql.Types.VARCHAR);

                callable.execute();

                return "T".equalsIgnoreCase(callable.getString("expected"));
            }
        } catch (Exception e) {
            throw new RuntimeException("failed :"
                    + " user = " + user
                    + ", pass = ...",
                    e);
        }
    }
}
