/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crc.docportal.facade.servlets;

import crc.docportal.facade.AServlet;
import crc.docportal.facade.HttpException;
import crc.docportal.facade.dao.LitigationDao;
import crc.docportal.facade.dao.UserDao;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author cstoykov
 */
@WebServlet(name = "LitigationServlet", urlPatterns = {"/LitigationServlet"})
public class LitigationServlet extends AServlet {

    // 
    private static final Logger LOG = Logger.getLogger(LitigationServlet.class.getName());

    // data-base
    protected LitigationDao litigationDao = new LitigationDao();
    protected UserDao userDao = new UserDao();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String error = "";
        String journal = UUID.randomUUID().toString();
        try {

            error = "basic authorization";
            String user = _authorizationUser(request);
            String pass = _authorizationPass(request);
            userDao.authorize(user, pass);

            error = "operation";
            String operation = _paramMatch(request, "^(litigationNaturalPerson|litigationLegalPerson)$", "operation");

            if ("litigationLegalPerson".equals(operation)) {

                error = "execute litigationLegalPerson";
                // жалбата
                String litigationNo = _paramMatch(request, "^(.+)$", "litigationNo");
                BigDecimal litigationAidaId = new BigDecimal(_paramMatch(request, "^([0-9]+)$", "litigationAidaId"));
                String litigationTopic = _paramMatch(request, "^(.+)$", "litigationTopic");
                String litigationFileLink = _paramMatch(request, "^(.+)$", "litigationFileLink");

                // жалбоподател
                String applicantLegalPersonName = _paramMatch(request, "^(.+)$", "applicantLegalPersonName");
                String applicantLegalEik = _paramMatch(request, "^([0-9]+)$", "applicantLegalEik");

                // предприятие
                String enterpriseName = _paramMatch(request, "^(.+)$", "enterpriseName");
                String enterpriseEik = _paramMatch(request, "^([0-9]+)$", "enterpriseEik");

                litigationDao.litigationLegalPerson(litigationNo, litigationAidaId, litigationTopic, litigationFileLink, applicantLegalPersonName, applicantLegalEik, enterpriseName, enterpriseEik);
            } else if ("litigationNaturalPerson".equals(operation)) {
                error = "execute litigationNaturalPerson";

                // жалбата
                String litigationNo = _paramMatch(request, "^(.+)$", "litigationNo");
                BigDecimal litigationAidaId = new BigDecimal(_paramMatch(request, "^([0-9]+)$", "litigationAidaId"));
                String litigationTopic = _paramMatch(request, "^(.+)$", "litigationTopic");
                String litigationFileLink = _paramMatch(request, "^(.+)$", "litigationFileLink");

                // жалбоподател
                String applicantNaturalPersonName = _paramMatch(request, "^(.+)$", "applicantNaturalPersonName");
                String applicantNaturalPersonEmail = _paramMatch(request, "^(.+)$", "applicantNaturalPersonEmail");
                String applicantNaturalPersonAddress = _paramMatch(request, "^(.+)$", "applicantNaturalPersonAddress");

                // предприятие
                String enterpriseName = _paramMatch(request, "^(.+)$", "enterpriseName");
                String enterpriseEik = _paramMatch(request, "^([0-9]+)$", "enterpriseEik");

                litigationDao.litigationNaturalPerson(litigationNo, litigationAidaId, litigationTopic, litigationFileLink, applicantNaturalPersonName, applicantNaturalPersonEmail, applicantNaturalPersonAddress, enterpriseName, enterpriseEik);
            } else {
                throw new IllegalStateException("bad impl : operation = " + operation);
            }

        } catch (HttpException http) {

            String temp = journal + " : expected : " + error + " : " + http.getMessage();
            LOG.log(Level.WARNING, temp, http);
            response.sendError(http.getHttpStatus(), temp);
        } catch (Exception e) {

            String temp = journal + " : unexpected : " + error;
            LOG.log(Level.SEVERE, temp, e);
            response.sendError(500, temp);
        }
    }

}
