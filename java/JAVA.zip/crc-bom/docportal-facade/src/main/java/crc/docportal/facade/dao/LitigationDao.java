/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crc.docportal.facade.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;

/**
 * @author cstoykov
 */
public class LitigationDao extends BaseDao {

    public static final String LIT_NP_QUERY
            = "begin\n"
            + "    DOCPORTAL_WS.lit_np(\n"
            + "        :lit_no\n"
            + "        ,:lit_aidaid\n"
            + "        ,:lit_topic\n"
            + "        ,:lit_filelink\n"
            + "        ,:appl_np_name\n"
            + "        ,:appl_np_email\n"
            + "        ,:appl_np_address\n"
            + "        ,:enterp_name\n"
            + "        ,:enterp_eik\n"
            + "        ,:expected"
            + "    );\n"
            + "end;";

    public static final String LIT_LP_QUERY
            = "begin\n"
            + "    DOCPORTAL_WS.lit_lp(\n"
            + "        :lit_no\n"
            + "        ,:lit_aidaid\n"
            + "        ,:lit_topic\n"
            + "        ,:lit_filelink\n"
            + "        ,:appl_lp_name\n"
            + "        ,:appl_lp_eik\n"
            + "        ,:enterp_name\n"
            + "        ,:enterp_eik\n"
            + "        ,:expected\n"
            + "    );\n"
            + "end;";

    /**
     * litigation from natural-person
     *
     * @param litigationNo
     * @param litigationAidaId
     * @param litigationTopic
     * @param litigationFileLink
     * @param applicantNaturalPersonName
     * @param applicantNaturalPersonEmail
     * @param applicantNaturalPersonAddress
     * @param enterpriseName
     * @param enterpriseEik
     *
     * @throws IllegalArgumentException
     */
    public void litigationNaturalPerson(
            // жалбата
            String litigationNo,
            BigDecimal litigationAidaId,
            String litigationTopic,
            String litigationFileLink,
            // жалбоподател
            String applicantNaturalPersonName,
            String applicantNaturalPersonEmail,
            String applicantNaturalPersonAddress,
            // предприятие
            String enterpriseName,
            String enterpriseEik
    ) throws IllegalArgumentException {
        String expectedError = null;
        try (Connection ora = getDataSource().getConnection()) {
            ora.setAutoCommit(false);
            ora.setReadOnly(true);

            try (CallableStatement callable = ora.prepareCall(LIT_NP_QUERY)) {
                callable.clearBatch();
                callable.clearParameters();
                callable.clearWarnings();

                // жалбата\n"
                //        :lit_no -- varchar2,       -- жалба/вх.№ String(50)\n"
                callable.setString("lit_no", litigationNo);
                //        :lit_aidaid -- number,     -- жалба/ID от АИДА Integer\n"
                callable.setBigDecimal("lit_aidaid", litigationAidaId);
                //        :lit_topic -- varchar2,    -- жалба/тема на жалбата String(200)\n"
                callable.setString("lit_topic", litigationTopic);
                //        :lit_filelink -- varchar2, -- жалба/линк към преписката String(1000) \n"
                callable.setString("lit_filelink", litigationFileLink);
                //        -- жалбоподател\n"
                //        :appl_np_name -- varchar2,    -- жалбоподател/физическо лице/имена String(200)\n"
                callable.setString("appl_np_name", applicantNaturalPersonName);
                //        :appl_np_email -- varchar2,   -- жалбоподател/физическо лице/е-мейл String(200)\n"
                callable.setString("appl_np_email", applicantNaturalPersonEmail);
                //        :appl_np_address -- varchar2, -- жалбоподател/физическо лице/адрес String(200)\n"
                callable.setString("appl_np_address", applicantNaturalPersonAddress);
                //        -- предприятие\n"
                //        :enterp_name -- varchar2, -- данни за предприятие (доставчик на услуги)/наименование String(200)\n"
                callable.setString("enterp_name", enterpriseName);
                //        :enterp_eik -- varchar2,  -- данни за предприятие (доставчик на услуги)/ЕИК/Булстат String(20)\n"
                callable.setString("enterp_eik", enterpriseEik);
                //        -- грешки\n"
                //        :expected -- out varchar2\n"
                callable.registerOutParameter("expected", java.sql.Types.VARCHAR);

                callable.execute();

                expectedError = callable.getString("expected");

            }

            ora.commit();
        } catch (Exception e) {
            throw new RuntimeException("failed :"
                    + " litigationNo = " + litigationNo
                    + ", litigationAidaId = " + litigationAidaId
                    + ", litigationTopic = " + litigationTopic
                    + ", litigationFileLink = " + litigationFileLink
                    + ", applicantNaturalPersonName = " + applicantNaturalPersonName
                    + ", applicantNaturalPersonEmail = " + applicantNaturalPersonEmail
                    + ", applicantNaturalPersonAddress = " + applicantNaturalPersonAddress
                    + ", enterpriseName = " + enterpriseName
                    + ", enterpriseEik = " + enterpriseEik,
                    e);
        }

        // очакван проблем
        if (expectedError != null && !expectedError.trim().isEmpty()) {
            throw new IllegalArgumentException(expectedError);
        }
    }

    /**
     * litigation from legal-person
     *
     * @param litigationNo
     * @param litigationAidaId
     * @param litigationTopic
     * @param litigationFileLink
     * @param applicantLegalPersonName
     * @param applicantLegalEik
     * @param enterpriseName
     * @param enterpriseEik
     * @throws IllegalArgumentException
     */
    public void litigationLegalPerson(
            // жалбата
            String litigationNo,
            BigDecimal litigationAidaId,
            String litigationTopic,
            String litigationFileLink,
            // жалбоподател
            String applicantLegalPersonName,
            String applicantLegalEik,
            // предприятие
            String enterpriseName,
            String enterpriseEik
    ) throws IllegalArgumentException {
        String expectedError = null;
        try (Connection ora = getDataSource().getConnection()) {
            ora.setAutoCommit(false);
            ora.setReadOnly(true);

            try (CallableStatement callable = ora.prepareCall(LIT_LP_QUERY)) {
                callable.clearBatch();
                callable.clearParameters();
                callable.clearWarnings();

                // жалбата\n"
                //        :lit_no -- varchar2,       -- жалба/вх.№ String(50)\n"
                callable.setString("lit_no", litigationNo);
                //        :lit_aidaid -- number,     -- жалба/ID от АИДА Integer\n"
                callable.setBigDecimal("lit_aidaid", litigationAidaId);
                //        :lit_topic -- varchar2,    -- жалба/тема на жалбата String(200)\n"
                callable.setString("lit_topic", litigationTopic);
                //        :lit_filelink -- varchar2, -- жалба/линк към преписката String(1000) \n"
                callable.setString("lit_filelink", litigationFileLink);
                //        -- жалбоподател\n"
                //        :appl_lp_name -- varchar2, -- жалбоподател/юридическо лице/наименование String(200)\n"
                callable.setString("appl_lp_name", applicantLegalPersonName);
                //        :appl_lp_eik -- varchar2,  -- жалбоподател/юридическо лице/ЕИК/Булстат String(20)\n"
                callable.setString("appl_lp_eik", applicantLegalEik);
                //        -- предприятие\n"
                //        :enterp_name -- varchar2, -- данни за предприятие (доставчик на услуги)/наименование String(200)\n"
                callable.setString("enterp_name", enterpriseName);
                //        :enterp_eik -- varchar2,  -- данни за предприятие (доставчик на услуги)/ЕИК/Булстат String(20)\n"
                callable.setString("enterp_eik", enterpriseEik);
                //        -- грешки\n"
                //        :expected -- out varchar2\n"
                callable.registerOutParameter("expected", java.sql.Types.VARCHAR);

                callable.execute();

                expectedError = callable.getString("expected");

            }

            ora.commit();
        } catch (Exception e) {
            throw new RuntimeException("failed :"
                    + " litigationNo = " + litigationNo
                    + ", litigationAidaId = " + litigationAidaId
                    + ", litigationTopic = " + litigationTopic
                    + ", litigationFileLink = " + litigationFileLink
                    + ", applicantLegalPersonName = " + applicantLegalPersonName
                    + ", applicantLegalEik = " + applicantLegalEik
                    + ", enterpriseName = " + enterpriseName
                    + ", enterpriseEik = " + enterpriseEik,
                    e);
        }

        // очакван проблем
        if (expectedError != null && !expectedError.trim().isEmpty()) {
            throw new IllegalArgumentException(expectedError);
        }
    }
}
