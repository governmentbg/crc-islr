/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crc.docportal.facade.dao;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

/**
 * достъп до DataSource
 *
 * @author cstoykov
 */
public class BaseDao {

    // 
    protected DataSource dataSource;

    /**
     * lazy load for DataSource
     *
     * @return DataSource
     */
    protected DataSource getDataSource() {
        if (dataSource == null) {
            String path = "java:comp/env/jdbc/facade";
            try {
                Context initContext = new InitialContext();
                dataSource = (DataSource) initContext.lookup(path);
            } catch (Exception e) {
                throw new RuntimeException("failed : path = " + path, e);
            }
        }
        return dataSource;
    }

}
