/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crc.docportal.facade;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Base64;
import java.util.Random;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.text.StringEscapeUtils;

/**
 *
 * @author cstoykov
 */
public class AServlet extends HttpServlet {

    public static final String PATERN_BASICAUTH = "Basic ([A-Za-z0-9+/]{4})*([A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?";
    public static final Charset CHARSET_UTF8 = Charset.forName("utf-8");

    protected Random _random = new Random();

    // помощник : parameter[name] != null
    protected String _paramNotNull(HttpServletRequest request, String name) {
        String temp = request.getParameter(name);
        if (temp == null) {
            throw new HttpException(400, "bad parameter[" + name + "] : null");
        }
        return temp;
    }

    // помощник : parameter[name] like /.../
    protected String _paramMatch(HttpServletRequest request, String pattern, String name) {
        String temp = request.getParameter(name);
        if (temp == null) {
            throw new HttpException(400, "bad parameter[" + name + "] : null");
        }
        if (!temp.matches(pattern)) {
            throw new HttpException(400, "bad parameter[" + name + "] : not matching pattern /" + pattern + "/");
        }
        return temp;
    }

    // помощник :  url(parameter[name])
    protected URL _paramUrl(HttpServletRequest request, String name) {
        String temp = request.getParameter(name);
        if (temp != null) {
            try {
                return new URL(temp);
            } catch (MalformedURLException ex) {
                throw new HttpException(400, "bad parameter[" + name + "] : not an url", ex);
            }
        }
        return null;
    }

    // помощник :  header[name] != null
    protected String _headerNotNull(HttpServletRequest request, String name) {
        String temp = request.getHeader(name);
        if (temp == null) {
            throw new HttpException(400, "bad header[" + name + "] : null");
        }
        return null;
    }

    // помощник : parameter[name] like /.../
    protected String _headerMatch(HttpServletRequest request, String pattern, String name) {
        String temp = request.getHeader(name);
        if (request.getParameter(name) != null && !request.getParameter(name).matches(pattern)) {
            throw new HttpException(400, "bad header[" + name + "] : not matching pattern /" + pattern + "/");
        }
        return temp;
    }

    // помощник : user
    protected String _authorizationUser(HttpServletRequest request) {
        String test = request.getHeader("Authorization");
        String result = null;
        if (test != null && test.matches(PATERN_BASICAUTH)) {
            String temp = test.replace("Basic ", "");
            temp = new String(Base64.getDecoder().decode(temp), CHARSET_UTF8);
            String[] parts = temp.split("[:]", 2);
            result = parts[0];
        }
        return result;
    }

    // помощник : pass
    protected String _authorizationPass(HttpServletRequest request) {
        String test = request.getHeader("Authorization");
        String result = null;
        if (test != null && test.matches(PATERN_BASICAUTH)) {
            String temp = test.replace("Basic ", "");
            temp = new String(Base64.getDecoder().decode(temp), CHARSET_UTF8);
            String[] parts = temp.split("[:]", 2);
            result = parts[1];
        }
        return result;
    }

    // помощник : 
    protected String _logEscape(String test) {
        return test == null ? "null" : StringEscapeUtils.escapeJava(test);
    }

    /**
     * детаилно описание на грешката
     *
     * @param thr
     * @return
     */
    protected String _throwable(Throwable thr) {
        StringWriter sw = new StringWriter();
        thr.printStackTrace(new PrintWriter(sw, true));
        return sw.toString();
    }

}
