/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crc.docportal.facade;

import crc.docportal.facade.dao.LitigationDao;
import java.math.BigDecimal;
import java.sql.DriverManager;
import javax.sql.DataSource;
import org.apache.commons.dbcp2.BasicDataSource;

/**
 * работи ли?
 *
 * @author cstoykov
 */
public class DaoLitigationTest extends LitigationDao {

    @Override
    protected DataSource getDataSource() {
        if (dataSource == null) {
            try {
                DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
                BasicDataSource temp = new BasicDataSource();
                temp.setDriverClassName("oracle.jdbc.driver.OracleDriver");
                temp.setUrl("jdbc:oracle:thin:@172.16.33.50:1521:crclrn");
                temp.setUsername("crc");
                temp.setPassword("crc");
                dataSource = temp;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return dataSource;
    }

    public void testLitigationNaturalPerson() {
        String litigationNo = "No123";
        BigDecimal litigationAidaId = new BigDecimal("123");
        String litigationTopic = "Litigation Topic";
        String litigationFileLink = "http://localhost/crc/file=" + litigationNo;
        String applicantNaturalPersonName = "Ivan Ivanov";
        String applicantNaturalPersonEmail = "iivanov@abv.bg";
        String applicantNaturalPersonAddress = "Sofia, Mladost 3, 323, B, 17";
        String enterpriseName = "HAHA EOOD";
        String enterpriseEik = "123456789";
        new DaoLitigationTest().litigationNaturalPerson(
                litigationNo,
                litigationAidaId,
                litigationTopic,
                litigationFileLink,
                applicantNaturalPersonName,
                applicantNaturalPersonEmail,
                applicantNaturalPersonAddress,
                enterpriseName,
                enterpriseEik
        );
    }

    public void testLitigationLegalPerson() {
        String litigationNo = "No123";
        BigDecimal litigationAidaId = new BigDecimal("123");
        String litigationTopic = "Litigation Topic";
        String litigationFileLink = "http://localhost/crc/file=" + litigationNo;
        String applicantLegalPersonName = "OHOH EAD";
        String applicantLegalEik = "234567891";
        String enterpriseName = "HAHA EOOD";
        String enterpriseEik = "123456789";
        new DaoLitigationTest().litigationLegalPerson(litigationNo, litigationAidaId, litigationTopic, litigationFileLink, applicantLegalPersonName, applicantLegalEik, enterpriseName, enterpriseEik);
    }

    public static void main(String... args) throws Exception {
        new DaoLitigationTest().testLitigationLegalPerson();
        new DaoLitigationTest().testLitigationNaturalPerson();
    }

}
