/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.pdfsign;

import bg.crc.pdfsign.sign.PdfSigner;
import java.awt.Desktop;
import java.io.File;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.Enumeration;
import lombok.extern.java.Log;

/**
 * как се ползва PdfSigner
 *
 * @author cstoykov
 */
@Log
public class DemoSignPdf {

    public static void main(String... args) throws Exception {
        KeyStore ks = KeyStore.getInstance("Windows-MY");
        ks.load(null, null);
        Enumeration en = ks.aliases();
        while (en.hasMoreElements()) {
            String aliasKey = (String) en.nextElement();
            Certificate c = ks.getCertificate(aliasKey);
            System.out.println("---> alias : " + aliasKey);
            if (ks.isKeyEntry(aliasKey)) {
                Certificate[] chain = ks.getCertificateChain(aliasKey);
                System.out.println("\t---> chain length: " + chain.length);
                for (Certificate cert : chain) {
                    X509Certificate x509 = (X509Certificate) cert;
                    System.out.println("\t" + x509.getSubjectDN());
                    System.out.println("\t" + x509.getSubjectDN());
                }
                if (aliasKey.equals("Canko Stoyanov Stoykov")) {
                    File tempFolder = new File(System.getProperty("java.io.tmpdir"));
                    File input = new File("C:\\Users\\cstoykov\\Desktop\\Крум Стойков 01.09.20021.pdf");
                    File ouput = new File("C:\\Users\\cstoykov\\Desktop\\Крум Стойков 01.09.20021." + System.currentTimeMillis() + ".pdf");
                    PdfSigner pdfs = new PdfSigner().signature("dbid").tempFolder(tempFolder);

                    pdfs.sign(input, ouput, (KeyStore.PrivateKeyEntry) ks.getEntry(aliasKey, new KeyStore.PasswordProtection("logged-user's-pass".toCharArray())));

                    Desktop.getDesktop().open(ouput);
                }
            }
        }

    }
}
