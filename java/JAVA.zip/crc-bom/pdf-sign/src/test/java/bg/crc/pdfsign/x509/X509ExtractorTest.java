/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.pdfsign.x509;

import bg.crc.pdfsign.PdfSignerTest;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.cert.Certificate;
import java.util.List;
import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Test;

/**
 *
 * @author cstoykov
 */
public class X509ExtractorTest {

    @Test
    public void testPdfCertificate_File_01() throws Exception {
        File input = File.createTempFile(getClass().getName() + ".", ".pdf");
        try {
            try (InputStream is = PdfSignerTest.class.getResourceAsStream("/Pdf02.pdf")) {
                try (OutputStream os = new FileOutputStream(input)) {
                    IOUtils.copy(is, os);
                }
            }
            List<Certificate> temp = X509Extractor.pdfCertificate(input);
            Assert.assertTrue(temp.size() == 1);
        } finally {
            input.delete();
        }
    }
    
        @Test
    public void testPdfCertificate_File_02() throws Exception {
        File input = File.createTempFile(getClass().getName() + ".", ".pdf");
        try {
            try (InputStream is = PdfSignerTest.class.getResourceAsStream("/Pdf03.pdf")) {
                try (OutputStream os = new FileOutputStream(input)) {
                    IOUtils.copy(is, os);
                }
            }
            List<Certificate> temp = X509Extractor.pdfCertificate(input);
            Assert.assertTrue(temp.size() == 2);
        } finally {
            input.delete();
        }
    }
}
