/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.pdfsign;

import bg.crc.pdfsign.p12.P12Wrapper;
import bg.crc.pdfsign.sign.PdfSigner;
import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import lombok.extern.java.Log;
import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Test;

/**
 * как се ползва PdfSigner
 *
 * @author cstoykov
 */
@Log
public class PdfSignerTest {

    @Test
    public void test_sign() throws Exception {
        File input = File.createTempFile(getClass().getName() + ".", ".pdf");
        File output = File.createTempFile(getClass().getName() + ".", ".pdf");
        try {
            try (InputStream is = PdfSignerTest.class.getResourceAsStream("/Pdf01.pdf")) {
                try (OutputStream os = new FileOutputStream(input)) {
                    IOUtils.copy(is, os);
                }
            }
            new PdfSigner().sign(input, output, P12Wrapper.DEFALT.privateKeyEntry("a1", (message) -> P12Wrapper.DEFALT_PASS.toCharArray()));
            Assert.assertTrue(output.exists());
            Assert.assertTrue(output.length() >= input.length());
        } finally {
            input.delete();
            output.delete();
        }
    }
    
    @Test
    public void test_x509() throws Exception {
        File input = File.createTempFile(getClass().getName() + ".", ".pdf");
        File output = File.createTempFile(getClass().getName() + ".", ".pdf");
        try {
            try (InputStream is = PdfSignerTest.class.getResourceAsStream("/Pdf02.pdf")) {
                try (OutputStream os = new FileOutputStream(input)) {
                    IOUtils.copy(is, os);
                }
            }
            new PdfSigner().sign(input, output, P12Wrapper.DEFALT.privateKeyEntry("a1", (message) -> P12Wrapper.DEFALT_PASS.toCharArray()));
            Assert.assertTrue(output.exists());
            Assert.assertTrue(output.length() >= input.length());
        } finally {
            input.delete();
            output.delete();
        }
    }

    public static void main(String... args) throws Exception {
        File tempFolder = new File(System.getProperty("java.io.tmpdir"));
        tempFolder = new File(tempFolder, "HowToPdfSigner");
        tempFolder = new File(tempFolder, "" + System.currentTimeMillis());
        tempFolder.mkdirs();

        File input = new File(tempFolder, "input.pdf");
        try (InputStream is = PdfSignerTest.class.getResourceAsStream("/Pdf01.pdf")) {
            try (OutputStream os = new FileOutputStream(input)) {
                IOUtils.copy(is, os);
            }
        }

        File ouput = new File(tempFolder, "output.pdf");
        PdfSigner pdfs = new PdfSigner().tempFolder(tempFolder);

        pdfs.sign(input, ouput, P12Wrapper.DEFALT.privateKeyEntry("a1", (message) -> "12345".toCharArray()));

        Desktop.getDesktop().open(ouput);
    }
}
