/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.pdfsign;

import java.security.Provider;
import java.security.Provider.Service;
import java.security.Security;

/**
 * Как да проверим, какви алгоритни имаме за хеширане?
 *
 * @author cstoykov
 */
public class DemoMessageDigestAlgo {

    public static void main(String... args) throws Exception {
        MyProvider.init();
        Provider[] providers = Security.getProviders();
        for (Provider provider : providers) {
            for (Service service : provider.getServices()) {
                if ("MessageDigest".equals(service.getType())) {
                    System.out.printf("%s,%s,%s\n", provider.getName(), service.getType(), service.getAlgorithm());
                }
            }
        }
    }
}
