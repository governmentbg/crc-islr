/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.pdfsign;

import bg.crc.pdfsign.p12.P12Wrapper;
import bg.crc.pdfsign.sign.PdfSigner;
import bg.crc.pdfsign.x509.X509Extractor;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.cert.Certificate;
import java.util.List;
import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Test;

/**
 *
 * @author cstoykov
 */
public class X509ExtractorTest {

    @Test
    public void test_pdfCertificate() throws Exception {
        File input = File.createTempFile(getClass().getName() + ".", ".pdf");
        File output = File.createTempFile(getClass().getName() + ".", ".pdf");
        try {
            try (InputStream is = PdfSignerTest.class.getResourceAsStream("/Pdf01.pdf")) {
                try (OutputStream os = new FileOutputStream(input)) {
                    IOUtils.copy(is, os);
                }
            }
            new PdfSigner().sign(input, output, P12Wrapper.DEFALT.privateKeyEntry("a1", (message) -> P12Wrapper.DEFALT_PASS.toCharArray()));

            List<Certificate> certificateList = X509Extractor.pdfCertificate(output);
            Assert.assertTrue(certificateList.size() > 0);
        } finally {
            input.delete();
            output.delete();
        }
    }

}
