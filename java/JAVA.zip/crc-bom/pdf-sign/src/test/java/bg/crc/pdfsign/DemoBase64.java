/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.pdfsign;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author cstoykov
 */
public class DemoBase64 {

    public static void main(String... args) throws Exception {
        String str = "Разписка\n"
                + "Контролана сума (base64): {ipc4QnzYceLxuxq96Im/clxDPiY=}\n"
                + "Приложения\n"
                + "1. [3066] Заявление\n"
                + "2. [727] Радиомрежи P to P\n"
                + "3. [728] Радиомрежи P to P\n"
                + "4. [730] Радиомрежи P to P\n"
                + "5. [4268] Данни за предприятия от заявленията/уведомленията\n"
                + "6. [4084] Представляващи от заявленията/уведомленията\n"
                + "7. [4085] Представляващи от заявленията/уведомленията\n"
                + "8. [4086] Представляващи от заявленията/уведомленията\n"
                + "9. [3142] Лица за контакт от заявленията/уведомленията"; //Extracting the content from a particular page.
        Matcher matcher = Pattern.compile("[{](?<base64>(([A-Za-z0-9+/]{4})*(([A-Za-z0-9+/]{2}==)|([A-Za-z0-9+/]{3}=))?))[}]").matcher(str);
        if (matcher.find()) {
            System.out.println(matcher.group("base64"));
        }
    }
}
