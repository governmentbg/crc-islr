/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.pdfsign;

import bg.crc.pdfsign.p12.P12Wrapper;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.KeyStore;
import java.util.Arrays;
import java.util.logging.Level;
import lombok.extern.java.Log;
import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * как се ползва P12Wrapper
 *
 * @author cstoykov
 */
@Log
public class P12WrapperTest {

    private File keystoreFile;

    @Before
    public void before_test() throws Exception {
        keystoreFile = File.createTempFile(getClass().getName() + ".", ".p12");
        try (InputStream input = P12Wrapper.class.getResourceAsStream(P12Wrapper.DEFALT_P12);
                OutputStream output = new FileOutputStream(keystoreFile)) {
            IOUtils.copy(input, output);
        }
    }

    @After
    public void after_test() throws Exception {
        if (keystoreFile != null) {
            keystoreFile.delete();
        }
    }

    @Test
    public void test_keystore() throws Exception {
        try (FileInputStream fis = new FileInputStream(keystoreFile)) {
            P12Wrapper.keystore(fis, (message) -> P12Wrapper.DEFALT_PASS.toCharArray());
        }
    }

    @Test
    public void test_aliasSet() throws Exception {
        P12Wrapper temp;
        try (FileInputStream fis = new FileInputStream(keystoreFile)) {
            temp = P12Wrapper.keystore(fis, (message) -> P12Wrapper.DEFALT_PASS.toCharArray());
        }
        Assert.assertEquals(Arrays.asList("a1").toString(), temp.aliasSet().toString());
    }

    @Test
    public void test_privateKeyEntry() throws Exception {
        P12Wrapper temp;
        try (FileInputStream fis = new FileInputStream(keystoreFile)) {
            temp = P12Wrapper.keystore(fis, (message) -> P12Wrapper.DEFALT_PASS.toCharArray());
        }
        Assert.assertNotNull(temp.privateKeyEntry("a1", null));
    }

    public static void main(String... args) throws Exception {
        log.log(Level.INFO, "alias = {0}", P12Wrapper.DEFALT.aliasSet());
        // alias = [a1]
        KeyStore.PrivateKeyEntry pke = P12Wrapper.DEFALT.privateKeyEntry("a1", null);
        log.log(Level.INFO, "pke.certificate.type = {0}", pke.getCertificate().getType());
        log.log(Level.INFO, "pke.private-key.algorithm = {0}", pke.getPrivateKey().getAlgorithm());
    }
}
