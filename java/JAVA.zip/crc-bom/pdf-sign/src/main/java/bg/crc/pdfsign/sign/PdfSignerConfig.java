/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.pdfsign.sign;

import java.awt.Dimension;
import java.awt.Point;
import java.io.File;
import lombok.Data;
import lombok.ToString;

/**
 * конфигурация за подписване
 */
@Data
@ToString
public class PdfSignerConfig {

    /**
     * страница на която да се появи подписа
     */
    int pageNumber = 1;
    /**
     * горна лява точка за подписа
     */
    Point topLeftPoint = new Point(20, 580);
    /**
     * размер на правоъгълника с подписа
     */
    Dimension dimension = new Dimension(100, 50);
    /**
     * текст за показване върху четириъгулника с подписа
     */
    String signature;
    /**
     * папка за буфериране
     */
    private File tempFolder;
}
