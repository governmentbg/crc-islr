/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.pdfsign.x509;

import bg.crc.pdfsign.MyProvider;
import com.itextpdf.text.pdf.AcroFields;
import com.itextpdf.text.pdf.PdfPKCS7;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.Principal;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.extern.java.Log;

/**
 *
 * @author cstoykov
 */
@Log
public class X509Extractor {

    static {
        MyProvider.init();
    }

    /**
     *
     * @param is
     * @return
     */
    public static String pdfCheckSum(InputStream is) {
        String result = null;
        try {
            PdfReader reader = new PdfReader(is);
            int n = reader.getNumberOfPages();
            String str = PdfTextExtractor.getTextFromPage(reader, 1); //Extracting the content from a particular page.
            // ([A-Za-z0-9+/]{4})*(([A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?
            Matcher matcher = Pattern.compile("[{](?<base64>(([A-Za-z0-9+/]{4})*(([A-Za-z0-9+/]{2}==)|([A-Za-z0-9+/]{3}=))?))[}]").matcher(str);
            if (matcher.find()) {
                result = matcher.group("base64");
            }
            reader.close();
        } catch (Exception ex) {
            // проблем
            throw new RuntimeException(String.format("pdf(%s) to x509", is), ex);
        }
        return result;
    }

    /**
     *
     * @param pdfFile
     * @return
     */
    public static String pdfCheckSum(File pdfFile) {
        try (FileInputStream fis = new FileInputStream(pdfFile)) {
            return pdfCheckSum(fis);
        } catch (Exception ex) {
            // проблем
            throw new RuntimeException(String.format("pdf(%s) to x509", pdfFile), ex);
        }
    }

    /**
     * изважда сертификат от pdf
     *
     * @param is
     * @return
     */
    public static List<Certificate> pdfCertificate(InputStream is) {
        UUID journal = UUID.randomUUID();
        // log.fine(String.format("%s : start", journal));
        // log.fine(String.format("%s : input.is = %s", journal, is));
        List<Certificate> result = new LinkedList<>();
        try {
            PdfReader reader = new PdfReader(is);
            // log.fine(String.format("%s : reader = %s", journal, reader));

            boolean valid = false;
            AcroFields form = reader.getAcroFields();
            // log.fine(String.format("%s : form = %s", journal, form));
            for (String key : form.getSignatureNames()) {
                // log.fine(String.format("%s : signature.name = %s", journal, key));
                // log.fine(String.format("%s : signature.whole-document = %s", journal, form.signatureCoversWholeDocument(key)));

                // интересуват ме подписи върху целия документ
                 if (form.signatureCoversWholeDocument(key))
                {
                    PdfPKCS7 pkcs7 = form.verifySignature(key);
                    valid = pkcs7.verify();
                    // log.fine(String.format("%s : pkcs7.valid = %s", journal, valid));
                    String reason = pkcs7.getReason();
                    // log.fine(String.format("%s : pkcs7.reason = %s", journal, reason));
                    Calendar signedAt = pkcs7.getSignDate();
                    // log.fine(String.format("%s : pkcs7.signDate = %s", journal, signedAt));
                    X509Certificate signingCertificate = pkcs7.getSigningCertificate();
                    result.add(signingCertificate);
                    Principal issuerDN = signingCertificate.getIssuerDN();
                    // log.fine(String.format("%s : x509.issuerDN = %s", journal, issuerDN));
                    Principal subjectDN = signingCertificate.getSubjectDN();
                    // log.fine(String.format("%s : x509.subjectDN = %s", journal, subjectDN));
                } //end if    
            } //end for

        } catch (Exception ex) {
            // проблем
            throw new RuntimeException(String.format("pdf(%s) to x509", is), ex);
        }
        return result;
    }

    /**
     * изважда сертификат от pdf
     *
     * @param pdfFile
     * @return
     */
    public static List<Certificate> pdfCertificate(File pdfFile) {
        try (FileInputStream fis = new FileInputStream(pdfFile)) {
            return pdfCertificate(fis);
        } catch (Exception ex) {
            // проблем
            throw new RuntimeException(String.format("pdf(%s) to x509", pdfFile), ex);
        }
    }

    private X509Extractor() {
    }

}
