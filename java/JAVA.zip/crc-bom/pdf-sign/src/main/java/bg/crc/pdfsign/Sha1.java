/* 
 * 
 *  TITLE: Sha1 
 *  PACKAGE: com.technologica.Sha1
 * 
 *  LIMITATIONS/CONSTRAINTS:
 * 
 *  Author: cstoykov@technologica.com 
 * 
 *  TechnoLogica Ltd. All rights reserved.
 */
package bg.crc.pdfsign;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.cert.Certificate;

/**
 * Пресмятане на Sha1
 *
 * @author cstoykov (tsani_san@abv.bg)
 */
public class Sha1 {

    /**
     * @param file за хеширане
     * @return hex(sha1(_))
     */
    public static String digest(File file) {
        try (FileInputStream fis = new FileInputStream(file)) {
            MessageDigest mDigest = MessageDigest.getInstance("SHA1");
            int BYTE;
            while ((BYTE = fis.read()) != -1) {
                mDigest.update((byte) BYTE);
            }
            return hexify(mDigest.digest());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * @param text за хеширане
     * @return hex(sha1(_))
     */
    public static String digest(String text) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] der = text.getBytes(Charset.forName("utf-8"));
            md.update(der);
            byte[] digest = md.digest();
            return hexify(digest);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * @param cert за хеширане
     * @return hex(sha1(_))
     */
    public static String digest(Certificate cert) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] der = cert.getEncoded();
            md.update(der);
            byte[] digest = md.digest();
            return hexify(digest);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * @param bytes за кодиране
     * @return 16-ично цисло еквивалент на byte-овете
     */
    public static String hexify(byte[] bytes) {
        // застраховка
        if (bytes == null) {
            bytes = new byte[0];
        }

        // цифрите в 16-ична система
        char[] hexDigits = {'0', '1', '2', '3', '4', '5', '6', '7',
            '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

        // един byte дава две цифри в 16-ична
        StringBuilder buf = new StringBuilder(bytes.length * 2);

        for (int i = 0; i < bytes.length; ++i) {
            buf.append(hexDigits[(bytes[i] & 0xf0) >> 4]);
            buf.append(hexDigits[bytes[i] & 0x0f]);
        }

        return buf.toString();
    }

    /**
     * @param input за хеширане
     * @return hex(sha1(_))
     */
    public static byte[] digest(byte[] input) {
        MessageDigest mDigest;
        try {
            mDigest = MessageDigest.getInstance("SHA1");
        } catch (NoSuchAlgorithmException ex) {
            throw new RuntimeException(" failed to load 'sha1' ", ex);
        }

        return mDigest.digest(input);
    }

    /**
     * @param input за хеширане
     * @return hex(sha1(_))
     */
    public static byte[] digest(InputStream input) {
        MessageDigest mDigest;
        try {
            mDigest = MessageDigest.getInstance("SHA1");
        } catch (NoSuchAlgorithmException ex) {
            throw new RuntimeException("failed to load 'sha1' ", ex);
        }

        int BYTE;
        try {
            while ((BYTE = input.read()) != -1) {
                mDigest.update((byte) BYTE);
            }
        } catch (IOException ex) {
            throw new RuntimeException(" stream io ", ex);
        }

        return mDigest.digest();
    }

//    public static void main(String[] args) {
//        String bad = "‎2d 3f 97 02 9c a2 e6 1f bf 0a e0 83 4b 5e 40 02 60 0f 79 53"; 
//        String good = bad.replaceAll("[^0-9a-fA-F ]", "");
//        String test = bad.replaceAll("\\u200E","");//"\\p{C}+"
//        //------------------------------
//        System.out.printf("bad  = %128s\n", hexify(bad.getBytes(Charset.forName("utf-8")))); 
//        System.out.printf("good = %128s\n", hexify(good.getBytes(Charset.forName("utf-8"))));
//        System.out.printf("test = %128s\n", hexify(test.getBytes(Charset.forName("utf-8")))); 
//        //------------------------------
//        System.out.printf("bad  = %128s\n", hexify(bad.getBytes(Charset.forName("windows-1251")))); 
//        System.out.printf("good = %128s\n", hexify(good.getBytes(Charset.forName("windows-1251"))));
//        System.out.printf("test = %128s\n", hexify(test.getBytes(Charset.forName("windows-1251"))));
//        
//        System.out.println("magic = "+StringEscapeUtils.escapeJava(bad)); 
//    }
}
