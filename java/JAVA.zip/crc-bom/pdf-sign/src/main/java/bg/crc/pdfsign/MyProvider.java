/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.pdfsign;

import java.security.Provider;
import java.security.Security;

/**
 *
 * @author cstoykov
 */
public class MyProvider extends Provider {

    private static final long serialVersionUID = 1L;

    public static void init() {
        Provider temp = Security.getProvider("MyProvider");
        if (temp == null) {
            Security.addProvider(new MyProvider());
        }
    }

    public MyProvider() {
        super(MyProvider.class.getSimpleName(), 0.9, "SHA impl");
        // SHA-224
        super.put("MessageDigest.SHA224", "sun.security.provider.SHA2$SHA224");
        super.put("MessageDigest.SH224", "sun.security.provider.SHA2$SHA224");
        // SHA-256
        super.put("MessageDigest.SHA256", "sun.security.provider.SHA2$SHA256");
        super.put("MessageDigest.SH256", "sun.security.provider.SHA2$SHA256");
        // SHA-384
        super.put("MessageDigest.SHA384", "sun.security.provider.SHA5$SHA384");
        super.put("MessageDigest.SH384", "sun.security.provider.SHA5$SHA384");
        // SHA-512 
        super.put("MessageDigest.SHA512", "sun.security.provider.SHA5$SHA512");
        super.put("MessageDigest.SH512", "sun.security.provider.SHA5$SHA512");
    }
}
