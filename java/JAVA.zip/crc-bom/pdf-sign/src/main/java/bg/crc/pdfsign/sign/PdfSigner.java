/* 
 * 
 *  TITLE: PdfSigner 
 *  PACKAGE: com.technologica.pdfsigners.PdfSigner
 * 
 *  LIMITATIONS/CONSTRAINTS:
 * 
 *  Author: cstoykov@technologica.com 
 * 
 *  TechnoLogica Ltd. All rights reserved.
 */
package bg.crc.pdfsign.sign;

import bg.crc.pdfsign.p12.CertificateWrapper;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfSignatureAppearance;
import com.itextpdf.text.pdf.PdfStamper;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.util.Calendar;
import java.util.Objects;
import lombok.ToString;
import lombok.extern.java.Log;

/**
 * Подписване на PDF.
 *
 * @author cstoykov
 */
@Log
@ToString
public class PdfSigner {

    static {
        //Security.addProvider(new BouncyCastleProvider());
    }

    // папка за буфериране 
    protected File tempFolder = new File(System.getProperty("java.io.tmpdir"));
    // къде отива подписа
    protected int page = 1, x = 1, y = 1, w = 1, h = 1;
    // текст за показване върху четириъгулника с подписа 
    protected String signature;

    /**
     * signature
     *
     * @param signature
     * @return
     */
    public PdfSigner signature(String signature) {
        Objects.requireNonNull(signature, "signature != null");
        this.signature = signature;
        return this;
    }

    /**
     * временна папка
     *
     * @param tempFolder
     * @return
     */
    public PdfSigner tempFolder(File tempFolder) {
        Objects.requireNonNull(tempFolder, "tempFolder != null");
        this.tempFolder = tempFolder;
        return this;
    }

    /**
     * подписа отва на страница
     *
     * @param page
     * @return
     */
    public PdfSigner page(int page) {
        if (page <= 0) {
            throw new RuntimeException("pageNumber >= 1");
        }
        this.page = page;
        return this;
    }

    /**
     * подписа отва на позиция
     *
     * @param x
     * @param y
     * @return
     */
    public PdfSigner position(int x, int y) {
        if (x <= 0) {
            throw new RuntimeException("x >= 1");
        }
        if (y <= 0) {
            throw new RuntimeException("y >= 1");
        }
        this.x = x;
        this.y = y;
        return this;
    }

    /**
     * подписа е с размери
     *
     * @param w
     * @param h
     * @return
     */
    public PdfSigner dimension(int w, int h) {
        if (w <= 0) {
            throw new RuntimeException("w >= 1");
        }
        if (h <= 0) {
            throw new RuntimeException("h >= 1");
        }
        this.w = w;
        this.h = h;
        return this;
    }

    /**
     * @param in файл за подписване
     * @param out подписан файл
     * @param certificate желания подпис ( x509 )
     * @param privateKey желания подпис ( таен ключ )
     *
     * http://api.itextpdf.com/itext/com/itextpdf/text/pdf/PdfStamper.html#createSignature%28com.itextpdf.text.pdf.PdfReader,%20java.io.OutputStream,%20char%29
     *
     * TODO: да се използва ram вместо временен файл
     *
     * @throws Exception
     */
    public void sign(InputStream in, OutputStream out, CertificateWrapper certificate, PrivateKey privateKey) throws Exception {

        // искам random за да не се разправям със конфликти на имената
        String fieldName = "signature_" + System.currentTimeMillis();

        // временен файл 
        File tmpFile = File.createTempFile(getClass().getName() + ".", ".pdf", tempFolder);

        try {

            // кога подписвам
            Calendar signDate = Calendar.getInstance();
            PdfReader reader = new PdfReader(in);

            // прави нова ревизия ...
            PdfStamper stamper = PdfStamper.createSignature(reader, out, '\0', tmpFile, true);

            PdfSignatureAppearance appearance = stamper.getSignatureAppearance();

            //appearance.setProvider(null/*"SunPKCS11"*/);// "BC","SUN","SunJSSE","SunRsaSign"
            //appearance.setImage(Image.getInstance(getClass().getResource("/icons/PdfSigner.png")));
            appearance.setSignDate(signDate);

            // ако няма текст?
            String text = signature;
            if (text == null || text.trim().isEmpty()) {
                text = certificate.toPdfString();
            }
            appearance.setLayer2Text(text);

            appearance.setCrypto(
                    privateKey,
                    certificate.getChain(),
                    null,
                   null// PdfSignatureAppearance.WINCER_SIGNED
            );

            appearance.setVisibleSignature(
                    new Rectangle(
                            x,
                            y + h,
                            x + w,
                            y),
                    page,
                    fieldName
            );

            stamper.close();
            out.flush();

        } finally {
            // почисти  
            tmpFile.delete();
        }
    }

    /**
     * @param in файл за подписване
     * @param out подписан файл
     * @param pke желания подпис ( x509 + таен ключ )
     *
     * @throws Exception
     */
    public void sign(final File in, final File out, final KeyStore.PrivateKeyEntry pke) throws Exception {
        try (FileInputStream fis = new FileInputStream(in)) {
            out.getParentFile().mkdirs();
            try (FileOutputStream fos = new FileOutputStream(out)) {
                sign(fis, fos, new CertificateWrapper(pke), pke.getPrivateKey());
            }
        }
    }

}
