/* 
 * 
 *  TITLE: CertificateWrapper 
 *  PACKAGE: com.technologica.certificates.CertificateWrapper
 * 
 *  LIMITATIONS/CONSTRAINTS:
 * 
 *  Author: cstoykov@technologica.com 
 * 
 *  TechnoLogica Ltd. All rights reserved.
 */
package bg.crc.pdfsign.p12;

import bg.crc.pdfsign.Sha1;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import javax.naming.ldap.Rdn;
import lombok.Getter;
import lombok.Setter;

/**
 * Адаптер на X509 сертификат.
 *
 * <p>
 * хубав toString() и getter/setter за полетата.</p>
 *
 * @author cstoykov (tsani_san@abv.bg)
 */
public class CertificateWrapper {

    /**
     * формат на дата
     */
    @Getter
    @Setter
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    /**
     * истински обект
     */
    @Getter
    private final X509Certificate base;

    /**
     * полета subject-DN
     */
    @Getter
    private final Map<String, String> subjectProperties = new HashMap<>();

    /**
     * полета issuer-DN
     */
    @Getter
    private final Map<String, String> issuerProperties = new HashMap<>();

    /**
     * полета x509
     */
    @Getter
    private final Map<String, String> certificateProperties = new HashMap<>();

    /**
     * удостоверителна верига
     */
    @Getter
    @Setter
    //не е използвано?
    //да добавim CertificationPath
    private Certificate[] chain;

    /**
     * @param b сертификат
     */
    public CertificateWrapper(X509Certificate b) {
        this.base = b;
        this.chain = new Certificate[]{b};
        String error = "certificate properties";
        try {
            // certificate 
            certificateProperties.put("sha1", Sha1.digest(b));
            certificateProperties.put("not-before", dateFormat.format(base.getNotBefore()));
            certificateProperties.put("not-after", dateFormat.format(base.getNotAfter()));
            certificateProperties.put("serial", base.getSerialNumber() + "");

            // subject
            error = "subject properties";
            LdapName subject = new LdapName(base.getSubjectDN().getName());
            for (Rdn rdn : subject.getRdns()) {
                subjectProperties.put(rdn.getType(), rdn.getValue() + "");
            }

            // issuer 
            error = "issuer properties";
            LdapName issuer = new LdapName(base.getIssuerDN().getName());
            for (Rdn rdn : issuer.getRdns()) {
                issuerProperties.put(rdn.getType(), rdn.getValue() + "");
            }

        } catch (InvalidNameException ex) {
            // проблем
            throw new RuntimeException(error, ex);
        }
        this.chain = new Certificate[]{b};
    }

    /**
     * @param pke сертификат
     */
    public CertificateWrapper(KeyStore.PrivateKeyEntry pke) {
        this((X509Certificate) pke.getCertificate());
        this.chain = pke.getCertificateChain();
    }

    @Override
    public String toString() {
        return subjectProperties.get("CN") + " : " + base.getSerialNumber();
    }

    /**
     * text представяне на сертификата за подпиписа в pdf документа
     *
     * @return html низ
     */
    public String toPdfString() {
        StringBuilder sb = new StringBuilder();
        sb.append(subjectProperties.get("CN")).append("\n");
        sb.append(dateFormat.format(new Date())).append("\n");
        if (subjectProperties.get("O") != null
                && !subjectProperties.get("O").isEmpty()) {
            sb.append(subjectProperties.get("O")).append("\n");
        }
        if (subjectProperties.get("title") != null
                && !subjectProperties.get("title").isEmpty()) {
            sb.append(subjectProperties.get("title")).append("\n");
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 53 * hash + Objects.hashCode(this.base);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final CertificateWrapper other = (CertificateWrapper) obj;
        if (!Objects.equals(this.base, other.base)) {
            return false;
        }
        return true;
    }

}
