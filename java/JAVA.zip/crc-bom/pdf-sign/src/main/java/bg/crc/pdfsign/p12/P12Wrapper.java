/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.crc.pdfsign.p12;

import java.io.InputStream;
import java.security.KeyStore;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import lombok.extern.java.Log;

/**
 * работа с p12
 *
 * @author cstoykov
 */
@Log
public class P12Wrapper {

    public static final String DEFALT_P12 = "/Pkcs1xLocal.p12";
    public static final String DEFALT_PASS = "12345";
    public static final P12Wrapper DEFALT;

    static {
        try (InputStream is = P12Wrapper.class.getResourceAsStream(DEFALT_P12)) {
            DEFALT = keystore(is, (message) -> DEFALT_PASS.toCharArray());
        } catch (Exception e) {
            throw new RuntimeException("loading [" + P12Wrapper.class.getResource(DEFALT_P12) + "] failed", e);
        }
    }

    /**
     * keystore
     *
     * @param stream keystore поток
     * @param passwordCallback парола
     * @return
     */
    public static P12Wrapper keystore(InputStream stream, PasswordCallback passwordCallback) {
        Objects.requireNonNull(passwordCallback, "passwordCallback != null");
        Objects.requireNonNull(stream, "stream != null");
        P12Wrapper result = new P12Wrapper();
        try {
            result.keyStore = KeyStore.getInstance("PKCS12");
            result.keyStorePassword = passwordCallback;
            result.keyStore.load(stream, passwordCallback.password("keystore-password"));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return result;
    }

    protected KeyStore keyStore;
    protected PasswordCallback keyStorePassword;

    protected P12Wrapper() {
    }

    /**
     * всички записи от keystore
     *
     * @return всички записи от keystore
     */
    public List<String> aliasSet() {
        try {
            return Collections.list(getKeyStore().aliases());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * дай ми частек ключ и сертификат по запис
     *
     * @param alias запис
     * @param passwordCallback парола
     * @return частек ключ
     */
    public KeyStore.PrivateKeyEntry privateKeyEntry(String alias, PasswordCallback passwordCallback) {
        try {
            if (passwordCallback == null) {
                return (KeyStore.PrivateKeyEntry) getKeyStore().getEntry(alias, new KeyStore.PasswordProtection(keyStorePassword.password(alias)));
            } else {
                return (KeyStore.PrivateKeyEntry) getKeyStore().getEntry(alias, new KeyStore.PasswordProtection(passwordCallback.password(alias)));
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * @return the keyStore
     */
    public KeyStore getKeyStore() {
        return keyStore;
    }

    /**
     * @param keyStore the keyStore to set
     */
    public void setKeyStore(KeyStore keyStore) {
        this.keyStore = keyStore;
    }
}
