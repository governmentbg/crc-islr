package com.tlogica.jsec.utils;
/**
 * Various character utilities.
 */
 public class CharUtil {

    // ---------------------------------------------------------------- conversions

    /**
     * Converts char array into byte array. Chars are truncated to byte size.
     */
    public static byte[] toByteArray(char[] carr) {
        if (carr == null) {
            return null;
        }
        byte[] barr = new byte[carr.length];
        for (int i = 0; i < carr.length; i++) {
            barr[i] = (byte) carr[i];
        }
        return barr;
    }

    /**
     * Converts byte array to char array.
     */
    public static char[] toCharArray(byte[] barr) {
        if (barr == null) {
            return null;
        }
        char[] carr = new char[barr.length];
        for (int i = 0; i < barr.length; i++) {
            carr[i] = (char) barr[i];
        }
        return carr;
    }
}