package com.tlogica.jsec.utils;

import java.io.OutputStream;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Provides an OutputStream to an internal String. Internally converts bytes
 * to a Strings and stores them in an internal StringBuffer.
 */
public class StringOutputStream extends OutputStream implements Serializable {

    protected String m_encoding = "UTF-8"; // default encoding
    protected byte[] m_bytes;

    /**
     * Creates new StringOutputStream, makes a new internal StringBuffer,
     * using UTF-8 encoding of characters.
     */
    public StringOutputStream() {
        super();
    }

    /**
     * Creates new StringOutputStream, makes a new internal StringBuffer,
     * using explicitly specified encoding.
     */
    public StringOutputStream(String encoding) {
        super();
        if (encoding != null) {
            m_encoding = encoding;
        }
    }

    /**
     * Returns the content of the internal StringBuffer as a String, the result
     * of all writing to this OutputStream.
     *
     * @return returns the content of the internal StringBuffer
     */
    @Override
    public String toString() {
        String result = null;
        try {
            result = new String(m_bytes, m_encoding);
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(StringOutputStream.class.getName()).log(Level.SEVERE, null, ex);
            result = new String(m_bytes);
        }
        return result;
    }

    /**
     * Sets the internal StringBuffer to null.
     */
    @Override
    public void close() {
        m_bytes = null;
    }

    /**
     * Writes and appends byte array to StringOutputStream.
     *
     * @param b byte array
     */
    @Override
    public void write(byte[] b) {
        System.out.println("Write byte array");
        m_bytes = b;
    }

    /**
     * Writes and appends a byte array to StringOutputStream.
     *
     * @param b the byte array
     * @param off the byte array starting index
     * @param len the number of bytes from byte array to write to the stream
     */
    @Override
    public void write(byte[] b, int off, int len) {
        if ((off < 0) || (len < 0) || (off + len) > b.length) {
            throw new IndexOutOfBoundsException("StringOutputStream.write: Parameters out of bounds.");
        }
        byte[] bytes = new byte[len];
        for (int i = 0; i < len; i++) {
            bytes[i] = b[off];
            off++;
        }
        m_bytes = ByteArray.mergeArrays(m_bytes, bytes);
    }

    /**
     * Writes and appends a single byte to StringOutputStream.
     *
     * @param b the byte as an int to add
     */
    public void write(int b) {
        System.out.println("WARNING: Write int");
    }

    public void setEncoding(String encoding) {
        m_encoding = encoding;
    }

    public String getEncoding() {
        return m_encoding;
    }

    /**
     * Returns all bytes read from the input stream without any modification
     * on them.
     * @return byte array
     */
    public byte[] getBytes() {
        return m_bytes;
    }
}
