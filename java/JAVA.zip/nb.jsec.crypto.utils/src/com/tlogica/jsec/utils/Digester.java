package com.tlogica.jsec.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * This class is intended to digest messages and binary files.
 * @author Miroslav Dzhokanov
 */
public class Digester {

    public static final String SHA1 = "SHA1";
    protected static final String defaultAlgorithm = "SHA1";
    private String digestAlgorithm;

    /**
     * Default constructor. Uses default algorithm - SHA1
     */
    public Digester() {
        this.digestAlgorithm = defaultAlgorithm;
    }

    /**
     * Constructor with specific digest algorithm.
     * @param digestAlgorithm - SHA1, SHA512, MD5 ...
     */
    public Digester(String digestAlgorithm) {
        this.digestAlgorithm = digestAlgorithm;
    }

    public byte[] digest(byte[] data) //
    {
        byte[] digested = null;

        try {
            MessageDigest digest = MessageDigest.getInstance(digestAlgorithm);
            digested = digest.digest(data);
        } catch (NoSuchAlgorithmException ex) {
            throw new RuntimeException(" failed to get private key as bytes ", ex);
        }


        return digested;
    }
    // TODO - FileDigester
}
