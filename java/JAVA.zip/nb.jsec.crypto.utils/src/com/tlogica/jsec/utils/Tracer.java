package com.tlogica.jsec.utils;

/**
 * Това е помощен клас, чиято основна функция е
 * да открива името на класа и метода, които извикват журнала.
 * Методите на класа са package-private и не са достъпни извън
 * текущия пакет.
 */
public class Tracer {

    private Tracer() {
    }

    /**
     * Открива името на метода, който е извикал настоящия метод.
     * Откриването на името на метода се осъществява посредством
     * стека на текущата нишка.
     * @param depth допълнителна дълбочина в стека на нишката,
     * от която да се вземе името на търсения метод
     * @return пълно име на метод (включва и името на класа)
     * @throws LoggerException в случай че подадената като параметър
     * дълбочина е твърде голяма (с поне 3 единици по-голяма от дълбочината
     * стека)
     */
    static String getFullMethodName(int depth) {
        return getClassName(depth + 1) + "." + getMethodName(depth + 1);
    }

    /**
     * Открива името на метода, който е извикал настоящия метод.
     * Откриването на името на метода се осъществява посредством
     * стека на текущата нишка.
     * @param depth допълнителна дълбочина в стека на нишката,
     * от която да се вземе името на търсения метод
     * @return име на метод
     * @throws LoggerException в случай че подадената като параметър
     * дълбочина е твърде голяма (с поне 3 единици по-голяма от дълбочината
     * стека)
     */
    static String getMethodName(int depth) {
        StackTraceElement[] traces = getCurrentTrace();
        int traceDepth = traces.length;

        String methodName = null;
        if (traceDepth >= 3 + depth) {
            // traces[0]  -->  Thread.getStackTrace()
            // traces[1]  -->  this.getCurrentTrace()
            // traces[2]  -->  this.getMethodName()
            methodName = traces[3 + depth].getMethodName();
        } else {
            //Logger.log(Logger.ERROR, "Bad method depth - " + depth);
            //throw new LoggerException("Bad method depth - " + depth);
        }

        return methodName;
    }

    /**
     * Открива името на класа, който е извикал настоящия метод.
     * Откриването на името на класа се осъществява посредством
     * стека на текущата нишка.
     * @param depth допълнителна дълбочина в стека на нишката,
     * от която да се вземе името на търсения клас
     * @return пълно име на клас
     * @throws LoggerException в случай че подадената като параметър
     * дълбочина е твърде голяма (с поне 3 единици по-голяма от дълбочината
     * стека)
     */
    static String getClassName(int depth){
        StackTraceElement[] traces = getCurrentTrace();
        int traceDepth = traces.length;

        String methodName = null;
        if (traceDepth >= 3 + depth) {
            // traces[0]  -->  Thread.getStackTrace()
            // traces[1]  -->  this.getCurrentTrace()
            // traces[2]  -->  this.getClassName()
            methodName = traces[3 + depth].getClassName();
        } else {
            //Logger.log(Logger.ERROR, "Bad method depth - " + depth);
            //throw new LoggerException("Bad method depth - " + depth);
        }

        return methodName;
    }

    /**
     * Този метод връща стека на текущата нишка
     * @return масив от стекови елементи
     */
    private static StackTraceElement[] getCurrentTrace() {
        return Thread.currentThread().getStackTrace();
    }

    /**
     * Връща текущия StackTrace (без да взема предвид настоящия метод) и го
     * връща като стринг
     * @param depth допълнителна дълбочина в стека на нишката,
     * от която да се вземе името на търсения клас
     * @return StackTrace като текст
     */
    public static String getCurrentStackTraceAsText(int depth) {
        StackTraceElement[] methods = Thread.currentThread().getStackTrace();

        // Конструираме стринга
        String stackTrace = "";
        String prefix = " ";
        // i = 2, за да прескочи Thread.getStackTrace и настоящия метод
        for (int i = 2 + depth; i < methods.length; i++) {
            stackTrace += prefix + methods[i] + "\n";
        }

        return stackTrace;
    }

    /**
     * Връща StackTrace на подадената грешка и го връща като стринг
     * @return StackTrace като текст
     */
    public static String getExceptionStackTraceAsText(Exception e) {
        String stackTrace = getExceptionTraceInner(e);
        Throwable cause = e.getCause();
        while (cause != null) {
            stackTrace += "Caused by: \n" + getExceptionTraceInner(cause);
            cause = cause.getCause();
        }
        return stackTrace;
    }

    private static String getExceptionTraceInner(Throwable e) {
        StackTraceElement[] methods = e.getStackTrace();
        String message = e.getMessage();
        String stackTrace = e.getClass().getName() + ": " +message + " at \n";
        String leftPadding = " ";
        // Конструираме стринга
        for (int i = 0; i < methods.length; i++) {
            stackTrace += leftPadding + methods[i] + "\n";
        }
        return stackTrace;
    }
}
