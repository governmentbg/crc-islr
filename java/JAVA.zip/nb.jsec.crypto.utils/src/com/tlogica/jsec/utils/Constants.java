
package com.tlogica.jsec.utils;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class Constants {
    public static final String IE_SIGNATURE_ENCODING = "UnicodeLittleUnmarked";
    public static final String DEFAULT_MESSAGE_ENCODING = "UTF-8";
    public static final char TOKEN_WHITE_SPACE = ' ';
    public static final char TOKEN_NEW_LINE = '\n';
    public static final char TOKEN_CARRIAGE_RETURN = '\r';
}
