package com.tlogica.jsec.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 *
 * @author mdzhokanov
 */
public class ByteArray {

    /**
     * Checks two byte arrays for equality.
     * If the two arrays are NULL (not initalized) this method returns false.
     * @param a
     * @param b
     * @return true if the byte arrays are the same. Otherwise returns false.
     */
    public static boolean constantTimeAreEqual(
            byte[] a,
            byte[] b) {
        if (a == b) {
            return true;
        }

        if (a == null || b == null) {
            return false;
        }

        if (a.length != b.length) {
            return false;
        }

        int nonEqual = 0;

        for (int i = 0; i != a.length; i++) {
            nonEqual |= (a[i] ^ b[i]);
        }

        return nonEqual == 0;
    }

    public static void printBytes(byte[] arr) {
        int sum = 0;
        for (byte b : arr) {
            sum += b;
            System.out.print(" " + b);
        }
        System.out.println();
        //System.out.println("Bytes LEN/SUM => " + arr.length + "/" + sum);
    }

    public static byte[] mergeArrays(byte[] first, byte[] second) {
        if (first == null && second != null) {
            return second;
        }
        if (first != null && second == null) {
            return second;
        }
        int firstSize = first.length;
        int secondSize = second.length;
        byte result[] = new byte[firstSize + secondSize];
        System.arraycopy(first, 0, result, 0, firstSize);
        System.arraycopy(second, 0, result, firstSize, secondSize);
        return result;
    }

    public static byte[] getBytesFromStream(InputStream is) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();

        int nRead;
        byte[] data = new byte[16384];

        while ((nRead = is.read(data, 0, data.length)) != -1) {
            buffer.write(data, 0, nRead);
        }

        buffer.flush();

        return buffer.toByteArray();


    }
}
