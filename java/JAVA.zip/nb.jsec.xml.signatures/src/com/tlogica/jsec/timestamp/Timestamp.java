package com.tlogica.jsec.timestamp;

import com.tlogica.jsec.core.pkcs.PKCS7Container;
import com.tlogica.jsec.core.pkcs.PKCS7Signature;
import com.tlogica.jsec.core.pkcs.PKCS7SignedData;
import com.tlogica.jsec.core.verification.PKCS7SignatureVerifier;
import com.tlogica.jsec.core.verification.VerificationException;
import com.tlogica.jsec.utils.ByteArray;
import com.tlogica.jsec.utils.Digester;
import com.tlogica.jsec.utils.base64.Base64;
import com.tlogica.jsec.timestamp.TimeStampFactory;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.security.cert.X509Certificate;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import sun.security.pkcs.ParsingException;
import sun.security.util.DerInputStream;
import sun.security.util.DerValue;

/**
 * This class represents the timestamp object, described in RFC 3161.
 * (http://tools.ietf.org/html/rfc3161)
 * 
 * ------- FREE TIMESTAMP AUTHORITIES -------
http://tsa.b-trust.org/   OK
https://tsa.stampit.org/         !!!   NOT TESTED YET
http://tsa.swisssign.net  OK
http://time.certum.pl     OK
http://tsa01.quovadisglobal.com/TSS/HttpTspServer   OK
http://www.ca-soft.com/request.aspx   OK
http://zeitstempel.dfn.de   OK
http://tsp.signtrust.de/tsp/dpcom  OK
http://tsp.signtrust.de/tsp/dpcom (Bad PKCS7)
http://dir.signtrust.de/Signtrust/TSP/servlet/httpGateway.PostHandler (Bad PKCS7)
http://dir.bnotk.de/bnotk/TSP/servlet/httpGateway.PostHandler (Bad PKCS7)
http://tsa.starfieldtech.com (NOT DER encoded response)
http://tsa.aloaha.com/ (NOT DER encoded response)
http://dse200.ncipher.com/TSS/HttpTspServer (Unrecognized value for the failInfo element)
 *
 * @author Miroslav Dzhokanov
 */
public class Timestamp {

    private byte[] m_bytes;
    private Date m_date;
    private PKCS7SignedData m_signedData;
    private byte[] m_tsRequestBytes;
    private PKCS7Signature m_signature;
    private X509Certificate m_signerCertificate;
    private final static String OID_PKCS7_SIGNED_DATA = "OID.1.2.840.113549.1.7.2";
    private final static String OID_PKCS9_ENCAP_CONTENT_INFO = "OID.1.2.840.113549.1.9.16.1.4";
    private final static String OID_SHA_1_DIGEST_ALGORITHM = "OID.1.3.14.3.2.26";

    private Timestamp() {
    }

    /**
     * Bytes should not be base64 encoded.
     * @param bytes
     */
    public Timestamp(byte[] bytes){
        try {
            PKCS7Container pkcs7TimeStamp = new PKCS7Container(bytes);
            m_bytes = bytes;
            m_date = pkcs7TimeStamp.getSignedData().getSigningTime();
            // TSA certificate
            m_signerCertificate = pkcs7TimeStamp.getSignerCert();
            m_signedData = pkcs7TimeStamp.getSignedData();
            m_signature = pkcs7TimeStamp.getSignature();
            additionalDerDecode();
        } catch (Exception ex) { 
            throw new RuntimeException(ex);
        }
    }

    /**
     * This method decodes timestamp response according to RFC 3161
     * @throws IOException
     */
    private void additionalDerDecode() throws IOException {
        DerValue derTSToken = new DerValue(m_bytes);
        DerInputStream derStream = derTSToken.data;
        if (derStream.available() > 0) {
            DerValue derContentType = derStream.getDerValue();
            String contentTypeOID = derContentType.toString();
            //System.out.println("DEBUG: TimeStamp ContentType OID - " + contentTypeOID);
            // PKCS7 TIMESTAMP
            if (OID_PKCS7_SIGNED_DATA.equals(contentTypeOID)) {
                if (derStream.available() > 0) {
                    DerValue derContent = derStream.getDerValue();
                    //System.out.println("DEBUG: TimeStamp content was detected.");
                    DerInputStream derContentStream = derContent.data;
                    if (derContentStream.available() > 0) {
                        DerValue[] derContentValues = derContentStream.getSequence(0);
//                        DerValue derSignedDataContentVersion = derContentValues[0];
//                        DerValue derSignedDataContentPolicy = derContentValues[1];
                        DerValue derSignedDataContent = derContentValues[2];
                        //System.out.println("derSignedDataContent: " + derSignedDataContent);
                        DerInputStream derEncapContentInfo = derSignedDataContent.data;
                        if (derEncapContentInfo.available() > 0) {
                            DerValue derEncapContentTypeOID = derEncapContentInfo.getDerValue();
                            String encapContentTypeOID = derEncapContentTypeOID.toString();
                            //System.out.println("Encapsulated ContentType OID - " + encapContentTypeOID);
                            DerValue derEncapContent = derEncapContentInfo.getDerValue();
                            //System.out.println("derEncapContent: " + derEncapContent);
                            // PKCS9 TIMESTAMP INFO
                            if (OID_PKCS9_ENCAP_CONTENT_INFO.equals(encapContentTypeOID)) {
                                DerInputStream derTSTInfoStream = derEncapContent.data;
                                DerValue derTSTInfo = new DerValue(derTSTInfoStream.getOctetString());
                                //System.out.println("TSTInfo Octet String: " + derTSTInfo);
                                DerInputStream tstInfoStream = derTSTInfo.data;
                                if (tstInfoStream.available() > 0) {
                                    DerValue derTSTInfoVersion = tstInfoStream.getDerValue();
                                    //System.out.println("derTSTInfoVersion: " + derTSTInfoVersion);
                                    DerValue derTSTInfoPolicy = tstInfoStream.getDerValue();
                                    //System.out.println("derTSTInfoPolicy: " + derTSTInfoPolicy);
                                    DerValue derTSTInfoMessageImprint = tstInfoStream.getDerValue();
                                    //System.out.println("derTSTInfoMessageImprint: " + derTSTInfoMessageImprint);
                                    DerInputStream messageImprintStream = derTSTInfoMessageImprint.data;
                                    if (tstInfoStream.available() > 0) {
                                        DerValue derDigestAlgorithm = messageImprintStream.getDerValue();
                                        //System.out.println("derDigestAlgorithmOID: " + derDigestAlgorithm.data.getDerValue());
                                        DerValue derSignedBytes = messageImprintStream.getDerValue();
                                        //System.out.println("DEBUG: Signed message bytes are - " + derSignedBytes);
                                        m_tsRequestBytes = derSignedBytes.getDataBytes();
                                        //ByteArray.printBytes(derSignedBytes.getDataBytes());
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                throw new UnsupportedOperationException(derContentType.toString() + " TimeStamps are not supported");

            }
        }
    }

    /**
     * Returns timestamp bytes (NOT base64 encoded)
     * @return
     */
    public byte[] getBytes() {
        return m_bytes;
    }

    /**
     * Returns timestamp bytes (base64 encoded)
     * @return
     */
    public byte[] getBytesEncoded() {
        byte[] encoded = Base64.encode(m_bytes);
        return encoded;
    }

    public Date getDate() {
        return m_date;
    }

    public PKCS7SignedData getSignedData() {
        return m_signedData;
    }

    public PKCS7Signature getSignature() {
        return m_signature;
    }

    /**
     * TSA certificate
     * @return
     */
    public X509Certificate getSignerCertificate() {
        return m_signerCertificate;
    }

    public byte[] getTSRequestBytes() {
        return m_tsRequestBytes;
    }

    /**
     * Verifies whether the passed bytes are the same as the ones been timestamped
     * by current timestamp object.
     * This method also check for consistency of the timestamp itslef - makes check
     * whether the timestamped bytes have been modified after signing or not.
     * @param timestampedBytes
     * @return false if the passed bytes doesn't correspond to the bytes that have
     * been signed with current timestamp or if the current timestamp has been
     * corrupted (its content has been modified after the actual timestamping)
     */
    public boolean verify(byte[] timestampedBytes) {
        boolean verified = true;

        // Check actual bytes, signed by TSA, are the same as the ones passed as argument
        Digester digest = new Digester("SHA-1");
        byte[] digested = digest.digest(timestampedBytes);
        if (!ByteArray.constantTimeAreEqual(m_tsRequestBytes, digested)) {
            Logger.getLogger(Timestamp.class.getName()).log(Level.WARNING, null, "WARNING: Not equal hashes! The signed data is not the same as the data provided.");
            verified = false;
            return verified;
        }

        // Verify the signature itself is correct and has not been corrupted or modified
        PKCS7SignatureVerifier verifier = new PKCS7SignatureVerifier(m_bytes, getSignedData().getSignedDataBytes());
        try {
            verifier.verify();
        } catch (VerificationException ex) {
            // In timestamp PKCS7 verification this exception (NOT_EQUAL_HASHES) is always thrown.
            // TODO need to be researched (PKCS7 and Timestamp creation)
            if (!VerificationException.NOT_EQUAL_HASHES.equals(ex.getMessage())) {
                Logger.getLogger(Timestamp.class.getName()).log(Level.SEVERE, null, ex);
                verified = false;
                return verified;
            }
        }

        //TODO where to load trusted certificates, not breaking current JAR's portability
        // Verify TSA certificate
//        Verifier certVerifier = new Verifier();
//        certVerifier.verifyCertificate(m_signerCertificate);
        return verified;
    }
}
