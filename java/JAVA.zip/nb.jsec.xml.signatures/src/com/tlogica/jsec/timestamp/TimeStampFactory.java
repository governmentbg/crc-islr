package com.tlogica.jsec.timestamp;

import com.tlogica.jsec.timestamp.except.TimestampException;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;

import sun.security.timestamp.TSRequest;

/**
 * TODO export these TSA urls in external config file * //http://tsa.b-trust.org/ OK // https://tsa.stampit.org/ !!! NOT
 * TESTED YET //http://tsa.swisssign.net OK //http://time.certum.pl OK
 * //http://tsa01.quovadisglobal.com/TSS/HttpTspServer OK //http://www.ca-soft.com/request.aspx OK
 * //http://zeitstempel.dfn.de OK //http://tsp.signtrust.de/tsp/dpcom OK //http://tsp.signtrust.de/tsp/dpcom (Bad PKCS7)
 * //http://dir.signtrust.de/Signtrust/TSP/servlet/httpGateway.PostHandler (Bad PKCS7)
 * //http://dir.bnotk.de/bnotk/TSP/servlet/httpGateway.PostHandler (Bad PKCS7) //http://tsa.starfieldtech.com (NOT DER
 * encoded response) //http://tsa.aloaha.com/ (NOT DER encoded response) //http://dse200.ncipher.com/TSS/HttpTspServer
 * (Unrecognized value for the failInfo element)
 *
 * @author mdzhokanov
 */
public class TimeStampFactory {

    private static final Logger log = Logger.getLogger("com.tlogica.jsec.xml.xades.tsa.TimeStampFactory");
    // TODO - get the TSA_URL from list with all possible addresses
    private static final String TSA_URL = "http://tsa.swisssign.net";

    public static TSResponse getTimeStampResponse(String strUrl, byte[] data, boolean calculateDigest) throws TimestampException {
	HttpTimestamper httpTimestamper = new HttpTimestamper(strUrl);

	byte[] digest = data;
	// digest bytes to be timestamped if calculateDigest argument is true
	try {
	    if (calculateDigest) {
		MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
		digest = messageDigest.digest(data);
	    }
	} catch (NoSuchAlgorithmException e) {
	    throw new TimestampException(e);
	}

	TSRequest request = new TSRequest(digest, "SHA-1");
	request.requestCertificate(false);

	TSResponse response = null;
	try {
	    response = httpTimestamper.generateTimestamp(request);
	} catch (IOException e) {
	    throw new TimestampException(e);
	}

	return response;
    }

    public static Timestamp getTimeStamp(byte[] data) throws TimestampException {
	return getTimeStamp(TSA_URL, data, true);
    }

    public static Timestamp getTimeStamp(String tsaURL, byte[] data, boolean calculateDigest)
	    throws TimestampException //
    {
	log.log(Level.INFO, "Get timestamp from {0}", tsaURL);
	TSResponse response = null;
	response = getTimeStampResponse(tsaURL, data, calculateDigest);
	Timestamp timestamp = null;
	timestamp = new Timestamp(response.getEncodedToken());
	log.fine("Timestamp received.");
	return timestamp;
    }
}
