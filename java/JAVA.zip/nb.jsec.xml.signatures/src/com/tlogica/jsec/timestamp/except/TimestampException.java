package com.tlogica.jsec.timestamp.except;

/**
 * General exception, which is thrown during generation or parsing of timestamp.
 * @author Miroslav Dzhokanov
 */
public class TimestampException extends Exception {

    public static final String UNDEFINED = "Undefined timestamp exception.";
    private String errorCode;

    public TimestampException(String mess) {
        super(mess);
        this.errorCode = TimestampException.UNDEFINED;
    }

    public TimestampException(Throwable cause) {
        super(cause);
        if (cause instanceof TimestampException) {
            this.errorCode = ((TimestampException) cause).getErrorCode();
        } else {
            this.errorCode = TimestampException.UNDEFINED;
        }
    }

    public TimestampException(String mess, Throwable cause) {
        super(mess, cause);
        if (cause instanceof TimestampException) {
            this.errorCode = ((TimestampException) cause).getErrorCode();
        } else {
            this.errorCode = TimestampException.UNDEFINED;
        }
    }

    public TimestampException(String mess, String errCode) {
        super(mess);
        this.errorCode = errCode;
    }

    public TimestampException(Throwable cause, String errCode) {
        super(cause);
        this.errorCode = errCode;
    }

    public TimestampException(String mess, Throwable cause, String errCode) {
        super(mess, cause);
        this.errorCode = errCode;
    }

    public String getErrorCode() {
        return this.errorCode;
    }
}