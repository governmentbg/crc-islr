package com.tlogica.jsec.xml.dsig;

/**
 *
 * @author mdzhokanov
 */
public enum XMLSignatureType {

    ENVELOPING, ENVELOPED, DETACHED
}
