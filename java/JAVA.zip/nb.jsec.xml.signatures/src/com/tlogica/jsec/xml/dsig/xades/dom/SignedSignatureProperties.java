package com.tlogica.jsec.xml.dsig.xades.dom;

import com.tlogica.jsec.xml.DOMUtil;
import java.util.Map;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class SignedSignatureProperties {

    public static final String ID_KEY = "SSP";
    private static final String ELEMENT_LOCAL_NAME = "SignedSignatureProperties";
    private Element element;
    private SigningTime signingTime;
    private SigningCertificate signingCertificate;

    public SignedSignatureProperties(Document doc, String prefix, Map<String, String> idMap) {
        signingTime = new SigningTime(doc, prefix, idMap);
        signingCertificate = new SigningCertificate(doc, prefix, idMap);

        element = doc.createElementNS(XadesSignature.XMLNS_1_3_2, ELEMENT_LOCAL_NAME);
        element.setPrefix(prefix);
        // append child nodes
        element.appendChild(signingTime.getDOMElement());
        element.appendChild(signingCertificate.getDOMElement());
        DOMUtil.setNoNSId(element, idMap, ID_KEY);
    }

    public Element getDOMElement() {
        return element;
    }

    public SigningTime getSigningTime() {
        return signingTime;
    }
    public SigningCertificate getSigningCertificate() {
        return signingCertificate;
    }
}
