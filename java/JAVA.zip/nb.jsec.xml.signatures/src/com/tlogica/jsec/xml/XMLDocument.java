package com.tlogica.jsec.xml;

import com.tlogica.jsec.xml.dsig.XMLDigSignature;
import com.tlogica.jsec.xml.except.XMLDocumentException;
import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

/**
 * Object representation of xml file
 * @author Miroslav Dzhokanov
 */
public class XMLDocument implements Cloneable {

    // this document represents the whole XML Document
    private Document m_rootDocument;
    // is the xml signed
    private boolean m_isSigned = false; //default value is false
    // this field is null if the xml is not signed
    private List<XMLDigSignature> m_signatures = new LinkedList<XMLDigSignature>();
    // this field holds the document content (doesn't hold signatures)
    private List<Node> m_documentContentNodeList;
    private String m_encoding = "UTF-8"; //default encoding

    public XMLDocument() {
    }

    /**
     * Returns null if the document is not signed.
     * @return 
     */
    public List<XMLDigSignature> getSignatures() {
        return m_signatures;
    }

    public boolean isSigned() {
        return m_isSigned;
    }

    public void setIsSigned(boolean isSigned) {
        this.m_isSigned = isSigned;
    }

    public Document getRoot() {
        return m_rootDocument;
    }

    public void setRootDocument(Document root) {
        m_rootDocument = root;
        // set encoding for eventual future output
        if (m_rootDocument.getXmlEncoding() != null) {
            this.setEncoding(m_rootDocument.getXmlEncoding());
        }
    }

    public List<Node> getDocumentContentNodes() {
        return m_documentContentNodeList;
    }

    void setDocumentContentNodes(List<Node> nodes) {
        m_documentContentNodeList = nodes;
    }

    public String getEncoding() {
        return m_encoding;
    }

    public void setEncoding(String encoding) {
        this.m_encoding = encoding;
    }

    void addSignatures(List<XMLDigSignature> signatures) {
        for (XMLDigSignature sig : signatures) {
            addSignature(sig);
        }
    }

    void addSignature(XMLDigSignature signature) {
        this.m_signatures.add(signature);
    }

    @Override
    public String toString() {
        String text = XMLUtils.convertXMLNodeToString(m_rootDocument, m_encoding);
        try {
            text = XMLUtils.beautifyXML(text);
        } catch (XMLDocumentException ex) {
            Logger.getLogger(XMLDocument.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(XMLDocument.class.getName()).log(Level.SEVERE, null, ex);
        }
        return text;
    }

    /**
     * This method compares two documents after normalizing and beautifying them.
     * @param o
     * @return
     */
    @Override
    public boolean equals(Object o) {
        if (o instanceof XMLDocument) {
            XMLDocument otherDoc = (XMLDocument) o;
            Document otherRoot = otherDoc.getRoot();
            XMLUtils.normalizeXML(otherRoot);
            String otherText = null;
            otherText = XMLUtils.convertXMLNodeToString(otherRoot, otherDoc.getEncoding());

            XMLUtils.normalizeXML(m_rootDocument);
            String thisText = null;
            thisText = XMLUtils.convertXMLNodeToString(m_rootDocument, m_encoding);

            if (thisText != null && otherText != null) {
                // Same documents
                if (thisText.equals(otherText)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public XMLDocument clone() {
        XMLDocument copy = new XMLDocument();

        copy.setRootDocument(this.getRoot());
        copy.setDocumentContentNodes(this.getDocumentContentNodes());
        copy.addSignatures(this.getSignatures());
        copy.setIsSigned(this.isSigned());
        copy.setEncoding(this.getEncoding());

        if (!copy.equals(this)) {
            System.out.println("FATAL: Unreliable clone method!!!");
        }

        return copy;
    }

    public static void main(String... a) throws Exception {
        XMLDocument doc1 = XMLDocumentReader.read(new File("test/xml/fileToSignFULL.xml"));
        XMLDocument doc2 = XMLDocumentReader.read(new File("test/xml/fileToSignFULL_decorative_changes.xml"));
        System.out.println("Compare doc1 to doc1 -> " + doc1.equals(doc1));
        System.out.println("Compare doc1 to doc2 -> " + doc1.equals(doc2));
    }
}
