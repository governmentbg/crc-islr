package com.tlogica.jsec.xml.dsig.xades.dom;

import com.tlogica.jsec.xml.DOMUtil;
import com.tlogica.jsec.xml.except.XMLSigningException;
import java.util.Map;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class QualifyingProperties {

    public static final String ID_KEY = "QP";
    private Element elQualifProp;
    private static final String ELEMENT_LOCAL_NAME = "QualifyingProperties";

    public QualifyingProperties(Document doc, String prefix, Map<String, String> idMap, boolean addUnsignedProps) throws XMLSigningException {
        elQualifProp = doc.createElementNS(XadesSignature.XMLNS_1_3_2, ELEMENT_LOCAL_NAME);
        elQualifProp.setPrefix(prefix);
        // TODO Signature ID should be extracted from the map too
        elQualifProp.setAttributeNS(null, "Target", "Signature");

        SignedProperties signedProperties = new SignedProperties(doc, prefix, idMap);
        // append child nodes
        elQualifProp.appendChild(signedProperties.getDOMElement());
        // add unsigned properties only if it is explicitly specified
        if(addUnsignedProps){
            UnsignedProperties unsignedProperties = new UnsignedProperties(doc, prefix, idMap);
            elQualifProp.appendChild(unsignedProperties.getDOMElement());
        }
        // set attributes
        // TODO Signature ID should be extracted from the map too
        elQualifProp.setAttribute("Target", "#Signature");
        DOMUtil.setNoNSId(elQualifProp, idMap, ID_KEY);
    }

    public Element getDOMElement() {
        return elQualifProp;
    }
}
