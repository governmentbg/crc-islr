package com.tlogica.jsec.xml.except;

/**
 * General exception, which is thrown during deserialization process.
 * @author Miroslav Dzhokanov
 */
public class XMLDocumentException extends RuntimeException {

    public static final String UNDEFINED = "Undefined XMLDocument construction exception.";
    private String errorCode;

    public XMLDocumentException(String mess) {
        super(mess);
        this.errorCode = XMLDocumentException.UNDEFINED;
    }

    public XMLDocumentException(Throwable cause) {
        super(cause);
        if (cause instanceof XMLDocumentException) {
            this.errorCode = ((XMLDocumentException) cause).getErrorCode();
        } else {
            this.errorCode = XMLDocumentException.UNDEFINED;
        }
    }

    public XMLDocumentException(String mess, Throwable cause) {
        super(mess, cause);
        if (cause instanceof XMLDocumentException) {
            this.errorCode = ((XMLDocumentException) cause).getErrorCode();
        } else {
            this.errorCode = XMLDocumentException.UNDEFINED;
        }
    }

    public XMLDocumentException(String mess, String errCode) {
        super(mess);
        this.errorCode = errCode;
    }

    public XMLDocumentException(Throwable cause, String errCode) {
        super(cause);
        this.errorCode = errCode;
    }

    public XMLDocumentException(String mess, Throwable cause, String errCode) {
        super(mess, cause);
        this.errorCode = errCode;
    }

    public String getErrorCode() {
        return this.errorCode;
    }
}