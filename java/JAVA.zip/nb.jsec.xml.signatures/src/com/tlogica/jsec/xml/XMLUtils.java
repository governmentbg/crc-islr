package com.tlogica.jsec.xml;

import com.tlogica.jsec.xml.except.XMLDocumentException;
import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import com.tlogica.jsec.utils.StringOutputStream;
import com.tlogica.jsec.utils.StringUtils;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringReader;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class XMLUtils {
    // TODO remove this method. Always specify encoding explicitly

    public static String convertXMLNodeToString(Node node) {
	StringOutputStream sos = new StringOutputStream();
	writeXMLNodeToStream(node, sos);
	return sos.toString();
    }

    public static String convertXMLNodeToString(Node node, String encoding) {
	StringOutputStream sos = new StringOutputStream();
	writeXMLNodeToStream(node, sos, encoding);
	return sos.toString();
    }

    public static void writeXMLNodeToStream(Node node, OutputStream os) {
	//System.out.println("DEBUG: Convert XMLNode to byte stream");
	// This is strongly needed for non-ascii xml documents
	Document doc = null;
	if (node instanceof Document) {
	    doc = (Document) node;
	} else {
	    doc = node.getOwnerDocument();
	}
	if (doc != null) {
	    String outputEncoding = doc.getXmlEncoding();
	    //log.log(Level.INFO, "XMLEncoding: {0}; XML input Encoding: {1}", new Object[]{outputEncoding, doc.getInputEncoding()});
	    if (doc.getXmlEncoding() == null) {
		outputEncoding = "utf-8";
	    }
	    writeXMLNodeToStream(doc, os, outputEncoding);
	}
    }

    public static void writeXMLNodeToStream(Node node, OutputStream os, String encoding) {
	try {
	    TransformerFactory tf = TransformerFactory.newInstance();
	    Transformer transformer = tf.newTransformer();
	    transformer.setOutputProperty(OutputKeys.ENCODING, encoding);
	    if (os instanceof StringOutputStream) {
		((StringOutputStream) os).setEncoding(encoding);
	    }
	    transformer.transform(new DOMSource(node), new StreamResult(os));
	} catch (TransformerException ex) {
	    throw new RuntimeException("writeXMLNodeToStream(...)", ex);
	}
    }

    /**
     * Normalizes XML document removing all white spaces in it. This operation is contraversial for beautifying.
     */
    public static void normalizeXML(Node elem) {
	NodeList children = elem.getChildNodes();
	for (int ii = children.getLength() - 1; ii
		>= 0; ii--) {
	    Node child = children.item(ii);
	    switch (child.getNodeType()) {
		case Node.ELEMENT_NODE:
		    normalizeXML((Element) child);
		    break;
		case Node.CDATA_SECTION_NODE:
		case Node.TEXT_NODE:
		    if (StringUtils.isBlank(child.getNodeValue())) {
			elem.removeChild(child);
		    } else {
			elem.removeChild(child);
			Node newNode = elem.getOwnerDocument().createTextNode(child.getNodeValue().trim());
			elem.appendChild(newNode);
		    }
		    break;
		default:
		// do nothing
	    }
	}
    }

    public static Document parseString(String xmlText) {
	DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	factory.setNamespaceAware(true);
	Document doc = null;
	InputSource source = new InputSource(new StringReader(xmlText));
	try {
	    DocumentBuilder builder = factory.newDocumentBuilder();
	    // builder.setErrorHandler(new XMLErrorHandler());
	    doc = builder.parse(source);
	} catch (Exception ex) {
	    throw new RuntimeException(ex);
	}
	return doc;
    }

    public static String beautifyXML(String xmlText) throws XMLDocumentException, IOException {
	String encoding = "UTF-8";// default XML encoding
	String prolog = xmlText.substring(xmlText.indexOf("<?xml"), xmlText.indexOf("?>"));
	// <?xml version="1.0" encoding="utf-8" standalone="no" ?>
	int encodingIndex = prolog.indexOf("encoding=");
	// encoding is explicitly defined in the XML
	if (encodingIndex > 0) {
	    // utf-8" standalone="no"
	    String encodingPart = prolog.substring(encodingIndex + 9); //encoding=
	    int firstQuoteIndex = encodingPart.substring(1).indexOf("\"");
	    if (firstQuoteIndex > 0) {
		// remove entering and closing quote
		encoding = encodingPart.substring(1, firstQuoteIndex + 1);
	    } else
		encoding = encodingPart;
	}
	Document doc = parseString(xmlText);
	return beautifyXML(doc, encoding);
    }

    public static String beautifyXML(Node node, String encoding) throws XMLDocumentException, IOException {
	Document doc = node instanceof Document ? (Document) node : node.getOwnerDocument();
	StringOutputStream out = new StringOutputStream();
	out.setEncoding(encoding);
	OutputFormat format = new OutputFormat(doc);
	format.setLineWidth(65);
	format.setIndenting(true);
	format.setIndent(2);
	format.setEncoding(encoding);
	XMLSerializer serializer = new XMLSerializer(out, format);
	serializer.serialize(doc);
	return out.toString();
    }

    public static void main(String args[]) throws Exception {
	// text Y
	String xml = "<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"no\" ?><test></test>";
	String result = XMLUtils.beautifyXML(xml);


	// test X
	//testXalan();
	// TEST 1
//        try {
//            String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><VacationHomesList><test>...</test><test2/></VacationHomesList>";
//            String newXML = beautifyXML(xml);
//            System.out.println(newXML);
//        } catch (XMLDocumentConstructingException ex) {
//            Logger.getLogger(XMLUtils.class.getName()).log(Level.SEVERE, null, ex);
//        } catch (IOException ex) {
//            Logger.getLogger(XMLUtils.class.getName()).log(Level.SEVERE, null, ex);
//        }
	// TEST 2 - parsing string and beautifying
//        File xml = new File("test/xml/fileToSignFULL.xml");
//        XMLDocument xmlDoc = XMLDocumentReader.read(xml);
//        String text = convertXMLNodeToString(xmlDoc.getRoot());
//        System.out.println("Converted -> "+text);
//        String beautified = beautifyXML(text);
//        System.out.println(beautified);
    }

    private static void testXalan() throws Exception {
	DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	dbf.setNamespaceAware(true);
	//XMLDocument docToSign = XMLDocumentReader.read(new File("test/xml/fileToSign2.xml"));
	Document doc = dbf.newDocumentBuilder().newDocument(); //docToSign.getRoot();//

	System.out.println("Doc: " + XMLUtils.convertXMLNodeToString(doc, "windows-1251"));

//          try {
//            TransformerFactory tf = TransformerFactory.newInstance();
//            Transformer transformer = tf.newTransformer();
//            transformer.setOutputProperty(OutputKeys.ENCODING, "windows-1251");
//            System.out.println("CLASS: " + transformer.getClass());
//            System.out.println("Encoding property: " + transformer.getOutputProperty("encoding"));
//            transformer.transform(new DOMSource(doc), new StreamResult(System.out));
//        } catch (TransformerException ex) {
//            Logger.getLogger(XMLUtils.class.getName()).log(Level.SEVERE, null, ex);
//        }
    }
}
