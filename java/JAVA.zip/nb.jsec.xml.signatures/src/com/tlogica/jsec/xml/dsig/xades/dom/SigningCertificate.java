package com.tlogica.jsec.xml.dsig.xades.dom;

import com.tlogica.jsec.xml.DOMUtil;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Map;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class SigningCertificate {

    public static final String ID_KEY = "SIGN_CERT";
    private static final String ELEMENT_LOCAL_NAME = "SigningCertificate";
    private Element element;

    public SigningCertificate(Document doc, String prefix, Map<String, String> idMap) {
        Cert cert = new Cert(doc, prefix, idMap);
        // Set current time
        element = doc.createElementNS(XadesSignature.XMLNS_1_3_2, ELEMENT_LOCAL_NAME);
        element.setPrefix(prefix);
        DOMUtil.setNoNSId(element, idMap, ID_KEY);
        element.appendChild(cert.getDOMElement());
    }

    public Element getDOMElement() {
        return element;
    }
}
