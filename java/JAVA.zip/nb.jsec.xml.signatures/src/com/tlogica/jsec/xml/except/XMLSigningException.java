package com.tlogica.jsec.xml.except;

/**
 * General exception, which is thrown during deserialization process.
 * @author Miroslav Dzhokanov
 */
public class XMLSigningException extends Exception {

    public static final String UNDEFINED = "Undefined xml signing exception.";
    public static final String NOT_SIGNED_DOCUMENT = "Cannot countersign unsigned document.";
    public static final String BAD_CERTIFICATE_STRUCTURE = "Bad certificate structure.";
    private String errorCode;

    public XMLSigningException(String mess) {
        super(mess);
        this.errorCode = XMLDocumentException.UNDEFINED;
    }

    public XMLSigningException(Throwable cause) {
        super(cause);
        if (cause instanceof XMLDocumentException) {
            this.errorCode = ((XMLDocumentException) cause).getErrorCode();
        } else {
            this.errorCode = XMLDocumentException.UNDEFINED;
        }
    }

    public XMLSigningException(String mess, Throwable cause) {
        super(mess, cause);
        if (cause instanceof XMLDocumentException) {
            this.errorCode = ((XMLDocumentException) cause).getErrorCode();
        } else {
            this.errorCode = XMLDocumentException.UNDEFINED;
        }
    }

    public XMLSigningException(String mess, String errCode) {
        super(mess);
        this.errorCode = errCode;
    }

    public XMLSigningException(Throwable cause, String errCode) {
        super(cause);
        this.errorCode = errCode;
    }

    public XMLSigningException(String mess, Throwable cause, String errCode) {
        super(mess, cause);
        this.errorCode = errCode;
    }

    public String getErrorCode() {
        return this.errorCode;
    }
}