package com.tlogica.jsec.xml.dsig;

import com.tlogica.jsec.xml.except.XMLDocumentException;
import com.tlogica.jsec.core.x509.X509CertLoader;
import com.tlogica.jsec.core.x509.X509CertificateLoadingException;
import com.tlogica.jsec.utils.base64.Base64;
import com.tlogica.jsec.xml.XMLDocument;
import com.tlogica.jsec.xml.XMLUtils;
import java.io.IOException;
import java.security.cert.X509Certificate;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class XMLDigSignature {

    public final static String XMLNS = "http://www.w3.org/2000/09/xmldsig#";
    public static final String XMLNS_C14N_20010315 = "http://www.w3.org/TR/2001/REC-xml-c14n-20010315";
    public static final String XMLNS_C14N = "http://www.w3.org/2001/10/xml-exc-c14n#";
    protected Node m_signatureNode;
    private byte[] m_signatureValue;
    private String m_signatureMethod;
    private String m_canonicalizationMethod;
    private X509Certificate m_signerCertificate;
    private byte[] m_signerCertDigestValue;

    protected XMLDigSignature() {
    }

    public XMLDigSignature(Node node){
        m_signatureNode = node;
        parseSignature();
    }

    private void parseSignature(){
        if (m_signatureNode == null) {
            return;
        }
        parseSignatureValue();
        parseSignatureMethod();
        parseCanonicalizationMethod();
        parseSignerCertificate();
    }

    private void parseSignatureValue(){
        Node sigValNode = null;
        NodeList sigChildren = m_signatureNode.getChildNodes();
        if (sigChildren.getLength() != 0) {
            for (int i = 0; i < sigChildren.getLength(); i++) {
                Node n = sigChildren.item(i);
                if (n.getLocalName().equals("SignatureValue")) {
                    sigValNode = n;
                    break;
                }
            }
        }
        if (sigValNode == null) {
            throw new XMLDocumentException("<SignatureValue> was not found in the document.");
        }
        String encoded = sigValNode.getTextContent();
        // Signature value is found
        m_signatureValue = Base64.decode(encoded);
    }

    private void parseSignatureMethod() throws XMLDocumentException {
        Node signMethodNode = null;
        NodeList sigChildren = m_signatureNode.getChildNodes();
        if (sigChildren.getLength() != 0) {
            for (int i = 0; i < sigChildren.getLength(); i++) {
                Node n = sigChildren.item(i);
                if (n.getLocalName().equals("SignedInfo")) {
                    NodeList signedInfoChildren = n.getChildNodes();
                    if (signedInfoChildren.getLength() != 0) {
                        for (int j = 0; j < signedInfoChildren.getLength(); j++) {
                            Node n2 = signedInfoChildren.item(j);
                            if (n2.getLocalName().equals("SignatureMethod")) {
                                signMethodNode = n2;
                                break;
                            }
                        }
                    }
                    break;
                }
            }
        }
        if (signMethodNode == null) {
            throw new XMLDocumentException("<SignatureMethod> was not found in the document.");
        }
        NamedNodeMap attrMap = signMethodNode.getAttributes();
        if (attrMap != null && attrMap.getLength() > 0) {
            Node attr = attrMap.getNamedItem("Algorithm");
            // signature method is found
            m_signatureMethod = attr.getTextContent();
        }
    }

    private void parseCanonicalizationMethod() throws XMLDocumentException {
        Node c14nNode = null;
        NodeList sigChildren = m_signatureNode.getChildNodes();
        if (sigChildren.getLength() != 0) {
            for (int i = 0; i < sigChildren.getLength(); i++) {
                Node n = sigChildren.item(i);
                if (n.getLocalName().equals("SignedInfo")) {
                    NodeList signedInfoChildren = n.getChildNodes();
                    if (signedInfoChildren.getLength() != 0) {
                        for (int j = 0; j < signedInfoChildren.getLength(); j++) {
                            Node n2 = signedInfoChildren.item(j);
                            if (n2.getLocalName().equals("CanonicalizationMethod")) {
                                c14nNode = n2;
                                break;
                            }
                        }
                    }
                    break;
                }
            }
        }
        if (c14nNode == null) {
            throw new XMLDocumentException("<CanonicalizationMethod> was not found in the document.");
        }
        NamedNodeMap attrMap = c14nNode.getAttributes();
        if (attrMap != null && attrMap.getLength() > 0) {
            Node attr = attrMap.getNamedItem("Algorithm");
            // Canonicalization Method was found
            m_canonicalizationMethod = attr.getTextContent();
        }
    }

    private void parseSignerCertificate() throws XMLDocumentException {
        try {
            Node certNode = null;
            NodeList sigChildren = m_signatureNode.getChildNodes();
            if (sigChildren.getLength() != 0) {
                for (int i = 0; i < sigChildren.getLength(); i++) {
                    Node n = sigChildren.item(i);
                    if (n.getLocalName().equals("KeyInfo")) {
                        NodeList keyInfoChildren = n.getChildNodes();
                        if (keyInfoChildren.getLength() != 0) {
                            for (int j = 0; j < keyInfoChildren.getLength(); j++) {
                                Node n2 = keyInfoChildren.item(j);
                                if (n2.getLocalName().equals("X509Data")) {
                                    NodeList x509DataChildren = n2.getChildNodes();
                                    if (x509DataChildren.getLength() != 0) {
                                        for (int k = 0; k < x509DataChildren.getLength(); k++) {
                                            Node n3 = x509DataChildren.item(k);
                                            if (n3.getLocalName().equals("X509Certificate")) {
                                                certNode = n3;
                                                break;
                                            }
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                        break;
                    }
                }
            }
            if (certNode == null) {
                throw new XMLDocumentException("<X509Certificate> was not found in the document.");
            }
            String encoded = certNode.getTextContent();
            // Signer certificate was found
            m_signerCertificate = X509CertLoader.loadX509CertificateFromString(encoded);
        } catch (X509CertificateLoadingException ex) {
            throw new XMLDocumentException(ex);
        }
    }

    public String getCanonicalizationMethod() {
        return m_canonicalizationMethod;
    }

    public Node getSignatureNode() {
        return m_signatureNode;
    }

    public String getSignatureMethod() {
        return m_signatureMethod;
    }

    public byte[] getSignatureValue() {
        return m_signatureValue;
    }

    public byte[] getSignerCertDigestValue() {
        return m_signerCertDigestValue;
    }

    public X509Certificate getSignerCertificate() {
        return m_signerCertificate;
    }

    @Override
    public String toString() {
        String text = XMLUtils.convertXMLNodeToString(m_signatureNode);
        try {
            text = XMLUtils.beautifyXML(text);
        } catch (XMLDocumentException ex) {
            Logger.getLogger(XMLDocument.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(XMLDocument.class.getName()).log(Level.SEVERE, null, ex);
        }
        return text;
    }
}
