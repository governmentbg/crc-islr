package com.tlogica.jsec.xml.dsig;

import com.tlogica.jsec.core.pkcs.PKCS11KeyStore;
import com.tlogica.jsec.core.pkcs.PKCS12KeyStore;
import com.tlogica.jsec.utils.Digester;
import com.tlogica.jsec.utils.base64.Base64;
import com.tlogica.jsec.xml.*;
import com.tlogica.jsec.xml.XMLUtils;
import static com.tlogica.jsec.xml.dsig.XMLSignatureType.*;
import com.tlogica.jsec.xml.dsig.xades.dom.*;
import com.tlogica.jsec.xml.except.XMLDocumentException;
import com.tlogica.jsec.xml.except.XMLSigningException;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore.PrivateKeyEntry;
import java.security.*;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.crypto.MarshalException;
import javax.xml.crypto.dom.DOMStructure;
import javax.xml.crypto.dsig.*;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import javax.xml.crypto.dsig.spec.TransformParameterSpec;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.*;

/**
 * Задачата е да подпише xml-документ със един от подаденеите му private-ключове ...
 *
 * - подписва със xades - формата
 *
 * @author Miroslav Dzhokanov
 */
public class XMLSigner {

    public final static String XML_DSIG_PREFIX = "ds";
    public final static String XADES_DSIG_PREFIX = "xades";
    // XML Elements IDs
    final static String CONTENT_ENVELOPE_ID = "ContentEnvelope";
    final static String SIGNED_DOC_ENVELOPE_ID = "SignedDocEnvelope";
    final static String SIGNED_PROPERTIES_ID = "SignedPropertiesId";
    final static String UNSIGNED_PROPERTIES_ID = "UnsignedProperties";
    final static String SIGNATURE_TIMESTAMP_ID = "Timestamp";
    final static String ENCAPSULATED_TIMESTAMP_ID = "EncapTimestamp";
    final static String QUALIFYING_PROPERTIES_ID = "QualifyingProperties";
    // Signing configuration properties
    private XMLSignatureCategory sigCategory;
    private XMLSignatureType sigType;
    private PrivateKeyEntry privateKey;
    private X509Certificate cert;
    private XMLDocument xmlToSign;
    // 
    private Map<String, String> idMap = new HashMap<String, String>();
    // in eneveloped signatures programmer can choose where the specific signature
    // node to be situated. Following field defines the parent which will receive the
    // new child node
    private String parentNodeName = "";
    private String nextSiblingNodeName = "";

    public XMLSigner(XMLDocument documentToSign,
	    PrivateKeyEntry privateKey) {
	// define id attributes for specifid XML nodes of the Signature
	idMap.put(QualifyingProperties.ID_KEY, QUALIFYING_PROPERTIES_ID);
	idMap.put(SignedProperties.ID_KEY, SIGNED_PROPERTIES_ID);
	idMap.put(UnsignedProperties.ID_KEY, UNSIGNED_PROPERTIES_ID);
	idMap.put(SignatureTimestamp.ID_KEY, SIGNATURE_TIMESTAMP_ID);
	// add properties in the properties map
	idMap.put(XADES_DSIG_PREFIX, XADES_DSIG_PREFIX);
	idMap.put(XML_DSIG_PREFIX, XML_DSIG_PREFIX);
	// наслагвам основните настройки ...
	sigCategory = XMLSignatureCategory.XADES_T;
	sigType = ENVELOPED;
	// xml и ключ за подпис
	this.xmlToSign = documentToSign;
	this.privateKey = privateKey;
	// load data from the private key
	try {
	    cert = (X509Certificate) privateKey.getCertificate();
	    // certificate data
	    byte[] certBytes = cert.getEncoded();
	    String signAlg = cert.getSigAlgName().replaceAll("with.*", "");
	    if (certBytes != null) {
		Digester d = new Digester(signAlg);
		byte[] digested = d.digest(certBytes);
		idMap.put(CertDigest.CERT_DIGEST_VALUE, new String(Base64.encode(digested)));
		idMap.put(CertDigest.CERT_DIGEST_ALG, signAlg);
	    }
	    // issuer data
	    idMap.put(Cert.CERT_ISSUER_NAME, cert.getIssuerDN().getName());
	    idMap.put(Cert.CERT_ISSUER_SERIAL, cert.getSerialNumber().toString());
	} catch (Exception e) {
	    //log.log(Level.WARNING, "Unable to set <SignerCertificate> data.", e);
	}
    }

    public void setSignatureType(XMLSignatureType signatureType) {
	this.sigType = signatureType;
    }

    public void setSignatureCategory(XMLSignatureCategory category) {
	this.sigCategory = category;
    }

    public void setNewSignatureParentNode(String parentNodeName) {
	this.parentNodeName = parentNodeName;
    }

    public void setNewSignatureNextSiblingNode(String nextSiblingNodeName) {
	this.nextSiblingNodeName = nextSiblingNodeName;
    }

    /**
     * Returns current signature type - 'Detached', 'Enveloped' or 'Enveloping'
     *
     * @return
     */
    public XMLSignatureType getSignatureType() {
	return sigType;
    }

    public XMLSignatureCategory getCategoryType() {
	return sigCategory;
    }

    public XMLDocument sign() //
	    throws XMLSigningException, XMLDocumentException //
    {
	XMLDocument signedDoc = null;

	if (sigType == ENVELOPING) {
	    signedDoc = signEnveloping();
	} else if (sigType == ENVELOPED) {
	    signedDoc = signEnveloped();
	} else {
	    try {
		signedDoc = signDetached();
	    } catch (Exception ex) {
		Logger.getLogger(XMLSigner.class.getName()).log(Level.SEVERE, null, ex);
	    }
	}
	if (signedDoc != null) {
	    signedDoc.setIsSigned(true);
	}
	//log.info("------------------ FINISH SIGNING ------------------");

	return signedDoc;
    }

    private XMLDocument signEnveloping()
	    throws XMLSigningException, XMLDocumentException //
    {
	//log.info("Create Enveloping XML Signature");
	// Create a DOM XMLSignatureFactory that will be used to
	// generate the enveloped signature.
	XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM");

	// Instantiate the document to be signed.
	DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	dbf.setNamespaceAware(true);
	// Create the SignedInfo.
	List<String> elementsToBeSignedIDs = new LinkedList<String>();
	elementsToBeSignedIDs.add(CONTENT_ENVELOPE_ID);
	//if (isXadesSignature) {
	elementsToBeSignedIDs.add(SIGNED_PROPERTIES_ID);
	//}
	SignedInfo si = createSignedInfo(fac, elementsToBeSignedIDs);
	// Create the KeyInfo.
	KeyInfo ki = createKeyInfo(fac);
	// Create XML Objects to be signed.
	DOMStructure contentStruct = new DOMStructure(xmlToSign.getRoot().getDocumentElement());
	XMLObject contentObject = fac.newXMLObject(Collections.singletonList(contentStruct), CONTENT_ENVELOPE_ID, null, null);
	XMLObject qualPropsObject = createQualifyingPropsWithoutUnsignedProps(fac, dbf);
	List xmlObjectsToSign = new ArrayList();
	xmlObjectsToSign.add(qualPropsObject);
	xmlObjectsToSign.add(contentObject);
	// Create the XMLSignature, but don't sign it yet.
	XMLSignature signature = fac.newXMLSignature(si, ki, xmlObjectsToSign, "Signature", "SignatureValue");
	// Create a DOMSignContext and specify the RSA PrivateKey and
	// location of the resulting XMLSignature's parent element.
	Document doc = null;
	try {
	    doc = dbf.newDocumentBuilder().newDocument();
	} catch (ParserConfigurationException ex) {
	    //log.getLogger(XMLSigner.class.getName()).log(Level.WARNING, null, ex);
	    throw new XMLSigningException(ex);
	}
	DOMSignContext context = new DOMSignContext(privateKey.getPrivateKey(), doc);
	// Set caching on for debug purposes
	//context.setProperty("javax.xml.crypto.dsig.cacheReference", Boolean.TRUE);
	context.putNamespacePrefix(XMLSignature.XMLNS, XML_DSIG_PREFIX);
	context.putNamespacePrefix(XadesSignature.XMLNS_1_3_2, XADES_DSIG_PREFIX);
	try {
	    // Marshal, generate, and sign the signature.
	    signature.sign(context);
	} catch (MarshalException ex) {
	    //log.log(Level.WARNING, null, ex);
	    throw new XMLSigningException(ex);
	} catch (XMLSignatureException ex) {
	    //log.log(Level.WARNING, null, ex);
	    throw new XMLSigningException(ex);
	}
	// Register IDs in document (TODO - does not recognize XADES IDs)
	//log.log(Level.INFO, " DOCUMENT TO VALIDATE: {0}", XMLUtils.convertXMLNodeToString(doc));
	//XMLStructureValidator.validateXMLDSig(doc, XadesSignature.XMLNS_1_3_2);
	// Create unsigned properties element
	Element elUnsignedProps = new UnsignedProperties(doc, XADES_DSIG_PREFIX, idMap).getDOMElement();
	NodeList elQualPropsList = doc.getElementsByTagNameNS(XadesSignature.XMLNS_1_3_2, "QualifyingProperties");
	if (elQualPropsList.getLength() > 1) {
	    throw new XMLSigningException("Too many 'QualifyingProperties' xml nodes");
	}
	if (elQualPropsList.getLength() == 0) {
	    throw new XMLSigningException("'QualifyingProperties' node was not found");
	}
	elQualPropsList.item(0).appendChild(elUnsignedProps);
	XMLDocument signedXMLDocument = XMLDocumentReader.read(doc);
	signedXMLDocument.setEncoding(xmlToSign.getEncoding());

	return signedXMLDocument;
    }

    /**
     * Create references to the elements that are being signed. Uses SHA-1 alogorithm for constructing references.
     *
     * @param fac The same XMLSignatureFactory instance that is being used to create other XMLStructures of the
     * XMLSignature
     * @param referenceURIs Id values of the elements being signed
     * @return list of reference objects
     * @throws XMLSigningException when fatal inner exception occur
     */
    private List<Reference> createXadesReferences(XMLSignatureFactory fac, List<String> referenceURIs) throws XMLSigningException {
	// TODO enveloped signature needs different references

	List<Reference> references = new LinkedList<Reference>();
	Reference reference = null;
	for (String URI : referenceURIs) {
	    try {
		//log.log(Level.INFO, "Creating reference #{0}", URI);
		reference = fac.newReference("#" + URI, fac.newDigestMethod(DigestMethod.SHA1, null));
		references.add(reference);
	    } catch (NoSuchAlgorithmException ex) {
		throw new XMLSigningException(ex);
	    } catch (InvalidAlgorithmParameterException ex) {
		throw new XMLSigningException(ex);
	    }
	}

	return references;
    }

    /**
     * Create XML Digital Signature SignedInfo element.
     *
     * @param fac The same XMLSignatureFactory instance that is being used to create other XMLStructures of the
     * XMLSignature
     * @return SignedInfo object (contains references, canonicalization and signature methods)
     * @throws XMLSigningException when fatal inner problem has occured
     */
    private SignedInfo createSignedInfo(XMLSignatureFactory fac, List<String> referencedIDs) throws XMLSigningException {
	CanonicalizationMethod cm;
	try {
	    cm = fac.newCanonicalizationMethod(CanonicalizationMethod.INCLUSIVE_WITH_COMMENTS, (C14NMethodParameterSpec) null);
	    //cm = fac.newCanonicalizationMethod(CanonicalizationMethod.EXCLUSIVE, (C14NMethodParameterSpec) null);
	} catch (NoSuchAlgorithmException ex) {
	    throw new XMLSigningException(ex);
	} catch (InvalidAlgorithmParameterException ex) {
	    throw new XMLSigningException(ex);
	}
	SignatureMethod sm;
	try {
	    sm = fac.newSignatureMethod(SignatureMethod.RSA_SHA1, null);
	} catch (NoSuchAlgorithmException ex) {
	    throw new XMLSigningException(ex);
	} catch (InvalidAlgorithmParameterException ex) {
	    throw new XMLSigningException(ex);
	}

//        List<String> elementsToBeSignedIDs = new LinkedList<String>();
//        elementsToBeSignedIDs.add(CONTENT_ENVELOPE_ID);
//        if (isXadesSignature) {
//            elementsToBeSignedIDs.add(SIGNED_PROPERTIES_ID);
//        }
	List references = createXadesReferences(fac, referencedIDs);
	SignedInfo si = fac.newSignedInfo(cm, sm, references);

	return si;
    }

    /**
     * Create XML Digital Signature KeyInfo element, which contains the signer certificate.
     *
     * @param fac The same XMLSignatureFactory instance that is being used to create other XMLStructures of the
     * XMLSignature
     * @return KeyInfo object (contains X509Data element)
     * @throws XMLSigningException when fatal inner problem has occured
     */
    private KeyInfo createKeyInfo(XMLSignatureFactory fac) {
	// Create the KeyInfo containing the X509Data.
	KeyInfoFactory kif = fac.getKeyInfoFactory();
	List x509Content = new ArrayList();
	String subjectDN = cert.getSubjectDN().getName();

	x509Content.add(subjectDN.replace(" + ", ", "));
	x509Content.add(cert);
	X509Data xd = kif.newX509Data(x509Content);
	KeyInfo ki = kif.newKeyInfo(Collections.singletonList(xd));
	return ki;
    }

    /**
     * Creates fresh instance of the QualifyingProperties (XAdES) DOM structure and returns it as XMLObject. However,
     * this method skips creation of 'UnsignedProperties' object because it is created after signing process.
     *
     *
     * @param fac The same XMLSignatureFactory instance that is being used to create other XMLStructures of the
     * XMLSignature
     * @param dbf The same DocumentBuilderFactory instance that is being used to create other Document structures, used
     * by the XMLSignature
     * @return XMLObject which contains all XAdES structures
     * @throws XMLSigningException when fatal inner problem has occured
     */
    private XMLObject createQualifyingPropsWithoutUnsignedProps(XMLSignatureFactory fac, DocumentBuilderFactory dbf) throws XMLSigningException {

	Document doc = null;
	try {
	    doc = dbf.newDocumentBuilder().newDocument();
	} catch (ParserConfigurationException ex) {
	    throw new XMLSigningException(ex);
	}

	boolean includeUnsignedProps = false;
	QualifyingProperties qp = new QualifyingProperties(doc, XADES_DSIG_PREFIX, idMap, includeUnsignedProps);
	XMLObject qualPropsObject = fac.newXMLObject(
		Collections.singletonList(new DOMStructure(qp.getDOMElement())), null, null, null);

	return qualPropsObject;
    }

    /**
     * This method verifies whether certificate corresponds to IETF specifications. If bad certificate is detected then
     * exception is thrown.
     *
     * @param cert
     */
    static void checkCertificateStructure(X509Certificate cert) throws XMLSigningException {
	// First check - check AVA format (http://www.ietf.org/rfc/rfc1779.txt)
	KeyInfoFactory keyFactory = KeyInfoFactory.getInstance();
	List x509Content = new ArrayList();
	x509Content.add(cert.getSubjectDN().toString());
	try {
	    keyFactory.newX509Data(x509Content);
	} catch (java.lang.IllegalArgumentException ex) {
	    throw new XMLSigningException("Bad certificate structure.", ex, XMLSigningException.BAD_CERTIFICATE_STRUCTURE);
	}
    }

    private XMLDocument signEnveloped() throws XMLSigningException, XMLDocumentException {
	// Create a DOM XMLSignatureFactory that will be used to
	// generate the enveloped signature.
	XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM");

	SignedInfo si = null;
	try {
	    // Create a Reference to the enveloped document (in this case,
	    // you are signing the whole document, so a URI of "" signifies
	    // that
	    Reference ref = fac.newReference("", fac.newDigestMethod(DigestMethod.SHA1, null),
		    Collections.singletonList(fac.newTransform(Transform.ENVELOPED, (TransformParameterSpec) null)),
		    null, null);
	    Reference signedPropsReference = fac.newReference("#" + SIGNED_PROPERTIES_ID, fac.newDigestMethod(DigestMethod.SHA1, null));
	    List references = new LinkedList();
	    references.add(ref);
	    references.add(signedPropsReference);

	    // Create the SignedInfo.
	    si = fac.newSignedInfo(fac.newCanonicalizationMethod(CanonicalizationMethod.INCLUSIVE,
		    (C14NMethodParameterSpec) null),
		    fac.newSignatureMethod(SignatureMethod.RSA_SHA1, null),
		    references);
	} catch (Exception ex) {
	    throw new XMLSigningException(ex);
	}
	// Load the KeyStore and get the signing key and certificate.
	//X509Certificate cert = (X509Certificate) privateKey.getCertificate();

	// Create the KeyInfo containing the X509Data.
	KeyInfoFactory kif = fac.getKeyInfoFactory();
	List x509Content = new ArrayList();
	x509Content.add(cert.getSubjectX500Principal().getName());
	x509Content.add(cert);
	X509Data xd = kif.newX509Data(x509Content);
	KeyInfo ki = kif.newKeyInfo(Collections.singletonList(xd));

	// Instantiate the document to be signed.
	DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	dbf.setNamespaceAware(true);

	// Create a DOMSignContext and specify the RSA PrivateKey and
	// location of the resulting XMLSignature's parent element.
	Node parent = xmlToSign.getRoot().getDocumentElement();
	Node nextSibling = null;
	if (parentNodeName != null && !parentNodeName.equals("")) {
	    List<Node> parents = XMLNodeFinder.findNodesByName(xmlToSign.getRoot(), parentNodeName);
	    if (parents.size() == 1) {
		parent = parents.get(0);
		if (nextSiblingNodeName != null && !nextSiblingNodeName.equals("")) {
		    List<Node> siblings = XMLNodeFinder.findNodesByName(xmlToSign.getRoot(), nextSiblingNodeName);
		    if (siblings.size() == 1) {
			nextSibling = siblings.get(0);
		    } else if (siblings.isEmpty()) {
			throw new XMLSigningException("Sibling node '" + parentNodeName + "' not found");
		    } else {
			throw new XMLSigningException("Too many siblings '" + nextSiblingNodeName + "' were found - " + siblings.size());
		    }
		}
	    } else if (parents.isEmpty()) {
		throw new XMLSigningException("Parent node '" + parentNodeName + "' not found");
	    } else {
		throw new XMLSigningException("Too many parents '" + parentNodeName + "' were found - " + parents.size());
	    }
	}
	DOMSignContext dsc = null;
	// put the signature at specific place in the document
	if (nextSibling != null) {
	    dsc = new DOMSignContext(privateKey.getPrivateKey(), parent, nextSibling);
	} else {
	    dsc = new DOMSignContext(privateKey.getPrivateKey(), parent);
	}
	dsc.putNamespacePrefix(XMLDigSignature.XMLNS, "ds");
	// Create XML Objects to be signed.
	XMLObject qualPropsObject = createQualifyingPropsWithoutUnsignedProps(fac, dbf);
	List xmlObjectsToSign = new ArrayList();
	xmlObjectsToSign.add(qualPropsObject);

	// Create the XMLSignature, but don't sign it yet.
	XMLSignature signature = fac.newXMLSignature(si, ki, xmlObjectsToSign, "ID"+Math.random(), "ID"+Math.random());
	try {
	    // Marshal, generate, and sign the enveloped signature.
	    signature.sign(dsc);
	} catch (Exception ex) {
	    throw new XMLSigningException(ex); 
	}

	Document doc = xmlToSign.getRoot();
	// Create unsigned properties element
	Element elUnsignedProps = new UnsignedProperties(doc, XADES_DSIG_PREFIX, idMap).getDOMElement();
	NodeList elQualPropsList = doc.getElementsByTagNameNS(XadesSignature.XMLNS_1_3_2, "QualifyingProperties");
	if (elQualPropsList.getLength() > 1) {
	    throw new XMLSigningException("Too many 'QualifyingProperties' xml nodes");
	}
	if (elQualPropsList.getLength() == 0) {
	    throw new XMLSigningException("'QualifyingProperties' node was not found");
	}
	elQualPropsList.item(0).appendChild(elUnsignedProps);

	// read newly created DOM Document into XMLDocument object
	XMLDocument signedXMLDocument = XMLDocumentReader.read(doc);
	signedXMLDocument.setEncoding(xmlToSign.getEncoding());

	return signedXMLDocument;
    }

    private XMLDocument signDetached() throws Exception {
	//log.info("Create Detached XML Signature");
	// Create a DOM XMLSignatureFactory that will be used to
	// generate the enveloped signature.
	XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM");

	// Create a Reference to the enveloped document (in this case,
	// you are signing the whole document, so a URI of "" signifies
	// that, and also specify the SHA1 digest algorithm and
	// the ENVELOPED Transform.
	Reference contentReference = null;

	// Creating references for ENVELOPED signature
	if (sigType == ENVELOPED) {
	    contentReference = fac.newReference("",
		    fac.newDigestMethod(DigestMethod.SHA1, null),
		    Collections.singletonList(fac.newTransform(Transform.ENVELOPED,
		    (TransformParameterSpec) null)), null, null);
	} // Creating references for ENVELOPING signature
	else if (sigType == ENVELOPING) {
	    Document docToSign = xmlToSign.getRoot();
	    String elementToSignID = DOMUtil.getNodeId(docToSign);
	    Element contentEnvelopeElem = docToSign.createElementNS(XMLSignature.XMLNS, "Object");
	    contentEnvelopeElem.setPrefix(XML_DSIG_PREFIX);
	    contentEnvelopeElem.setAttribute("Id", CONTENT_ENVELOPE_ID);
	    contentEnvelopeElem.setIdAttribute("Id", true);

	    NodeList rootChildren = docToSign.getChildNodes();
	    for (int i = 0; i < rootChildren.getLength(); i++) {
		Node child = rootChildren.item(i);
		docToSign.removeChild(child);
		contentEnvelopeElem.appendChild(child);
	    }
	    elementToSignID = CONTENT_ENVELOPE_ID;
	    docToSign.appendChild(contentEnvelopeElem);
	    xmlToSign = XMLDocumentReader.read(docToSign);

	    // Creating reference to the element that is being signed
	    contentReference = fac.newReference("#" + elementToSignID, fac.newDigestMethod(DigestMethod.SHA1, null));
	} // Creating references for DETACHED signature
	else if (sigType == DETACHED) {
	    Document docToSign = xmlToSign.getRoot();
	    String elementToSignID = DOMUtil.getNodeId(docToSign);
	    Node elementToSign = null;
	    // If the document has only one child and the child has ID
	    // than there is no need to create envelope for the content nodes
	    if (docToSign.getChildNodes().getLength() == 1) {
		elementToSignID = DOMUtil.getNodeId(docToSign.getFirstChild());
		// if the first child element has ID attribute
		if (elementToSignID != null) {
		    // the element to sign is determined
		    elementToSign = docToSign.getFirstChild();
		}
	    }
	    // If the element to sign is not yet determined than create an
	    // envelope for all signable objects
	    if (elementToSign == null) {
		// Create envelope object when there are mutliple elements to
		// be signed or there is a signle signable element but with no Id
		Element contentEnvelopeElem = docToSign.createElementNS(XMLSignature.XMLNS, "Object");
		contentEnvelopeElem.setPrefix(XML_DSIG_PREFIX);
		contentEnvelopeElem.setAttribute("Id", CONTENT_ENVELOPE_ID);
		contentEnvelopeElem.setIdAttribute("Id", true);

		NodeList rootChildren = docToSign.getChildNodes();
		for (int i = 0; i < rootChildren.getLength(); i++) {
		    Node child = rootChildren.item(i);
		    docToSign.removeChild(child);
		    contentEnvelopeElem.appendChild(child);
		}

		elementToSign = contentEnvelopeElem;
		elementToSignID = CONTENT_ENVELOPE_ID;
	    }

	    // Create SignedDoc element, including content and its signature
	    Element signedDocEnvelopeElem = docToSign.createElementNS(XMLSignature.XMLNS, "SignedDoc");
	    signedDocEnvelopeElem.setPrefix(XML_DSIG_PREFIX);
	    signedDocEnvelopeElem.setAttribute("Id", SIGNED_DOC_ENVELOPE_ID);
	    signedDocEnvelopeElem.setIdAttribute("Id", true);
	    signedDocEnvelopeElem.appendChild(elementToSign);

	    docToSign.appendChild(signedDocEnvelopeElem);
	    xmlToSign = XMLDocumentReader.read(docToSign);

	    // Creating reference to the element that is being signed
	    contentReference = fac.newReference("#" + elementToSignID, fac.newDigestMethod(DigestMethod.SHA1, null));
	}
	//QUALIFYING_PROPERTIES REFERENCE
	Reference qualPropsReference = fac.newReference("#" + SIGNED_PROPERTIES_ID, fac.newDigestMethod(DigestMethod.SHA1, null));
	List references = new LinkedList();
	references.add(contentReference);
	references.add(qualPropsReference);
	// Create the SignedInfo.
	CanonicalizationMethod cm = null;
	if (this.sigType == ENVELOPING) {
//                    SignedInfo si = fac.newSignedInfo(fac.newCanonicalizationMethod(
//                       CanonicalizationMethod.INCLUSIVE_WITH_COMMENTS,
//                       (C14NMethodParameterSpec) null),
//                       fac.newSignatureMethod(SignatureMethod.DSA_SHA1, null),
//                       Collections.singletonList(ref));

	    cm = fac.newCanonicalizationMethod(CanonicalizationMethod.INCLUSIVE_WITH_COMMENTS, (C14NMethodParameterSpec) null);
	} else {
	    cm = fac.newCanonicalizationMethod(CanonicalizationMethod.EXCLUSIVE, (C14NMethodParameterSpec) null);
	}
	SignatureMethod sm = fac.newSignatureMethod(SignatureMethod.RSA_SHA1, null);
	SignedInfo si = fac.newSignedInfo(cm, sm, references);
	//X509Certificate cert = (X509Certificate) privateKey.getCertificate();

	// Create the KeyInfo containing the X509Data.
	KeyInfoFactory kif = fac.getKeyInfoFactory();
	List x509Content = new ArrayList();
	x509Content.add(cert.getSubjectX500Principal().getName());
	x509Content.add(cert);
	X509Data xd = kif.newX509Data(x509Content);
	KeyInfo ki = kif.newKeyInfo(Collections.singletonList(xd));

	// Instantiate the document to be signed.
	DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	dbf.setNamespaceAware(true);
	Document documentToSign = xmlToSign.getRoot();

	//7. Create the QualifyingProperties (XAdES) structure:
	//Document doc = dbf.newDocumentBuilder().newDocument();
	Element elQualifProp = documentToSign.createElementNS(XadesSignature.XMLNS_1_3_2, "QualifyingProperties");
	elQualifProp.setPrefix(XADES_DSIG_PREFIX);

	Element elSignedSignatureProperties = documentToSign.createElementNS(XadesSignature.XMLNS_1_3_2, "SignedSignatureProperties");
	elSignedSignatureProperties.setPrefix(XADES_DSIG_PREFIX);
	Element elSignedProperties = documentToSign.createElementNS(XadesSignature.XMLNS_1_3_2, "SignedProperties");
	elSignedProperties.setPrefix(XADES_DSIG_PREFIX);
	elSignedProperties.setAttribute("ID", SIGNED_PROPERTIES_ID);
	elSignedProperties.setIdAttribute("ID", true);

//        Element elTime = documentToSign.createElementNS(XadesSignature.XMLNS_1_3_2, "SigningTime");
//        Calendar calendar = Calendar.getInstance();
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
//        StringBuilder sb = new StringBuilder(sdf.format(calendar.getTime()));
//        elTime.appendChild(documentToSign.createTextNode(sb.toString()));
//        elTime.setPrefix(XADES_DSIG_PREFIX);
//
//        elSignedSignatureProperties.appendChild(elTime);
//        elSignedProperties.appendChild(elSignedSignatureProperties);
//        elQualifProp.appendChild(elSignedProperties);
//        elQualifProp.setAttribute("Target", "#Signature");
//
//        System.out.println("TEST: " + XMLUtils.convertXMLNodeToString(documentToSign));
//        System.out.println("TEST: " + XMLUtils.convertXMLNodeToString(elQualifProp));
//
//        documentToSign.appendChild(elQualifProp);
	System.out.println("Child: " + documentToSign.getChildNodes().getLength());
	//8. Create the Object structure - needed for enveloping signature
	XMLObject qualPropsObject = fac.newXMLObject(Collections.singletonList(new DOMStructure(elQualifProp)), null, null, null);
	XMLObject contentObject = fac.newXMLObject(Collections.singletonList(new DOMStructure(documentToSign.getDocumentElement())), null, null, null);



	// Create a DOMSignContext and specify the RSA PrivateKey and
	// location of the resulting XMLSignature's parent element.

	XMLDocument signedXML = null;
	if (sigType == ENVELOPING) {
	    Document emptyDoc = dbf.newDocumentBuilder().newDocument();
	    DOMSignContext context = new DOMSignContext(privateKey.getPrivateKey(), emptyDoc);
	    // Set caching on for debug purposes
	    context.putNamespacePrefix(XMLSignature.XMLNS, XML_DSIG_PREFIX);
	    context.putNamespacePrefix(XadesSignature.XMLNS_1_3_2, XADES_DSIG_PREFIX);
	    context.setProperty("javax.xml.crypto.dsig.cacheReference", Boolean.TRUE);
	    List xmlObjects = new ArrayList();
	    xmlObjects.add(qualPropsObject);
	    xmlObjects.add(contentObject);

	    // Create the XMLSignature, but don't sign it yet.
	    XMLSignature signature = fac.newXMLSignature(si, ki, xmlObjects, "Signature", "SignatureValue");
	    // Marshal, generate, and sign the enveloped signature.
	    signature.sign(context);

	    try {
		System.out.println("XML[ENVELOPING]:\n" + XMLUtils.beautifyXML(XMLUtils.convertXMLNodeToString(emptyDoc)));
	    } catch (IOException ex) {
		Logger.getLogger(XMLSigner.class.getName()).log(Level.SEVERE, null, ex);
	    }
	    signedXML = XMLDocumentReader.read(emptyDoc);
	} // ENVELOPED, DETACHED
	else {
	    DOMSignContext context = new DOMSignContext(privateKey.getPrivateKey(), xmlToSign.getRoot());
	    // Set caching on for debug purposes
	    context.putNamespacePrefix(XMLSignature.XMLNS, XML_DSIG_PREFIX);
	    context.putNamespacePrefix(XadesSignature.XMLNS_1_3_2, XADES_DSIG_PREFIX);
	    context.setProperty("javax.xml.crypto.dsig.cacheReference", Boolean.TRUE);

	    // Create the XMLSignature, but don't sign it yet.
	    XMLSignature signature = fac.newXMLSignature(si, ki);
	    // Marshal, generate, and sign the enveloped signature.
	    signature.sign(context);


	    try {
		System.out.println("XML [DETACHED/ENVELOPED]:\n" + XMLUtils.beautifyXML(XMLUtils.convertXMLNodeToString(xmlToSign.getRoot())));
	    } catch (IOException ex) {
		Logger.getLogger(XMLSigner.class.getName()).log(Level.SEVERE, null, ex);
	    }
	    signedXML = XMLDocumentReader.read(xmlToSign.getRoot());
	}
	return signedXML;
    }

    /**
     * Currently works only with XAdES signatures.
     *
     * @param xmlDoc
     * @return
     * @throws XMLSigningException
     */
    public XMLDocument counterSignDocument(XMLDocument xmlDoc) throws XMLSigningException {
	XMLDocument signedXML = xmlDoc.clone();
	// Checks whether the document is signed
	if (!signedXML.isSigned()) {
	    throw new XMLSigningException("Passed XML document is not signed. Countersigning process failed.", XMLSigningException.NOT_SIGNED_DOCUMENT);
	}
	Document signedDoc = signedXML.getRoot();
	Node elementToSign = signedDoc.getElementsByTagNameNS(XMLSignature.XMLNS, "SignatureValue").item(0);
	if (elementToSign == null) {
	    throw new XMLSigningException("SignatureValue element could not be found.");
	}
	// Checks whether the document has countersignature
	NodeList counterSignatures = signedDoc.getElementsByTagName("CounterSignature");
	if (counterSignatures.getLength() > 0) {
	    //log.warning("Document has already been countersigned.");
	    // Get last countersignature
	    int lastCounterIndex = counterSignatures.getLength() - 1;
	    // Get Signature element
	    Node elCounterSignature = counterSignatures.item(lastCounterIndex).getFirstChild();
	    if (elCounterSignature != null) {
		// Get SignatureValue
		elementToSign = elCounterSignature.getLastChild();
	    }
	}
	// Determine xml element to be signed
	XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM");
	// Get SignatureValue Id
	String signatureValueId = null;
	NamedNodeMap sigValAttrs = elementToSign.getAttributes();
	if (sigValAttrs != null) {
	    Node signatureValueAttr = sigValAttrs.getNamedItem("Id");
	    if (signatureValueAttr != null) {
		signatureValueId = ((Attr) signatureValueAttr).getValue();
	    } else {
		throw new XMLSigningException("SignatureValue element does not have 'Id' attribute.");
	    }
	} else {
	    throw new XMLSigningException("SignatureValue element does not have 'Id' attribute.");
	}
	// Sign (encrypt) digest result
	SignedInfo si = createSignedInfo(fac, Arrays.asList(signatureValueId));
	KeyInfo ki = createKeyInfo(fac);
	XMLSignature signature = fac.newXMLSignature(si, ki, null, "CounterSignature", "CounterSignatureValue");

	DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	dbf.setNamespaceAware(true);
//        Document doc = null;
//        try {
//            doc = dbf.newDocumentBuilder().newDocument();
//        } catch (ParserConfigurationException ex) {
//            //log.getLogger(XMLSigner.class.getName()).log(Level.WARNING, null, ex);
//            throw new XMLSigningException(ex);
//        }
	Node parent = signedDoc.getElementsByTagNameNS(XadesSignature.XMLNS_1_3_2, "UnsignedSignatureProperties").item(0);
	Node elCounterSignature = signedDoc.createElementNS(XadesSignature.XMLNS_1_3_2, "CounterSignature");
	elCounterSignature.setPrefix(XADES_DSIG_PREFIX);
	parent.appendChild(elCounterSignature);
	if (parent == null) {
	    throw new XMLSigningException("Parent node could not be found.");
	}

	DOMSignContext context = new DOMSignContext(privateKey.getPrivateKey(), elCounterSignature);
	// Set caching on for debug purposes
	context.setProperty("javax.xml.crypto.dsig.cacheReference", Boolean.TRUE);
	context.putNamespacePrefix(XMLSignature.XMLNS, XML_DSIG_PREFIX);
	context.putNamespacePrefix(XadesSignature.XMLNS_1_3_2, XADES_DSIG_PREFIX);
	try {
	    // Marshal, generate, and sign the signature.
	    signature.sign(context);
	} catch (MarshalException ex) {
	    //log.log(Level.WARNING, null, ex);
	    throw new XMLSigningException(ex);
	} catch (XMLSignatureException ex) {
	    //log.log(Level.WARNING, null, ex);
	    throw new XMLSigningException(ex);
	}

	return signedXML;
    }

    // подписването с PKCS#11
    public static XMLDocument sign(XMLDocument documentToSign, String pin) throws Exception //
    {
	XMLDocument signedDoc = null;
	boolean break_ = false;
	// предусловия
	// 1) частен ключ
	PKCS11KeyStore ks = new PKCS11KeyStore();
	// 2) документ за подписване
	// documentToSign
	// 3) пробвам да подпиша със различните dll спирам при първият добър
	List<Provider> providers = ks.step1();
	for (Provider provider : providers) {
	    // добавям
	    Security.addProvider(provider);
	    System.out.printf("+ provider[%s,%d]\n", provider.getName(), provider.hashCode());
	    // зареждам 
	    KeyStore keyStore = null;
	    try {
		// опитвам да се свържа
		keyStore = KeyStore.getInstance("PKCS11", provider);
		keyStore.load(null, pin.toCharArray());
		// какво има в устройството ?
		Enumeration<String> en = keyStore.aliases();
		while (en.hasMoreElements() && !break_) {
		    String alias = en.nextElement();
		    KeyStore.Entry key = keyStore.getEntry(alias, null);
		    // имам ли PrivateKey вътре
		    if (key instanceof PrivateKeyEntry) {
			System.out.printf(" + alias=%s\n", alias);
			// пробвам се да подпиша 
			try {
			    XMLSigner signer = new XMLSigner(documentToSign, (PrivateKeyEntry) key);
			    signer.setSignatureType(ENVELOPED);
			    signedDoc = signer.sign();
			    break_ = true;
			} catch (Exception e) {
			    System.out.println("--------------- XMLSigner.sign(...) ---------------");
			    System.out.printf(" неможах да подпша със ключ = %s\n", alias);
			    e.printStackTrace(System.out);
			}
		    }
		}
	    } catch (Exception e) {
		System.out.println("--------------- XMLSigner.sign(...) ---------------");
		System.out.printf(" неможах да заредя устроиството \n");
		e.printStackTrace(System.out);
		Throwable cause = e;
		while (cause.getCause() != null) {
		    cause = cause.getCause();
		}
		System.out.printf("! provider[%s]:%s\n", provider.getName(), cause.getMessage());
	    }
	    // махам 
	    Security.removeProvider(provider.getName());
	    System.out.printf("- provider[%s,%d]\n", provider.getName(), provider.hashCode());
	    // успешно подписах
	    if (break_)
		break;
	}
	// ключово, за да не се кешира login
	ks.step0();
	// има ли грешки ?
	if (signedDoc == null) {
	    throw new RuntimeException(" Не можах да подпиша. ");
	}
	return signedDoc;
    }

    // подписването с PKCS#12
    public static XMLDocument sign(
	    XMLDocument documentToSign,
	    InputStream keyStore,
	    String keyStorePass,
	    String keyAlias,
	    String keyPass)
	    throws Exception //
    {
	XMLDocument signedDoc = null;
	PKCS12KeyStore ks = new PKCS12KeyStore(keyStore, keyStorePass, keyAlias, keyPass);

	// подписване
	XMLSigner signer = new XMLSigner(documentToSign, ks.getPrivateKey());
	signer.setSignatureType(ENVELOPED);
	signedDoc = signer.sign();
	return signedDoc;
    }

    public static void main(String args[]) throws Exception {

	// pkcs11
	XMLDocument docToSign = XMLDocumentReader.read("<ns0:grantAccess xmlns:ns0=\"http://nhif.bg/xsd/pis\">\n"
		+ "  <ns0:uin>0001</ns0:uin>\n"
		+ "  <ns0:owner>\n"
		+ "    <ns0:egn>7012241917</ns0:egn>\n"
		+ "  </ns0:owner>\n"
		+ "  <ns0:provider>\n"
		+ "    <ns0:egn>7012241917</ns0:egn>\n"
		+ "  </ns0:provider>\n"
		+ "  <ns0:from>2012-12-18T00:00:00</ns0:from>\n"
		+ "  <ns0:to>2012-12-19T00:00:00</ns0:to> \n"
		+ "  <ns1:signTag xmlns:ns1=\"http://nhif.bg/xsd/pis1\"/>\n"
		+ "</ns0:grantAccess>");
	XMLDocument signedDoc = XMLSigner.sign(docToSign, "1234");
	System.out.println(signedDoc);
	
	
	// Cannot resolve element with ID SignedPropertiesId
	//at com.tlogica.jsec.xml.dsig.XMLSigner.signEnveloped(XMLSigner.java:453)
	//at com.tlogica.jsec.xml.dsig.XMLSigner.sign(XMLSigner.java:140)
	//at com.tlogica.jsec.xml.dsig.XMLSigner.sign(XMLSigner.java:804)



//	// pkcs12
//	XMLDocument docToSign = XMLDocumentReader.read("<t>tsanko/" + System.currentTimeMillis() + "</t>"); 
//	XMLDocument signedDoc = XMLSigner.sign(docToSign, 
//		XMLSigner.class.getResourceAsStream("000053191.p12"),
//		"000053191", 
//		null, 
//		"000053191");
//	System.out.println(signedDoc); 
    }
}
