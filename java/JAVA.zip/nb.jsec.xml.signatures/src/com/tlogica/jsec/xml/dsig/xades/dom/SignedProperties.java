package com.tlogica.jsec.xml.dsig.xades.dom;

import com.tlogica.jsec.xml.DOMUtil;
import java.util.Map;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class SignedProperties {
    public final static String REFERENCE_TYPE = "http://uri.etsi.org/01903#SignedProperties";
    public static final String ID_KEY = "SP";
    private static final String ELEMENT_LOCAL_NAME = "SignedProperties";
    private Element element;
    private SignedSignatureProperties signedSignatureProperties;

    public SignedProperties(Document doc, String prefix, Map<String, String> idMap){
        signedSignatureProperties = new SignedSignatureProperties(doc, prefix, idMap);
        element = doc.createElementNS(XadesSignature.XMLNS_1_3_2, ELEMENT_LOCAL_NAME);
        element.setPrefix(prefix);
        // append child nodes
        element.appendChild(signedSignatureProperties.getDOMElement());
        DOMUtil.setNoNSId(element, idMap, ID_KEY);
    }

    public Element getDOMElement() {
        return element;
    }

    public SignedSignatureProperties getSignedSignatureProperties() {
        return signedSignatureProperties;
    }    
}
