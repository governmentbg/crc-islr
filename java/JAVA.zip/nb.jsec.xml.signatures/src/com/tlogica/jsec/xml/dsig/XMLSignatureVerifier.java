package com.tlogica.jsec.xml.dsig;

import com.tlogica.jsec.xml.except.XMLDocumentException;
import com.sun.org.apache.xml.internal.security.c14n.CanonicalizationException;
import com.sun.org.apache.xml.internal.security.c14n.Canonicalizer;
import com.sun.org.apache.xml.internal.security.c14n.InvalidCanonicalizerException;
import com.tlogica.jsec.core.verification.VerificationException;
import com.tlogica.jsec.utils.base64.Base64;
import com.tlogica.jsec.xml.XMLDocument;
import com.tlogica.jsec.xml.XMLStructureValidator;
import com.tlogica.jsec.timestamp.Timestamp;
import com.tlogica.jsec.xml.DOMUtil;
import com.tlogica.jsec.xml.dsig.xades.dom.XadesSignature;
import java.security.GeneralSecurityException;
import java.util.Iterator;
import java.util.List;
import javax.xml.crypto.MarshalException;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureException;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class XMLSignatureVerifier {

    /**
     * @param document signed xml document
     * @throws VerificationException
     * @throws GeneralSecurityException if a processing exception occur and
     *          verification was not completed
     */
    public static void verifySignedXMLDocument(XMLDocument document)
            throws VerificationException, //
            GeneralSecurityException //
    {
        verifySignatures(document.getRoot());
    }

    /**
     * @param doc DOM Document representing root element of signed xml document
     * @throws VerificationException 
     * @throws GeneralSecurityException
     */
    public static void verifySignatures(Document doc)
            throws VerificationException, //
            GeneralSecurityException //
    {
        // Find Signature element.
        try {
            List<Node> sigNodes = DOMUtil.getSignatureNodes(doc);

            if (sigNodes.isEmpty()) {
                throw new GeneralSecurityException("Cannot find 'Signature' element in the xml document.");
            }

            for (Node sigNode : sigNodes) {
                // Validate XML toward XSD
                XMLStructureValidator.validateXMLDSig(sigNode, XadesSignature.XMLNS_1_3_2);

                // Create a DOMValidateContext and specify a KeySelector
                // and document context.
                DOMValidateContext valContext = new DOMValidateContext(new X509KeySelector(), sigNode);

                // Set caching on for debug purposes
                valContext.setProperty("javax.xml.crypto.dsig.cacheReference", Boolean.TRUE);
                //valContext.setBaseURI("http://uri.etsi.org/01903/v1.3.2#");

                // Unmarshal the XMLSignature.
                XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM");
                XMLSignature signature = null;
                try {
                    signature = fac.unmarshalXMLSignature(valContext);
                } catch (MarshalException ex) {
                    throw new GeneralSecurityException(ex);
                }

                // Validate the XMLSignature.
                boolean isCoreValid = false;
                try {
                    isCoreValid = signature.validate(valContext);
                } catch (XMLSignatureException ex) {
                    throw new GeneralSecurityException(ex);
                }

                //  Check core validation status.
                if (isCoreValid == false) {
                    boolean isSignatureValid = false;
                    try {
                        isSignatureValid = signature.getSignatureValue().validate(valContext);
                    } catch (XMLSignatureException ex) {
                        throw new GeneralSecurityException(ex);
                    }
                    if (!isSignatureValid) {
                        // Check the validation status of each Reference.
                        Iterator i = signature.getSignedInfo().getReferences().iterator();
                        for (int j = 0; i.hasNext(); j++) {
                            boolean refValid = false;
                            try {
                                refValid = ((Reference) i.next()).validate(valContext);
                            } catch (XMLSignatureException ex) {
                                throw new GeneralSecurityException(ex);
                            }
                            if (!refValid) {
                                throw new VerificationException("Signature failed core validation.");
                            }
                        }
                    }
                }
            }
        } catch (XMLDocumentException e) {
            throw new VerificationException(e);
        }

        // Validate timestamp
        NodeList elTimestamps = doc.getElementsByTagNameNS(XadesSignature.XMLNS_1_3_2, "EncapsulatedTimeStamp");
        int timestamps = elTimestamps.getLength();
        if (timestamps > 0) {
            for (int i = 0; i < timestamps; i++) {
                Node elTimestamp = elTimestamps.item(i);
                Node elCanonicalizeAlg = elTimestamp.getPreviousSibling();
                String algorithmURI = null;
                if (elCanonicalizeAlg != null) {
                    Node attrAlg = elCanonicalizeAlg.getAttributes().getNamedItem("Algorithm");
                    algorithmURI = attrAlg.getNodeValue();
                }
                if (algorithmURI == null) {
                    algorithmURI = XMLDigSignature.XMLNS_C14N;
                }
                NodeList sigVals = doc.getElementsByTagNameNS(XMLSignature.XMLNS, "SignatureValue");
                if (sigVals.getLength() == 0) {
                    throw new GeneralSecurityException("Unable to find <SignatureValue> element.");
                }
                Node elSignature = sigVals.item(0);

                // Canonicalize signature value
                Canonicalizer c14n = null;
                try {
                    c14n = Canonicalizer.getInstance(algorithmURI);
                } catch (InvalidCanonicalizerException ex) {
                    throw new GeneralSecurityException(ex);
                }
                byte[] sigValBytes;
                try {
                    sigValBytes = c14n.canonicalizeSubtree(elSignature);
                } catch (CanonicalizationException ex) {
                    throw new GeneralSecurityException(ex);
                }

                String encodedTS = elTimestamp.getTextContent();
                if ("".equals(encodedTS)) {
                    throw new VerificationException("Signature has not been timestamped.",
                            VerificationException.XML_SIGNATURE_NOT_TIMESTAMPED);
                }

                byte[] decodedTS = Base64.decode(encodedTS);
                Timestamp timestamp = new Timestamp(decodedTS);
                // Verify Timestamp
                boolean timestampVerified = timestamp.verify(sigValBytes);
                if (!timestampVerified) {
                    throw new VerificationException("Timestamp verification failed.",
                            VerificationException.XML_SIGNATURE_TIMESTAMP_NOT_VALID);
                }
            }
        } else {
            throw new VerificationException("XML Signature is not timestamped.",
                    VerificationException.XML_SIGNATURE_NOT_TIMESTAMPED);
        }
    }
}
