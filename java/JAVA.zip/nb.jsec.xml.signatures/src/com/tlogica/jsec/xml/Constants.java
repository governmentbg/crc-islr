package com.tlogica.jsec.xml;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class Constants {
    public static final String PROPERTIES_FILE_URL = "resources/jsec_xml.properties";
    public static final String XMLDSIG_SCHEMA_LOCATION_PARAM = "xmldsig_schema_path";
    public static final String XADES_1_1_1_SCHEMA_LOCATION_PARAM = "xades_1_1_1_schema_path";
    public static final String XADES_1_3_2_SCHEMA_LOCATION_PARAM = "xades_1_3_2_schema_path";
    public static final String VALIDATE_XML_ON_READING = "validate_xml_on_reading";
    public static final String ALWAYS_COPY_XSD_TO_TEMP_FILES = "always_copy_xsd_to_temp_files";
}
