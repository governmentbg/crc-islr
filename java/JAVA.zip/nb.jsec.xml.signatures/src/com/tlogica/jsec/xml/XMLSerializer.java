package com.tlogica.jsec.xml;

import com.tlogica.jsec.xml.except.XMLDocumentException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class XMLSerializer {

    private static final Logger log = Logger.getLogger("com.tlogica.jsec.xml.XMLSerializer");

    public static void saveXMLDocumentToFile(XMLDocument doc, File file) throws IOException {
	log.log(Level.INFO, "Storing XML Document to file - {0}", file.getAbsolutePath()
		+ "(Encoding:" + doc.getEncoding() + ")");
	FileOutputStream fstream = null;
	try {
	    String xmlText = XMLUtils.convertXMLNodeToString(doc.getRoot(), doc.getEncoding());
	    xmlText = XMLUtils.beautifyXML(xmlText);
	    fstream = new FileOutputStream(file);
	    Writer out = new OutputStreamWriter(fstream, doc.getEncoding());
	    out.write(xmlText);
	    //Close the output stream
	    out.close();
	} catch (Exception ex) {
	    throw new XMLDocumentException(ex);
	} finally {
	    try {
		fstream.close();
	    } catch (Exception ex) {
		Logger.getLogger(XMLSerializer.class.getName()).log(Level.SEVERE, null, ex);
	    }
	}
    }

    public static void main(String args[]) throws Exception {
	test1();
    }

    private static void test1() throws Exception {
	File fin = new File("test/xml/signedDoc_Mine_NonASCII_X509Data_2.xml");
	System.out.println("Reading from " + fin.getAbsolutePath());
	XMLDocument doc = XMLDocumentReader.read(fin);
	File fout = new File("test/xml/signedDoc_Mine_NonASCII_COPY.xml");
	System.out.println("Writing to " + fout.getAbsolutePath());
	saveXMLDocumentToFile(doc, fout);
    }
}
