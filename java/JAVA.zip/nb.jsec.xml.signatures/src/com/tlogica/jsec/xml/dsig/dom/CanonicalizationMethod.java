package com.tlogica.jsec.xml.dsig.dom;

import com.tlogica.jsec.xml.DOMUtil;
import com.tlogica.jsec.xml.dsig.XMLDigSignature;
import java.util.Map;
import javax.xml.crypto.dsig.XMLSignature;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class CanonicalizationMethod {
    public static final String ID_KEY = "CM";
    private static final String ELEMENT_LOCAL_NAME = "CanonicalizationMethod";
    private Element element;

    public CanonicalizationMethod(Document doc, String prefix, Map<String, String> idMap) {

        element = doc.createElementNS(XMLSignature.XMLNS, ELEMENT_LOCAL_NAME);
        // TODO add canonicalization method as property 
        element.setAttributeNS(null, "Algorithm", XMLDigSignature.XMLNS_C14N);
        element.setPrefix(prefix);
        DOMUtil.setNoNSId(element, idMap, ID_KEY);
    }

    public Element getDOMElement() {
        return element;
    }
}
