package com.tlogica.jsec.xml.dsig;

/**
 * 
 * @author Miroslav Dzhokanov
 */
public enum XMLSignatureCategory {
    XML_DSIG,   // standart XML signature
    XADES,      // + basic XAdES impl. (and signing time)
    XADES_T,    // + timestamp
    XADES_C,    // + adding verification data (issuer's verification status, OCSP response
                // and relevant OCSP certificates),
                // allowing future offline verification
    XADES_X,    // + timestamps on the issuer certificate and CRL references
                // (defines the date of initial verification)
    XADES_XL,   // + adding issuer certificate chain and CRL to allow verification even after
                // the issuer certificates expiration
    XADES_A     // + adding timestamps periodically 
}
