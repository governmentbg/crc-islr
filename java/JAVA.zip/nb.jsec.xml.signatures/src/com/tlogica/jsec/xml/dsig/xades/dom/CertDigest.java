package com.tlogica.jsec.xml.dsig.xades.dom;

import com.tlogica.jsec.xml.DOMUtil;
import com.tlogica.jsec.xml.dsig.XMLDigSignature;
import com.tlogica.jsec.xml.dsig.XMLSigner;
import java.util.Map;
import java.util.logging.Logger;
import javax.xml.crypto.dsig.DigestMethod;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class CertDigest {

    public static final String ID_KEY = "CERT_DIGEST";
    public static final String CERT_DIGEST_VALUE = "certificateDigestVal";
    public static final String CERT_DIGEST_ALG = "certificateDigestAlg";
    private static final String ELEMENT_LOCAL_NAME = "CertDigest";
    private Element element;

    public CertDigest(Document doc, String prefix, Map<String, String> idMap) {
        // Create main element
        element = doc.createElementNS(XadesSignature.XMLNS_1_3_2, ELEMENT_LOCAL_NAME);
        //element.appendChild();
        element.setPrefix(prefix);
        DOMUtil.setNoNSId(element, idMap, ID_KEY);


        String algorithm = idMap.get(CERT_DIGEST_ALG);
        if (algorithm != null) {
            Element elDigestMethod = doc.createElementNS(XMLDigSignature.XMLNS, "DigestMethod");
            elDigestMethod.setAttributeNS("", "Algorithm", DigestMethod.SHA1);
            elDigestMethod.setPrefix(idMap.get(XMLSigner.XML_DSIG_PREFIX));

            Element elDigestValue = doc.createElementNS(XMLDigSignature.XMLNS, "DigestValue");
            elDigestValue.setTextContent(idMap.get(CERT_DIGEST_VALUE));
            elDigestValue.setPrefix(idMap.get(XMLSigner.XML_DSIG_PREFIX));
            element.appendChild(elDigestMethod);
            element.appendChild(elDigestValue);
        } else {
            Logger.getLogger(this.getClass().getName()).warning("CertDigest was not set due to missing digest algorithm defined.");
        }

    }

    public Element getDOMElement() {
        return element;
    }
}
