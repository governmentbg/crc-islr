package com.tlogica.jsec.xml.test;

//import iaik.security.provider.IAIK;
//import iaik.xml.crypto.XSecProvider;
//import iaik.xml.crypto.utils.KeySelectorImpl;
//import iaik.xml.crypto.utils.URI;
//import iaik.xml.crypto.utils.URIException;
//import iaik.xml.crypto.xades.ArchiveTimeStamp;
//import iaik.xml.crypto.xades.QualifyingProperties;
//import iaik.xml.crypto.xades.SignatureTimeStamp;
//import iaik.xml.crypto.xades.UnsignedProperties;
//import iaik.xml.crypto.xades.UnsignedSignatureProperties;
//import iaik.xml.crypto.xades.XAdESSignature;
//import iaik.xml.crypto.xades.timestamp.TimeStampToken;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.Provider;
import java.security.Security;
import java.util.Iterator;
import java.util.List;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.crypto.MarshalException;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureException;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.parsers.DocumentBuilderFactory;

import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * This class uses IAIK library. The purpose of this class is to check the
 * compatibility between IAIK library and our JSecToolbox
 * @author Miroslav Dzhokanov
 */
public class XadesIAIKVerifier {

//    private Logger log = Logger.getLogger(this.getClass().getName());
//
//    public boolean verify(File xadesXMLFile) throws Exception {
//        try {
//            if (!xadesXMLFile.isFile()) {
//                throw new Exception("Cannot find input file '" + xadesXMLFile + "'");
//            }
//            // Create a schema validating parser
//            File schemaFile = new File("resources/schema/xmldsig-core-schema.xsd");
//            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//            dbf.setNamespaceAware(true);
//            dbf.setIgnoringElementContentWhitespace(true);
//            dbf.setExpandEntityReferences(false);
//            dbf.setValidating(true);
//            dbf.setAttribute("http://java.sun.com/xml/jaxp/properties/schemaLanguage", "http://www.w3.org/2001/XMLSchema");
//            dbf.setAttribute("http://java.sun.com/xml/jaxp/properties/schemaSource", schemaFile);
//            dbf.setAttribute("http://apache.org/xml/features/validation/schema/normalized-value", Boolean.FALSE);
//            // parse the signature document
//            Document doc = dbf.newDocumentBuilder().parse(new BufferedInputStream(new FileInputStream(xadesXMLFile)));
//            return verify(doc);
//        } catch (SAXException ex) {
//            throw new Exception(ex);
//        } catch (IOException ex) {
//            throw new Exception(ex);
//        } catch (ParserConfigurationException ex) {
//            throw new Exception(ex);
//        }
//    }
//
//    public boolean verify(Document xadesDoc) throws Exception{
//        log.info("Start verifying a signature by IAIK xades verifier");
//        try {
//            URI baseURI = BaseURI.file2AbsoluteURI(new File("."));
//            // Register IAIK Provider
//            IAIK.addAsJDK14Provider();
//            // Find Signature element
//            NodeList nl = xadesDoc.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature");
//            if (nl.getLength() == 0) {
//                try {
//                    throw new Exception("Cannot find Signature element");
//                } catch (Exception ex) {
//                    Logger.getLogger(Exception.class.getName()).log(Level.SEVERE, null, ex);
//                }
//            }
//            // Create a DOM XMLSignatureFactory that will be used to unmarshal the
//            // document containing the XMLSignature
//            Provider provider = new XSecProvider();
//            Security.addProvider(provider);
//            //move other XMLDsig provider to the end
//            Provider otherXMLDsigProvider = Security.getProvider("XMLDSig");
//            if (otherXMLDsigProvider != null) {
//                Security.removeProvider(otherXMLDsigProvider.getName());
//                Security.addProvider(otherXMLDsigProvider);
//            }
//            XMLSignatureFactory sfac = XMLSignatureFactory.getInstance("DOM", provider);
//            // Create a DOMValidateContext and specify a KeyValue KeySelector
//            // and document context
//            DOMValidateContext valContext = new DOMValidateContext(new KeySelectorImpl(), nl.item(0));
//            valContext.setProperty("javax.xml.crypto.dsig.cacheReference", Boolean.TRUE);
//            valContext.setBaseURI(baseURI.toString());
//            // unmarshal the XMLSignature
//            XMLSignature signature = sfac.unmarshalXMLSignature(valContext);
//            // Validate the XMLSignature
//            boolean coreValidity = signature.validate(valContext);
//            // Check core validation status
//            if (coreValidity == false) {
//                System.err.println("Signature failed core validation");
//                boolean sv = signature.getSignatureValue().validate(valContext);
//                System.out.println("signature validation status: " + sv);
//                // check the validation status of each Reference
//                Iterator i = signature.getSignedInfo().getReferences().iterator();
//                for (int j = 0; i.hasNext(); j++) {
//                    Reference ref = (Reference) i.next();
//                    boolean refValid = ref.validate(valContext);
//                    System.out.println("ref[" + j + "] validity status: " + refValid);
//                    if (!refValid) {
//                        System.out.println("digest input:");
//                        InputStream digestInput = ref.getDigestInputStream();
//                        byte[] buf = new byte[1024];
//                        int count;
//                        while ((count = digestInput.read(buf)) != -1) {
//                            System.out.write(buf, 0, count);
//                        }
//                        System.out.println("\n");
//                    }
//                }
//            } else {
//                System.out.println("Signature passed core validation");
//            }
//            // validate Signature- and ArchiveTimeStamps if present
//            QualifyingProperties qp = ((XAdESSignature) signature).getQualifyingProperties();
//            if (qp != null) {
//                UnsignedProperties up = qp.getUnsignedProperties();
//                if (up != null) {
//                    UnsignedSignatureProperties usp = up.getUnsignedSignatureProperties();
//                    if (usp != null) {
//                        List sigTSs = usp.getSignatureTimeStamps();
//                        {
//                            for (Iterator iter = sigTSs.iterator(); iter.hasNext();) {
//                                SignatureTimeStamp sigTS = (SignatureTimeStamp) iter.next();
//                               boolean tsValid = sigTS.validate(valContext);
////                                System.out.println("TS  --> " + sigTS);
////                                // validate time-stamp
////                                // iaik.xml.crypto.xades.impl.dom.properties.SignatureTimeStampImpl
////                                InputStream is = sigTS.getTimeStampInputStream();
////                                byte[] bytes = new byte[is.available()];
////                                is.read(bytes);
////                                ByteArray.printBytes(bytes);
////                                for(Object o : sigTS.getIncludes()){
////                                    System.out.println("Obj: " + o);
////                                }
////                                System.out.println(sigTS.getCanonicalizationMethod() + ", " +sigTS.getTimeStampToken());
//
//                                if (tsValid) {
//                                    TimeStampToken tsToken = sigTS.getTimeStampToken();
//                                    System.out.println("SignatureTimeStamp validation date = " + tsToken.getTime());
//                                } else {
//                                    System.out.println("SignatureTimeStamp is invalid!");
//                                    return false;
//                                }
//                            }
//                        }
//                        {
//                            List archTSs = usp.getArchiveTimeStamps();
//                            for (Iterator iter = archTSs.iterator(); iter.hasNext();) {
//                                ArchiveTimeStamp archTS = (ArchiveTimeStamp) iter.next();
//                                // validate time-stamp
//                                boolean tsValid = archTS.validate(valContext);
//                                if (tsValid) {
//                                    TimeStampToken tsToken = archTS.getTimeStampToken();
//                                    System.out.println("ArchiveTimeStamp validation date = " + tsToken.getTime());
//                                } else {
//                                    System.out.println("ArchiveTimeStamp is invalid!");
//                                    return false;
//                                }
//                            }
//                        }
//                    }
//                }
//            }
//        } catch (IOException ex) {
//            throw new Exception(ex);
//        } catch (XMLSignatureException ex) {
//            throw new Exception(ex);
//        } catch (MarshalException ex) {
//            throw new Exception(ex);
//        } catch (URIException ex) {
//            throw new Exception(ex);
//        }
//        return true;
//    }
//
//    public static void main(String args[]) throws Exception{
//        XadesIAIKVerifier ver = new XadesIAIKVerifier();
//        File file = new File("C:/Documents and Settings/mdzhokanov/Desktop/iaik_Enveloping.xml");
//        ver.verify(file);
//    }
}
