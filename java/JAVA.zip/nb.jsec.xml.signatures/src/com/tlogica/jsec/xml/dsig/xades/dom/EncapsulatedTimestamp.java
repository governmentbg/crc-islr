package com.tlogica.jsec.xml.dsig.xades.dom;

import com.sun.org.apache.xml.internal.security.c14n.CanonicalizationException;
import com.sun.org.apache.xml.internal.security.c14n.Canonicalizer;
import com.sun.org.apache.xml.internal.security.c14n.InvalidCanonicalizerException;
import com.tlogica.jsec.timestamp.TimeStampFactory;
import com.tlogica.jsec.timestamp.Timestamp;
import com.tlogica.jsec.timestamp.except.TimestampException;
import com.tlogica.jsec.xml.DOMUtil;
import com.tlogica.jsec.xml.dsig.XMLDigSignature;
import com.tlogica.jsec.xml.dsig.XMLSigner;
import com.tlogica.jsec.xml.except.XMLSigningException;
import java.security.SignatureException;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.crypto.dsig.XMLSignature;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class EncapsulatedTimestamp {

    public static final String ID_KEY = "ETS";
    private static final String ELEMENT_LOCAL_NAME = "EncapsulatedTimeStamp";
    private Element element;

    public EncapsulatedTimestamp(Document doc, String prefix, Map<String, String> idMap) throws XMLSigningException {
        element = doc.createElementNS(XadesSignature.XMLNS_1_3_2, ELEMENT_LOCAL_NAME);
        element.setPrefix(prefix);
        // append child nodes
        DOMUtil.setNoNSId(element, idMap, ID_KEY);
        String timestamp = requestTimestamp(doc);
        element.appendChild(doc.createTextNode(timestamp));
    }

    /**
     * Current method returns timestamp for the passed document.
     * For this purpose, the method firstly looks for SignatureValue fields in the
     * DOM tree and send their canonicalized content for being timestamped from
     * TimeStamp Authority.
     * @param doc
     * @return
     * @throws XMLSigningException if there are no SignatureValue nodes or they
     *         cannot be canonicalized
     */
    private String requestTimestamp(Document doc) throws XMLSigningException {
        NodeList sigValues = doc.getElementsByTagNameNS(XMLSignature.XMLNS, "SignatureValue");
        if (sigValues == null || sigValues.getLength() < 1) {
            throw new XMLSigningException("<SignatureValue> xml nodes was not found");
        }
        Node elSigValue = sigValues.item(0);
        byte[] signatureValue = null;
        try {
            // TODO get the relevant canonicalizer algorithm from System.properties
            Canonicalizer c14n = Canonicalizer.getInstance(XMLDigSignature.XMLNS_C14N);
            signatureValue = c14n.canonicalizeSubtree(elSigValue);
        } catch (InvalidCanonicalizerException ex) {
            throw new XMLSigningException(ex);
        } catch (CanonicalizationException ex) {
            throw new XMLSigningException(ex);
        }
        String encodedTimestamp = null;
        try {
            Timestamp timestamp = TimeStampFactory.getTimeStamp(signatureValue);
            encodedTimestamp = new String(timestamp.getBytesEncoded());
        } catch (TimestampException ex) {
            Logger.getLogger(XMLSigner.class.getName()).log(Level.SEVERE, null, ex);
        }

        return encodedTimestamp;
    }

    public Element getDOMElement() {
        return element;
    }
}
