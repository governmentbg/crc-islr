package com.tlogica.jsec.xml.dsig.xades.dom;

import com.tlogica.jsec.xml.DOMUtil;
import com.tlogica.jsec.xml.dsig.dom.CanonicalizationMethod;
import com.tlogica.jsec.xml.except.XMLSigningException;
import java.util.Map;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class SignatureTimestamp {

    public static final String ID_KEY = "STS";
    private static final String ELEMENT_LOCAL_NAME = "SignatureTimeStamp";
    private Element element;
    private EncapsulatedTimestamp encapsulatedTimestamp;
    private CanonicalizationMethod canonicalizationMethod;

    public SignatureTimestamp(Document doc, String prefix, Map<String, String> idMap) throws XMLSigningException {
        // TODO 'ds' prefix to be configurable and passed as argument
        canonicalizationMethod = new CanonicalizationMethod(doc, "ds", idMap);
        encapsulatedTimestamp = new EncapsulatedTimestamp(doc, prefix, idMap);

        element = doc.createElementNS(XadesSignature.XMLNS_1_3_2, ELEMENT_LOCAL_NAME);
        element.setPrefix(prefix);
        // append child nodes
        element.appendChild(canonicalizationMethod.getDOMElement());
        element.appendChild(encapsulatedTimestamp.getDOMElement());
        DOMUtil.setNoNSId(element, idMap, ID_KEY);
    }

    public Element getDOMElement() {
        return element;
    }

    public EncapsulatedTimestamp getEncapsulatedTimestamp() {
        return encapsulatedTimestamp;
    }

    public CanonicalizationMethod getCanonicalizationMethod() {
        return canonicalizationMethod;
    }
}
