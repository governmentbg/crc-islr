package com.tlogica.jsec.xml.dsig.xades.dom;

import com.tlogica.jsec.xml.DOMUtil;
import com.tlogica.jsec.xml.dsig.XMLDigSignature;
import com.tlogica.jsec.xml.dsig.XMLSigner;
import java.util.Map;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class Cert {

    public static final String ID_KEY = "CERT";
    public static final String ELEMENT_LOCAL_NAME = "Cert";
    public static final String CERT_ISSUER_NAME = "X509IssuerName";
    public static final String CERT_ISSUER_SERIAL = "X509SerialNumber";
    private Element element;

    public Cert(Document doc, String prefix, Map<String, String> idMap) {
        CertDigest certDigest = new CertDigest(doc, prefix, idMap);
        // Set current time
        element = doc.createElementNS(XadesSignature.XMLNS_1_3_2, ELEMENT_LOCAL_NAME);
        //element.appendChild();
        element.setPrefix(prefix);
        DOMUtil.setNoNSId(element, idMap, ID_KEY);
        element.appendChild(certDigest.getDOMElement());

        Element elIssuerSerial = doc.createElementNS(XadesSignature.XMLNS_1_3_2, "IssuerSerial");
        elIssuerSerial.setPrefix(idMap.get(XMLSigner.XADES_DSIG_PREFIX));
        Element elIssuerName = doc.createElementNS(XMLDigSignature.XMLNS, "X509IssuerName");
        elIssuerName.setPrefix(idMap.get(XMLSigner.XML_DSIG_PREFIX));
        elIssuerName.setTextContent(idMap.get(CERT_ISSUER_NAME));
        Element elIssuerSerialNumber = doc.createElementNS(XMLDigSignature.XMLNS, "X509SerialNumber");
        elIssuerSerialNumber.setPrefix(idMap.get(XMLSigner.XML_DSIG_PREFIX));
        elIssuerSerialNumber.setTextContent(idMap.get(CERT_ISSUER_SERIAL));

        elIssuerSerial.appendChild(elIssuerName);
        elIssuerSerial.appendChild(elIssuerSerialNumber);

        element.appendChild(elIssuerSerial);
    }

    public Element getDOMElement() {
        return element;
    }
}
