package com.tlogica.jsec.xml;

import java.io.File;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class XMLDocumentComparator {

    private static final Logger log = Logger.getLogger("XMLDocumentComparator");

    /**
     * This method checks whether two xml documents has same contents.
     * XML documents has same contents when one of next requiremnts is met:
     * - the documents are absolutely identical
     * - one of the documents is the signed version of other
     *
     * @param doc1
     * @param doc2
     * @return true if the documents are identical
     */
    public static boolean checkContents(XMLDocument doc1, XMLDocument doc2) {
        log.info("Start checking contents between two documents.");
        if (doc1 == null || doc2 == null) {
            return false;
        }

        if (doc1.equals(doc2)) {
            return true;
        }

        List<Node> nodes1 = getContentNodes(doc1);
        List<Node> nodes2 = getContentNodes(doc2);
        if (nodes1.size() != nodes2.size()) {
            return false;
        } else {
            // Content lists have equal sizes
            for (int i = 0; i < nodes1.size(); i++) {
                // Convert node1 to text
                Node node1 = nodes1.get(i);
                XMLUtils.normalizeXML(node1);
                String node1Text = null;
                node1Text = XMLUtils.convertXMLNodeToString(node1, doc1.getEncoding());
                if (node1Text.startsWith("<?")) {
                    node1Text = node1Text.substring(node1Text.indexOf("?>") + 2);
                }

                // Convert node2 to text
                Node node2 = nodes2.get(i);
                XMLUtils.normalizeXML(node2);
                String node2Text = null;
                node2Text = XMLUtils.convertXMLNodeToString(node2, doc2.getEncoding());
                if (node2Text.startsWith("<?")) {
                    node2Text = node2Text.substring(node2Text.indexOf("?>") + 2);
                }

                // Compare strings
                //System.out.println("Compare " + node1 + " with " + node2);
                if (node1Text != null && node2Text != null) {
                    // Same documents
                    if (node1Text.equals(node2Text)) {
                        return true;
                    } // Not same documents
                    else {
                        int min = node1Text.length() < node2Text.length() ? node1Text.length() : node2Text.length();
                        int counter = 0;
                        for (; counter < min; counter++) {
                            if (node1Text.charAt(counter) != node2Text.charAt(counter)) {
                                break;
                            }
                        }
                        log.log(Level.INFO, "THE TEXTS ARE DIFFERENT AT POSITION #{0}", counter);
                        if (counter > 2) {
                            log.log(Level.INFO, "Doc1 (five chars, the third one is different) -> {0}, {1}, {2}, {3}, {4}",
                                    new Object[]{node1Text.charAt(counter - 2), node1Text.charAt(counter - 1),
                                    node1Text.charAt(counter), node1Text.charAt(counter + 1), node1Text.charAt(counter + 2)});
                            log.log(Level.INFO, "Doc2 (five chars, the third one is different) -> {0}, {1}, {2}, {3}, {4}",
                                    new Object[]{node2Text.charAt(counter - 2), node2Text.charAt(counter - 1),
                                    node2Text.charAt(counter), node2Text.charAt(counter + 1), node2Text.charAt(counter + 2)});
                        } else {
                            log.log(Level.INFO, "Doc1 (five chars, the third one is different) -> {0}, {1}, {2}",
                                    new Object[]{node1Text.charAt(counter), node1Text.charAt(counter + 1), node1Text.charAt(counter + 2)});
                            log.log(Level.INFO, "Doc2 (five chars, the third one is different) -> {0}, {1}, {2}",
                                    new Object[]{node2Text.charAt(counter), node2Text.charAt(counter + 1), node2Text.charAt(counter + 2)});
                        }
                        if(counter > 10){
                            log.log(Level.INFO, "Doc1 piece of String: {0}", node1Text.substring(counter - 10, counter + 10));
                            log.log(Level.INFO, "Doc2 piece of String: {0}", node2Text.substring(counter - 10, counter + 10));
                        }
                        else{
                            log.log(Level.INFO, "Doc1 piece of String: {0}", node1Text.substring(counter, counter + 10));
                            log.log(Level.INFO, "Doc2 piece of String: {0}", node2Text.substring(counter, counter + 10));
                        }
                    }
                } else {
                    log.info("One of the XML documents is empty.");
                }
            }

        }

        return false;
    }

    private static List<Node> getContentNodes(XMLDocument doc) {
        List<Node> content = doc.getDocumentContentNodes();
        // Check for signed document
        if (doc.isSigned()) {
            // Create new list by removing <ds:OBJECT> elements and saving their
            // content elements
            List<Node> newList = new LinkedList<Node>();
            for (Node n : content) {
                if ("Object".equals(n.getLocalName())) {
                    NodeList objectChildren = n.getChildNodes();
                    for (int i = 0; i < objectChildren.getLength(); i++) {
                        newList.add(objectChildren.item(i));
                    }
                } else {
                    newList.add(n);
                }
            }
            content = newList;
        }
        return content;
    }

    public static void main(String... args) throws Exception {
        XMLDocument docToSign = XMLDocumentReader.read(new File("test/xml/fileToSignNonASCII.xml"));
        XMLDocument signedDoc = XMLDocumentReader.read(new File("test/xml/signedDoc_Mine_NonASCII_X509Data.xml"));
        System.out.println("Compare doc and SignedDoc -> " + checkContents(docToSign, signedDoc));
        System.out.println("Compare SignedDoc and doc -> " + checkContents(signedDoc, docToSign));
        System.out.println("Compare SignedDoc and SignedDoc -> " + checkContents(signedDoc, signedDoc));
        System.out.println("Compare doc and doc -> " + checkContents(docToSign, docToSign));
    }
}
