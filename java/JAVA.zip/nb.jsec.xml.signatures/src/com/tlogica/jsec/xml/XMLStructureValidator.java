package com.tlogica.jsec.xml;

import com.sun.org.apache.xerces.internal.util.XMLCatalogResolver;
import com.tlogica.jsec.os.ResourceLocator;
import com.tlogica.jsec.xml.except.XMLDocumentException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URI;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.ls.LSInput;
import org.w3c.dom.ls.LSResourceResolver;

/**
 *
 * @author Miroslav Dzhokanov
 */
class MyLSInput implements LSInput {

    protected String fPublicId;
    protected String fSystemId;
    protected String fBaseSystemId;
    protected InputStream fByteStream;
    protected Reader fCharStream;
    protected String fData;
    protected String fEncoding;
    protected boolean fCertifiedText;

    public MyLSInput() {
    }

    public MyLSInput(String publicId, String systemId, InputStream byteStream) {
        fPublicId = publicId;
        fSystemId = systemId;
        fByteStream = byteStream;
    }

    public InputStream getByteStream() {
        return fByteStream;
    }

    public void setByteStream(InputStream byteStream) {
        fByteStream = byteStream;
    }

    public Reader getCharacterStream() {
        return fCharStream;
    }

    public void setCharacterStream(Reader characterStream) {
        fCharStream = characterStream;
    }

    public String getStringData() {
        return fData;
    }

    public void setStringData(String stringData) {
        fData = stringData;
    }

    public String getEncoding() {
        return fEncoding;
    }

    public void setEncoding(String encoding) {
        fEncoding = encoding;
    }

    public String getPublicId() {
        return fPublicId;
    }

    public void setPublicId(String publicId) {
        fPublicId = publicId;
    }

    public String getSystemId() {
        return fSystemId;
    }

    public void setSystemId(String systemId) {
        fSystemId = systemId;
    }

    public String getBaseURI() {
        return fBaseSystemId;
    }

    public void setBaseURI(String baseURI) {
        fBaseSystemId = baseURI;
    }

    public boolean getCertifiedText() {
        return fCertifiedText;
    }

    public void setCertifiedText(boolean certifiedText) {
        fCertifiedText = certifiedText;
    }
}

class MyLSResourceResolver implements LSResourceResolver {

    public LSInput resolveResource(String type, String namespaceURI, String publicId, String systemId, String baseURI) {

        System.out.println("----------------\ntype=" + type +
                "\nnamespaceURI=" + namespaceURI +
                "\npublicId=" + publicId +
                "\nsystemId=" + systemId +
                "\nbaseURI=" + baseURI);
        if ("http://www.w3.org/2001/XMLSchema.dtd".equals(baseURI)) {
            return null;
        }

        LSInput lsin = new MyLSInput();
        lsin.setBaseURI(baseURI);
        lsin.setPublicId(publicId);
        lsin.setSystemId(systemId);
        if (systemId != null && systemId.matches("[.]/.*")) {
            try {
                lsin.setByteStream(ResourceLocator.loadDataFromResource("resources/xsd/" + systemId.replaceAll("[.]/", "")));
            } catch (IOException ex) {
            }
        }
        return lsin;
    }
}

public class XMLStructureValidator {

    // getting schema by ns
    private static final HashMap<String, Schema> schemaByNs =
            new HashMap<String, Schema>();

    // load of all needed xsds ...
    static void loadXsd() throws Exception {
        SchemaFactory schemaFactory =
                SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        schemaFactory.setResourceResolver(new MyLSResourceResolver());
//        schemaByNs.put("http://www.w3.org/2000/09/xmldsig#",//
//                schemaFactory.newSchema(new StreamSource(//
//                ResourceLocator.loadDataFromResource("resources/xsd/xmldsig-core-schema.xsd"))));
//        System.out.println("http://www.w3.org/2000/09/xmldsig#");
//        schemaByNs.put("http://www.w3.org/2001/10/xml-exc-c14n#",//
//                schemaFactory.newSchema(new StreamSource(//
//                ResourceLocator.loadDataFromResource("resources/xsd/xml-exc-c14.xsd"))));
//        System.out.println("http://www.w3.org/2001/10/xml-exc-c14n#");
        schemaByNs.put("http://uri.etsi.org/01903/v1.1.1#",//
                schemaFactory.newSchema(new StreamSource(//
                ResourceLocator.loadDataFromResource("resources/xsd/xades1.1.1.xsd"))));
        System.out.println("http://uri.etsi.org/01903/v1.1.1#");
//        schemaByNs.put("http://uri.etsi.org/01903/v1.3.2#",//
//                schemaFactory.newSchema(new StreamSource(//
//                ResourceLocator.loadDataFromResource("resources/xsd/xades1.3.2.xsd"))));
//        System.out.println("http://uri.etsi.org/01903/v1.3.2#");
//        schemaByNs.put("http://uri.etsi.org/01903/v1.4.1#",//
//                schemaFactory.newSchema(new StreamSource(//
//                ResourceLocator.loadDataFromResource("resources/xsd/xades1.4.1.xsd"))));
//        System.out.println("http://uri.etsi.org/01903/v1.4.1#");
    }

    /**
     * This method also registers all elements' ID attributes, specified in the
     * relevant XSD.
     * @param signatureNode
     * @param xsdNamespace xades or xmldsig namespace
     * @throws XMLDocumentException
     */
    public static void validateXMLDSig(Node signatureNode, String xsdNamespace) throws XMLDocumentException {
        Document signatureDoc = DOMUtil.convertNodeToDocument(signatureNode);
        validateXMLDSig(signatureDoc, xsdNamespace);
    }

    /**
     * This method also registers all elements' ID attributes, specified in the
     * relevant XSD.
     * @param doc
     * @param xsdNamespace xades or xmldsig namespace
     * @throws XMLDocumentException 
     */
    public static void validateXMLDSig(Document doc, String xsdNamespace)
            throws XMLDocumentException //
    {
        System.out.println("xsdNamespace=" + xsdNamespace);
    }

    /**
     * This method also registers all elements' ID attributes, specified in the
     * relevant XSD.
     * @param doc
     * @param schemaLocation
     * @throws XMLDocumentException 
     */
    public static void validateXMLStructure(Document doc, String schemaLocation) throws XMLDocumentException {

        System.out.println("schemaLocation=" + schemaLocation);
    }

    public static void main(String[] a) throws Exception {
        loadXsd();
    }
}
