package com.tlogica.jsec.xml.dsig.xades.dom;

import com.tlogica.jsec.xml.DOMUtil;
import com.tlogica.jsec.xml.except.XMLSigningException;
import java.util.Map;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class UnsignedProperties {
    public final static String REFERENCE_TYPE = "http://uri.etsi.org/01903#UnsignedProperties";
    public static final String ID_KEY = "UP";
    private static final String ELEMENT_LOCAL_NAME = "UnsignedProperties";
    private Element element;
    private UnsignedSignatureProperties unsignedSignatureProperties;

    public UnsignedProperties(Document doc, String prefix, Map<String, String> idMap) throws XMLSigningException{
        unsignedSignatureProperties = new UnsignedSignatureProperties(doc, prefix, idMap);
        element = doc.createElementNS(XadesSignature.XMLNS_1_3_2, ELEMENT_LOCAL_NAME);
        element.setPrefix(prefix);
        // append child nodes
        element.appendChild(unsignedSignatureProperties.getDOMElement());
        DOMUtil.setNoNSId(element, idMap, ID_KEY);
    }

    public Element getDOMElement() {
        return element;
    }

    public UnsignedSignatureProperties getUnsignedSignatureProperties() {
        return unsignedSignatureProperties;
    }
}
