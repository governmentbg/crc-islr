package com.tlogica.jsec.xml;

import com.tlogica.jsec.xml.dsig.XMLDigSignature;
import com.tlogica.jsec.xml.except.XMLDocumentException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class DOMUtil {

    private static final Logger log = Logger.getLogger("com.tlogica.jsec.xml.DOMUtil");
    
    public static void setNoNSId(Element elem, Map<String, String> idMap, String idKey) {
        String id = idMap.get(idKey);
        setNoNSId(elem, id);
    }

    public static void setNoNSId(Element elem, String id) {
        if (id != null && !"".equals(id)) {
            log.log(Level.FINER, "Set ID ''{0}'' for {1} element", new Object[]{id, elem.getLocalName()});
            elem.setAttributeNS(null, "Id", id);
            elem.setIdAttribute("Id", true);
        }
    }

    /**
     * Returns null if there is no Id attribute
     * @param node
     */
    public static String getNodeId(Node node) {
        NamedNodeMap attrs = node.getAttributes();
        if (attrs != null) {
            Node idAttr = attrs.getNamedItem("Id");
            if (idAttr != null) {
                return idAttr.getNodeValue();
            }
        }
        return null;
    }

    /**
     * Looks for http://www.w3.org/2000/09/xmldsig#Signature xml elements in the passed
     * document and returns them as List<Node>
     * @param doc
     * @return
     */
    public static List<Node> getSignatureNodes(Document doc) {
        List<Node> sigNodes = new LinkedList<Node>();
        // sanity check
        if(doc == null){
            return sigNodes;
        }
        NodeList nodes = doc.getElementsByTagNameNS(XMLDigSignature.XMLNS, "Signature");
        int length = nodes.getLength();
        for (int i = 0; i < length; i++) {
            Node signatureNode = nodes.item(i);
            sigNodes.add(signatureNode);
        }
        return sigNodes;
    }

    /**
     * Converts the passed DOM Node into a XML Document where the passed node
     * is the root of the newly created document.
     * @param node
     * @return
     * @throws XMLDocumentException
     */
    public static Document convertNodeToDocument(Node node){
        // Instantiate the document to be signed.
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        Document doc = null;
        try {
            // Create new Document object
            doc = dbf.newDocumentBuilder().newDocument();
            // Extract node from its default Document owner
            Node importedNode = doc.importNode(node, true);
            doc.appendChild(importedNode);
        } catch (ParserConfigurationException ex) {
            throw new XMLDocumentException(ex);
        }
        return doc;
    }
}
