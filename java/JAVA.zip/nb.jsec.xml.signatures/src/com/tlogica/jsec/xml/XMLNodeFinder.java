package com.tlogica.jsec.xml;

import com.tlogica.jsec.xml.except.XMLDocumentException;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.crypto.dsig.XMLSignature;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class XMLNodeFinder {

    private static final Logger log = Logger.getLogger("XMLDocumentReader");

    /**
     * Private method looking for all signed nodes in the passed xml file, except for
     * "SignedProperties". This node is not skipped from the current method.
     * This method loops through all references and finds their targets.
     * @param doc xml file root node
     * @return list of the nodes which have been signed
     */
    public static List<Node> findSignedContentNodeList(Document doc){

        // Find Signed Content References
        List<String> signedNodesURIs = new LinkedList<String>();
        NodeList references = doc.getElementsByTagNameNS(XMLSignature.XMLNS, "Reference");

        if (references.getLength() > 0) {
            for (int i = 0; i < references.getLength(); i++) {
                NamedNodeMap attrsMap = references.item(i).getAttributes();
                if (attrsMap != null) {
                    Node uriAttr = attrsMap.getNamedItem("URI");
                    if (uriAttr != null) {
                        if (!uriAttr.getNodeValue().equals("")) {
                            String searchedId = uriAttr.getNodeValue().substring(1);
                            Node referencedNode = findNodeById(doc, searchedId);//doc.getElementById(uriAttr.getNodeValue().substring(1));
                            // Skipping "SignedProperties" reference
                            if (referencedNode != null && !"SignedProperties".equals(referencedNode.getLocalName())) {
                                // Reference was found !!
                                signedNodesURIs.add(uriAttr.getNodeValue());
                                System.out.println("Reference [" + searchedId + "] was found -> " + referencedNode);
                            }
                        } else {
                            // Enveloped signature
                            signedNodesURIs.add(uriAttr.getNodeValue());
                        }
                    }
                }
            }
        } else {
            throw new XMLDocumentException("No <" + XMLSignature.XMLNS + ":Reference> elements were found in the signed document.");
        }

        // Determine each reference's target node
        List<Node> signedContentNodes = new LinkedList<Node>();

        // ENVELOPED SIGNATURE
        if (signedNodesURIs.size() == 1 && signedNodesURIs.get(0).equals("")) {
            // Remove Signature node
            // TODO - do it without cloning the whole Document tree
            Node docCopy = doc.cloneNode(true);
            NodeList signatureNodes = ((Document) docCopy).getElementsByTagNameNS(XMLSignature.XMLNS, "Signature");
            Node signatureNode = signatureNodes.item(0);
            Node sigParent = signatureNode.getParentNode();
            sigParent.removeChild(signatureNode);
            signedContentNodes.add(docCopy);

        } // ENVELOPING OR DETACHED SIGNATURE
        else if (!signedNodesURIs.isEmpty()) {
            for (String contentId : signedNodesURIs) {
                // trim URIs - remove the target character
                if (contentId.startsWith("#")) {
                    contentId = contentId.substring(1);
                }
                if (contentId == null || contentId.equals("")) {
                    // TODO sign the whole document
                }
                // Find the signed node
                Node signedContentNode = findNodeById(doc, contentId);
                if (signedContentNode == null) {
                    // TODO check whether "contentId" is not an URI to local resource
                    log.warning("signedContentNode is null ");
                }

                if (signedContentNode != null) {
                    // Does not add SignatureValue element, because it was signed with a counter signature
                    if (!signedContentNode.getLocalName().equals("SignatureValue")) {
                        signedContentNodes.add(signedContentNode);
                    } else {
                        log.log(Level.WARNING, "signedContentNode unrecognized - {0}", signedContentNode);
                    }
                } else {
                    throw new XMLDocumentException("Signed node (Id=" + contentId + ") could not be found.");
                }
            }
        } else {
            throw new XMLDocumentException("Signed node references were not found.");
        }

        return signedContentNodes;
    }

    /**
     * Returns null if no node with the passed id was found.
     * @param root
     * @param id
     * @return
     */
    public static Node findNodeById(Document root, String id) {
        if (id == null) {
            return null;
        }
        log.log(Level.FINE, "FindNodeById - {0}", id);
        Node searchedNode = root.getElementById(id);
        if (searchedNode == null) {
            // Searched node is hold in xml node, which doesn't have registered ID attribute
            searchedNode = findNodeByIdRecursive(root, id);
        }
        return searchedNode;
    }

    /**
     * Returns null if no node with the passed id was found.
     * @param root
     * @param id
     * @return
     */
    private static Node findNodeByIdRecursive(Node root, String id) {
        Node searchedNode = null;
        NodeList children = root.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            NamedNodeMap attrs = child.getAttributes();
            if (attrs != null) {
                Node uriAttr = attrs.getNamedItem("Id");
                if (uriAttr != null) {
                    if (uriAttr.getNodeValue().equals(id)) {
                        searchedNode = child;
                        break;
                    }
                }
            }

            searchedNode = findNodeByIdRecursive(child, id);
            if (searchedNode != null) {
                break;
            }
        }
        return searchedNode;
    }

    /**
     * Returns null if no node with the passed tagName was found.
     * @param root
     * @param tagName
     * @return
     */
    public static List<Node> findNodesByName(Document root, String tagName) {
        if (tagName == null) {
            return null;
        }
        log.log(Level.FINE, "findNodeByName - {0}", tagName);
        NodeList searchedNodes = root.getElementsByTagName(tagName);
        List<Node> nodesList = new LinkedList<Node>();
        for(int i=0; i< searchedNodes.getLength(); i++){
            nodesList.add(searchedNodes.item(i));
        }

        if (nodesList.isEmpty()) {
            // Searched node is hold in xml node, which doesn't have registered ID attribute
            nodesList = findNodeByNameRecursive(root, tagName);
        }
        
        return nodesList;
    }

    /**
     * Returns null if no node with the passed tagName was found.
     * @param root
     * @param tagName
     * @return
     */
    private static List<Node> findNodeByNameRecursive(Node root, String tagName) {
        List<Node> foundNodes = new LinkedList<Node>();
        NodeList children = root.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            String childTagName = child.getLocalName();
            if(childTagName != null && childTagName.equals(tagName)){
                foundNodes.add(child);
            }
            // go deeper
            foundNodes.addAll(findNodeByNameRecursive(child, tagName));
        }
        return foundNodes;
    }
}
