package com.tlogica.jsec.xml.dsig.xades.dom;

import com.tlogica.jsec.xml.DOMUtil;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Map;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class SigningTime {

    public static final String ID_KEY = "ST";
    private static final String ELEMENT_LOCAL_NAME = "SigningTime";
    private Element element;

    public SigningTime(Document doc, String prefix, Map<String, String> idMap) {
        // Set current time
        element = doc.createElementNS(XadesSignature.XMLNS_1_3_2, ELEMENT_LOCAL_NAME);
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
        StringBuilder sb = new StringBuilder(sdf.format(calendar.getTime()));
        element.appendChild(doc.createTextNode(sb.toString()));
        element.setPrefix(prefix);
        DOMUtil.setNoNSId(element, idMap, ID_KEY);
    }

    public Element getDOMElement() {
        return element;
    }
}
