package com.tlogica.jsec.xml;

import com.tlogica.jsec.xml.dsig.XMLDigSignature;
import com.tlogica.jsec.xml.dsig.xades.dom.XadesSignature;
import com.tlogica.jsec.xml.except.XMLDocumentException;
import java.io.File;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class XMLDocumentReader {

    private static final Logger log = Logger.getLogger("XMLDocumentReader");

    /**
     * Constructs XMLDocument object from xml file, represented as String
     *
     * @param xmlString
     * @return
     * @throws XMLDocConstructingException
     */
    public static XMLDocument read(String xmlString) {
	log.log(Level.FINE, "Start reading an xml document from string.");

	if (xmlString == null) {
	    throw new NullPointerException("XML source string was not specified.");
	}
	DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	factory.setNamespaceAware(true);
	Document doc = XMLUtils.parseString(xmlString);
	return read(doc);
    }

    /**
     * Constructs XMLDocument object from xml file
     *
     * @param xmlFile
     * @return
     * @throws XMLDocConstructingException
     */
    public static XMLDocument read(File xmlFile) {
	log.log(Level.FINER, "Start reading an xml file - {0}.", xmlFile.getAbsolutePath());
	if (xmlFile == null) {
	    throw new NullPointerException("XML file was not specified.");
	}
	DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	factory.setNamespaceAware(true);
	Document doc = null;
	try {
	    doc = factory.newDocumentBuilder().parse(xmlFile);
	} catch (Exception ex) {
	    throw new XMLDocumentException(ex);
	}
	log.finer("XML document was successfully read.");
	return read(doc);
    }

    /**
     * Constructs XMLDocument object from DOM document
     *
     * @param doc
     * @return
     * @throws XMLDocConstructingException
     */
    public static XMLDocument read(Document doc) {
	log.finer("Start parsing an xml document.");
	XMLUtils.normalizeXML(doc);
	XMLDocument xmlDoc = new XMLDocument();
	xmlDoc.setRootDocument(doc);
	if (doc.getXmlEncoding() != null) {
	    xmlDoc.setEncoding(doc.getXmlEncoding());
	}

	// Find Signature element.
	NodeList nl = doc.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature");
	//SIGNED document
	if (nl.getLength() > 0) {
	    log.fine("Parse a SIGNED document.");
	    xmlDoc = parseSignedDocument(doc);
	    xmlDoc.setIsSigned(true);
	} // UNSIGNED Document
	else {
	    log.fine("Parse an UNSIGNED document.");
	    List<Node> signableNodes = new LinkedList<Node>();
	    NodeList children = doc.getChildNodes();
	    for (int i = 0; i < children.getLength(); i++) {
		signableNodes.add(children.item(i));
	    }
	    xmlDoc.setDocumentContentNodes(signableNodes);
	}
	return xmlDoc;
    }

    /**
     * This method parses any signed XML document and deserialize it in XMLDocument object.
     *
     * @param doc xml DOM node which holds the root of the xml file
     * @return deserialized XMLDocument object
     */
    private static XMLDocument parseSignedDocument(Document doc) {
	// Lookup for Xades object
	NodeList qualPropsNodes = doc.getElementsByTagName("QualifyingProperties");
	NodeList qualPropsNodesNS1 = doc.getElementsByTagNameNS(XadesSignature.XMLNS_1_1_1, "QualifyingProperties");
	NodeList qualPropsNodesNS2 = doc.getElementsByTagNameNS(XadesSignature.XMLNS_1_2_2, "QualifyingProperties");
	NodeList qualPropsNodesNS3 = doc.getElementsByTagNameNS(XadesSignature.XMLNS_1_3_2, "QualifyingProperties");

	List<Node> qualProps = mergeLists(Arrays.asList(qualPropsNodes, qualPropsNodesNS1, qualPropsNodesNS2, qualPropsNodesNS3));

	List<XMLDigSignature> xmlSignatures = new LinkedList<XMLDigSignature>();
	// XAdES Signature
	if (qualProps.size() > 0) {
	    //Determine XAdES version
	    log.finer("Signature is in XAdES format.");
	    String xadesNamespace = qualProps.get(0).getNamespaceURI();
	    List<Node> sigNodes = DOMUtil.getSignatureNodes(doc);
	    for (Node signature : sigNodes) {
		// Validate signed XML files on reading them
		Boolean doValidate = Boolean.parseBoolean(System.getProperty(Constants.VALIDATE_XML_ON_READING));
		//System.out.println("---------- doValidate on reading: " + doValidate);
		try {
		    if (doValidate) {
			Document signatureDoc = DOMUtil.convertNodeToDocument(signature);
			XMLStructureValidator.validateXMLDSig(signatureDoc, xadesNamespace);
		    }
		} catch (XMLDocumentException e) {
		    log.log(Level.WARNING, "Not valid signature. Skip this signature.", e);
		    // skip this signature
		    continue;
		}
		XMLDigSignature xmldsig = null;

		if (isXadesSignature(signature)) {
		    xmldsig = new XadesSignature(signature, xadesNamespace);
		} else {
		    // one of the signatures in the xml is not xades
		    xmldsig = new XMLDigSignature(signature);
		}

		xmlSignatures.add(xmldsig);
	    }
	} // XML Digital Signature
	else {
	    log.finer("Signature is in standart XML Digital Signature format.");
	    List<Node> sigNodes = DOMUtil.getSignatureNodes(doc);
	    for (Node signature : sigNodes) {

		try {
		    // validate signature element
		    Boolean doValidate = Boolean.parseBoolean(System.getProperty(Constants.VALIDATE_XML_ON_READING));
		    //System.out.println("---------- doValidate on reading: " + doValidate);
		    if (doValidate) {
			Document signatureDoc = DOMUtil.convertNodeToDocument(signature);
			XMLStructureValidator.validateXMLDSig(signatureDoc, XMLSignature.XMLNS);
		    }
		} catch (XMLDocumentException e) {
		    log.log(Level.WARNING, "Not valid signature. Skip this signature.", e);
		    // skip this signature
		    continue;
		}

		xmlSignatures.add(new XMLDigSignature(signature));
	    }
	}

	log.log(Level.FINE, "{0} signatures found.", xmlSignatures.size());
	XMLDocument xmlDoc = new XMLDocument();
	xmlDoc.setRootDocument(doc);
	xmlDoc.addSignatures(xmlSignatures);
	// Find signed nodes
	List<Node> signedNodes = XMLNodeFinder.findSignedContentNodeList(doc);
	xmlDoc.setDocumentContentNodes(signedNodes);

	return xmlDoc;
    }

    private static boolean isXadesSignature(Node signatureNode) {
	List<Node> references = getReferencesFromSignatureNode(signatureNode);
	boolean isXades = false;
	for (Node ref : references) {
	    NamedNodeMap attrMap = ref.getAttributes();
	    if (attrMap != null && attrMap.getLength() > 0) {
		Node attr = attrMap.getNamedItem("URI");
		if (attr != null) {
		    String uri = attr.getTextContent();
		    if (uri != null && !uri.equals("")) {
			uri = uri.substring(1); // removes # symbol
			if (uri.equals("SignedProperties")) {
			    isXades = true;
			}
		    }
		}
	    }
	}

	return isXades;
    }

    private static List<Node> getReferencesFromSignatureNode(Node signatureNode) {
	List<Node> refs = new LinkedList<Node>();
	NodeList sigChildren = signatureNode.getChildNodes();
	if (sigChildren.getLength() != 0) {
	    for (int i = 0; i < sigChildren.getLength(); i++) {
		Node n = sigChildren.item(i);
		if (n.getLocalName().equals("SignedInfo")) {
		    NodeList signedInfoChildren = n.getChildNodes();
		    if (signedInfoChildren.getLength() != 0) {
			for (int j = 0; j < signedInfoChildren.getLength(); j++) {
			    Node n2 = signedInfoChildren.item(j);
			    if (n2.getLocalName().equals("Reference")) {
				refs.add(n2);
			    }
			}
		    }
		    break;
		}
	    }
	}
	if (refs.isEmpty()) {
	    throw new RuntimeException("References were not found in the document.");
	}

	return refs;
    }

    private static List<Node> mergeLists(NodeList nl1, NodeList nl2) {
	List<Node> nodeList = new LinkedList<Node>();
	for (int i = 0; i < nl1.getLength(); i++) {
	    nodeList.add(nl1.item(i));
	}
	for (int i = 0; i < nl2.getLength(); i++) {
	    nodeList.add(nl2.item(i));
	}

	return nodeList;
    }

    private static List<Node> mergeLists(List<NodeList> list) {
	List<Node> nodeList = new LinkedList<Node>();

	for (NodeList domNodeList : list) {
	    for (int i = 0; i < domNodeList.getLength(); i++) {
		nodeList.add(domNodeList.item(i));
	    }
	}

	return nodeList;
    }
}
