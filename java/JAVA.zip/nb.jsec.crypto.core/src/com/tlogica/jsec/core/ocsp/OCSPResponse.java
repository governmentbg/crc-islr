package com.tlogica.jsec.core.ocsp;
 
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Date;
import java.util.List;
import sun.security.util.DerInputStream;
import sun.security.util.DerValue;
import sun.security.util.ObjectIdentifier;
import sun.security.x509.AlgorithmId;
import sun.security.x509.CertificateIssuerName;
import sun.security.x509.Extension;
import sun.security.x509.X509CertImpl;
/*  This class is used to process an OCSP response. The OCSP Response is defined
* in RFC 0 and the ASN.1 encoding is as follows:
* OCSPResponse ::= SEQUENCE {
*   responseStatus         OCSPResponseStatus,
*   responseBytes          [0] EXPLICIT ResponseBytes OPTIONAL }
* OCSPResponseStatus ::= ENUMERATED {
*   successful            (0),  --Response has valid confirmations
*   malformedRequest      (1),  --Illegal confirmation request
*   internalError         (2),  --Internal error in issuer
*   tryLater              (3),  --Try again later
*   --(4) is not used
*   sigRequired           (5),  --Must sign the request
*   unauthorized          (6)   --Request unauthorized
* }
* ResponseBytes ::=       SEQUENCE {
*   responseType   OBJECT IDENTIFIER,
*   response       OCTET STRING }
* BasicOCSPResponse       ::= SEQUENCE {
*   tbsResponseData      ResponseData,
*   signatureAlgorithm   AlgorithmIdentifier,
*   signature            BIT STRING,
*   certs                [0] EXPLICIT SEQUENCE OF Certificate OPTIONAL }
* The value for signature SHALL be computed on the hash of the DER
* encoding of ResponseData.
* ResponseData ::= SEQUENCE {
*   version              [0] EXPLICIT Version DEFAULT v1,
*   responderID              ResponderID,
*   producedAt               GeneralizedTime,
*   responses                SEQUENCE OF SingleResponse,
*   responseExtensions   [1] EXPLICIT Extensions OPTIONAL }
* ResponderID ::= CHOICE {
*   byName               [1] Name,
*   byKey                [2] KeyHash }
* KeyHash ::= OCTET STRING -- SHA-1 hash of responder's public key
* (excluding the tag and length fields)
* SingleResponse ::= SEQUENCE {
*   certID                       CertID,
*   certStatus                   CertStatus,
*   thisUpdate                   GeneralizedTime,
*   nextUpdate         [0]       EXPLICIT GeneralizedTime OPTIONAL,
*   singleExtensions   [1]       EXPLICIT Extensions OPTIONAL }
* CertStatus ::= CHOICE {
*   good        [0]     IMPLICIT NULL,
*   revoked     [1]     IMPLICIT RevokedInfo,
*   unknown     [2]     IMPLICIT UnknownInfo }
* RevokedInfo ::= SEQUENCE {
*   revocationTime              GeneralizedTime,
*   revocationReason    [0]     EXPLICIT CRLReason OPTIONAL }
* UnknownInfo ::= NULL -- this can be replaced with an enumeration
*
* Author(s):
* Ram Marti
*/

public class OCSPResponse {
    // Certificate status CHOICE

    public static final int CERT_STATUS_GOOD = 0;
    public static final int CERT_STATUS_REVOKED = 1;
    public static final int CERT_STATUS_UNKNOWN = 2;
    private static final ObjectIdentifier OCSP_BASIC_RESPONSE_OID;
    private static final ObjectIdentifier OCSP_NONCE_EXTENSION_OID;

    static {
        ObjectIdentifier tmp1 = null;
        ObjectIdentifier tmp2 = null;
        try {
            tmp1 = new ObjectIdentifier("1.3.6.1.5.5.7.48.1.1");
            tmp2 = new ObjectIdentifier("1.3.6.1.5.5.7.48.1.2");
        } catch (Exception e) {
            // should not happen; log and exit
        }
        OCSP_BASIC_RESPONSE_OID = tmp1;
        OCSP_NONCE_EXTENSION_OID = tmp2;
    }
    // OCSP response status code
    private static final int OCSP_RESPONSE_OK = 0;
    // ResponderID CHOICE tags
    private static final int NAME_TAG = 1;
    private static final int KEY_TAG = 2;
    // Object identifier for the OCSPSigning key purpose
    private static final String KP_OCSP_SIGNING_OID = "1.3.6.1.5.5.7.3.9";
    private SingleResponse singleResponse;
    private Date producedAtDate;
    private byte[] ocspNonce;
    private AlgorithmId sigAlgId;
    private CertificateIssuerName responderName;
    private int version;
    private ObjectIdentifier responseType;
    private DerValue mainDer;
    // bytes that have been signed by the OCSP authority
    private byte[] responseData;
    // bytes of the generated signature
    private byte[] signature;
    /* OCSP additional extensions. Added by our program. */
    private X509Certificate certificateBeingChecked;
     // this could be any issuing certificate of the CA
    private X509Certificate certificateBeingCheckedIssuer;
     // this could be any OCSP-enabled certificate of the CA
    private X509Certificate certificateBeingCheckedOCSPAuthority;
    
    /**
     * Create an OCSP response from its ASN.1 DER encoding.
     * @param bytes
     * @param responderCert
     * @throws CertificateException
     * @throws IOException in case of not received or bad formatted (not ASN.1 DER encoded)
     *         answer
     * @throws OCSPException in case the received answer is signed by certificate
     *         which has not rights to generate OCSP responses. This exception is
     *         thrown also in case of failed OCSP Response status (malformed request,
     *         unsigned request, unauthorized request, internal server error)
     */
    public OCSPResponse(byte[] bytes, X509Certificate responderCert)
            throws IOException, CertificateException {
        // OCSPResponse
        mainDer = new DerValue(bytes);
        if (mainDer.tag != DerValue.tag_Sequence) {
            throw new IOException("Bad encoding in OCSP response: "
                    + "expected ASN.1 SEQUENCE tag.");
        }
        DerInputStream derIn = mainDer.getData();
        // HTTP responseStatus
        int ocspResponseStatus = derIn.getEnumerated();
        if (ocspResponseStatus != OCSP_RESPONSE_OK) {
            throw new RuntimeException("OCSP Response Failure: "
                    + responseToText(ocspResponseStatus));
        }
        // responseBytes
        mainDer = derIn.getDerValue();
        if (!mainDer.isContextSpecific((byte) 0)) {
            throw new IOException("Bad encoding in responseBytes element "
                    + "of OCSP response: expected ASN.1 context specific tag 0.");
        }
        DerValue tmp = mainDer.data.getDerValue();
        if (tmp.tag != DerValue.tag_Sequence) {
            throw new IOException("Bad encoding in responseBytes element "
                    + "of OCSP response: expected ASN.1 SEQUENCE tag.");
        }
        // responseType
        derIn = tmp.data;
        responseType = derIn.getOID();
        if (!responseType.equals(OCSP_BASIC_RESPONSE_OID)) {
            throw new IOException("Unsupported OCSP response type: " + responseType);
        }
        // BasicOCSPResponse
        DerInputStream basicOCSPResponse = new DerInputStream(derIn.getOctetString());
        DerValue[] seqTmp = basicOCSPResponse.getSequence(2);
        DerValue responseDataDer = seqTmp[0];
        // Need the DER encoded ResponseData to verify the signature later
        responseData = seqTmp[0].toByteArray();
        // tbsResponseData
        if (responseDataDer.tag != DerValue.tag_Sequence) {
            throw new IOException("Bad encoding in tbsResponseData "
                    + " element of OCSP response: expected ASN.1 SEQUENCE tag.");
        }
        DerInputStream seqDerIn = responseDataDer.data;
        DerValue seq = seqDerIn.getDerValue();
        // version
        if (seq.isContextSpecific((byte) 0)) {
            // seq[0] is version
            if (seq.isConstructed() && seq.isContextSpecific()) {
                seq = seq.data.getDerValue();
                version = seq.getInteger();
                if (seq.data.available() != 0) {
                    throw new IOException("Bad encoding in version "
                            + " element of OCSP response: bad format");
                }
                seq = seqDerIn.getDerValue();
            }
        }
        // responderID
        short tag = (byte) (seq.tag & 0x1f);
        if (tag == NAME_TAG) {
            responderName = new CertificateIssuerName(seq.getData());
        } else if (tag == KEY_TAG) {
            // Ignore, for now
        } else {
            throw new IOException("Bad encoding in responderID element of OCSP"
                    + " response: expected ASN.1 context specific tag 0 or 1");
        }
        // producedAt
        seq = seqDerIn.getDerValue();
        producedAtDate = seq.getGeneralizedTime();
        // responses
        DerValue[] singleResponseDer = seqDerIn.getSequence(1);
        // Examine only the first response
        singleResponse = new SingleResponse(singleResponseDer[0]);
        // responseExtensions
        if (seqDerIn.available() > 0) {
            seq = seqDerIn.getDerValue();
            if (seq.isContextSpecific((byte) 1)) {
                DerValue[] responseExtDer = seq.data.getSequence(3);
                Extension[] responseExtension = new Extension[responseExtDer.length];
                for (int i = 0; i < responseExtDer.length; i++) {
                    responseExtension[i] = new Extension(responseExtDer[i]);
                    if ((responseExtension[i].getExtensionId()).equals(
                            OCSP_NONCE_EXTENSION_OID)) {
                        ocspNonce = responseExtension[i].getExtensionValue();
                    } else if (responseExtension[i].isCritical()) {
                        throw new IOException("Unsupported OCSP critical extension: "
                                + responseExtension[i].getExtensionId());
                    }
                }
            }
        }
        // signatureAlgorithmId
        sigAlgId = AlgorithmId.parse(seqTmp[1]);
        // generated by the OCSP authority signature
        signature = seqTmp[2].getBitString();
        X509CertImpl[] x509Certs = null;
        // if seq[3] is available , then it is a sequence of certificates
        if (seqTmp.length > 3) {
            // certs are available
            DerValue seqCert = seqTmp[3];
            if (!seqCert.isContextSpecific((byte) 0)) {
                throw new IOException("Bad encoding in certs element "
                        + "of OCSP response: expected ASN.1 context specific tag 0.");
            }
            DerValue[] certs = (seqCert.getData()).getSequence(3);
            x509Certs = new X509CertImpl[certs.length];
            for (int i = 0; i < certs.length; i++) {
                x509Certs[i] = new X509CertImpl(certs[i].toByteArray());
            }
        }
        // Check whether the cert returned by the responder is trusted
        if (x509Certs != null && x509Certs[0] != null) {
            X509Certificate cert = x509Certs[0];
            // First check if the cert matches the responder cert which
            // was set locally.
            if (cert.equals(responderCert)) {
                // cert is trusted
                // Next check if the cert was issued by the responder cert
                // which was set locally.
            } else if (cert.getIssuerDN().equals(responderCert.getSubjectDN())) {
                // Check for the OCSPSigning key purpose
                List<String> keyPurposes = cert.getExtendedKeyUsage();
                if (keyPurposes == null || !keyPurposes.contains(KP_OCSP_SIGNING_OID)) {
                    throw new RuntimeException("Responder's certificate"
                            + "not valid for signing OCSP responses");
                }
                // verify the signature
                try {
                    cert.verify(responderCert.getPublicKey());
                    responderCert = cert;
                    // cert is trusted, now verify the signed response
                } catch (GeneralSecurityException e) {
                    responderCert = null;
                }
            }
            else{
                //System.out.println("OCSP cert is not recognized!!");
            }
        }
    }

    /*
     * Map an OCSP response status code to a string.
     */
    static private String responseToText(int status) {
        switch (status) {
            case 0:
                return "Successful";
            case 1:
                return "Malformed request";
            case 2:
                return "Internal error";
            case 3:
                return "Try again later";
            case 4:
                return "Unused status code";
            case 5:
                return "Request must be signed";
            case 6:
                return "Request is unauthorized";
            default:
                return ("Unknown status code: " + status);
        }
    }
    /*
     * Return the revocation status code for a given certificate.
     */

    public Status getCertStatus() {
        // TODO use serial number for support of multiple
        // requests/responses
        return singleResponse.getStatus();
    }

    public CertId getCertId() {
        return singleResponse.getCertId();
    }

    public Date getNextUpdate() {
        return singleResponse.nextUpdate;
    }

    public Date getRevocationTime() {
        return singleResponse.revocationTime;
    }

    public Date getThisUpdate() {
        return singleResponse.thisUpdate;
    }

    public byte[] getOcspNonce() {
        return ocspNonce;
    }

    public Date getProducedAtDate() {
        return producedAtDate;
    }

    public CertificateIssuerName getResponderName() {
        return responderName;
    }

    public AlgorithmId getSigAlgId() {
        return sigAlgId;
    }

    public byte[] getAllOCSPResponseData() throws IOException {
        return mainDer.toByteArray();
    }

    /**
     * This data was actually signed by the OCSP authority
     * @return
     */
    public byte[] getResponseData() {
        return responseData;
    }

    /**
     * This data is the actual signature of the OCSP authority
     * @return
     */
    public byte[] getSignature() {
        return signature;
    }

    public int getVersion() {
        return version;
    }

    public X509Certificate getCertificateBeingChecked() {
        return certificateBeingChecked;
    }

    public X509Certificate getCertificateBeingCheckedIssuer() {
        return certificateBeingCheckedIssuer;
    }

    public X509Certificate getCertificateBeingCheckedOCSPAuthority() {
        return certificateBeingCheckedOCSPAuthority;
    }

    void setCertificateBeingChecked(X509Certificate certificateBeingChecked) {
        this.certificateBeingChecked = certificateBeingChecked;
    }

    void setCertificateBeingCheckedIssuer(X509Certificate certificateBeingCheckedIssuer) {
        this.certificateBeingCheckedIssuer = certificateBeingCheckedIssuer;
    }

    void setCertificateBeingCheckedOCSPAuthority(X509Certificate certificateBeingCheckedOCSPAuthority) {
        this.certificateBeingCheckedOCSPAuthority = certificateBeingCheckedOCSPAuthority;
    }


    /*
     * A class representing a single OCSP response.
     */
    private class SingleResponse {

        private CertId certId;
        private Status certStatus;
        private Date revocationTime;
        private Date nextUpdate;
        private Date thisUpdate;

        private SingleResponse(DerValue der) throws IOException {
            if (der.tag != DerValue.tag_Sequence) {
                throw new IOException("Bad ASN.1 encoding in SingleResponse");
            }
            DerInputStream tmp = der.data;
            certId = new CertId(tmp.getDerValue().data);
            DerValue derVal = tmp.getDerValue();
            short tag = (byte) (derVal.tag & 0x1f);
            if (tag == CERT_STATUS_GOOD) {
                certStatus = Status.CERT_STATUS_GOOD;
            } else if (tag == CERT_STATUS_REVOKED) {
                certStatus = Status.CERT_STATUS_REVOKED;
                // RevokedInfo
                try{
                    revocationTime = derVal.data.getGeneralizedTime();
                }
                catch(IOException e){
                    // in some cases throws "garbage offset" exception
                }
            } else if (tag == CERT_STATUS_UNKNOWN) {
                certStatus = Status.CERT_STATUS_UNKNOWN;
            } else {
                throw new IOException("Invalid certificate status");
            }
            thisUpdate = tmp.getGeneralizedTime();
            if (tmp.available() == 0) {
                // we are done
            } else {
                derVal = tmp.getDerValue();
                tag = (byte) (derVal.tag & 0x1f);
                if (tag == 0) {
                    // next update
                    nextUpdate = derVal.data.getGeneralizedTime();
                    if (tmp.available() == 0) {
                        return;
                    } else {
                        derVal = tmp.getDerValue();
                        tag = (byte) (derVal.tag & 0x1f);
                    }
                }
                // ignore extensions
            }
            Date now = new Date();
            // Check that the test date is within the validity interval
            if ((thisUpdate != null && now.before(thisUpdate))
                    || (nextUpdate != null && now.after(nextUpdate))) {
                throw new IOException("Response is unreliable: its validity "
                        + "interval is out-of-date");
            }
        }
        /*
         * Return the certificate's revocation status code
         */

        private Status getStatus() {
            return certStatus;
        }

        private CertId getCertId() {
            return certId;
        }

        public Date getNextUpdate() {
            return nextUpdate;
        }

        public Date getRevocationTime() {
            return revocationTime;
        }

        public Date getThisUpdate() {
            return thisUpdate;
        }

        //Construct a string representation of a single OCSP response.
        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("SingleResponse:  \n");
            sb.append(certId);
            sb.append("\nCertStatus: ").append(getCertStatus().toString()).append("\n");
            sb.append("thisUpdate is ").append(thisUpdate).append("\n");
            if (nextUpdate != null) {
                sb.append("nextUpdate is ").append(nextUpdate).append("\n");
            }
            return sb.toString();
        }
    }
}
