package com.tlogica.jsec.core.x509;

import java.security.GeneralSecurityException;

/**
 * General Exception related to X509 issues
 * @author Miroslav Dzhokanov
 */
public class X509CertificateLoadingException extends GeneralSecurityException {

    public static final String UNDEFINED = "An exception occured while loading X509 Certificate object.";

    public X509CertificateLoadingException() {
        super(UNDEFINED);
    }

    public X509CertificateLoadingException(String string) {
        super(string);
    }

    public X509CertificateLoadingException(Throwable throwable) {
        super(throwable);
    }

    public X509CertificateLoadingException(String string, Throwable throwable) {
        super(string, throwable);
    }
}
