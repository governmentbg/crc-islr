package com.tlogica.jsec.core.pkcs;

import sun.security.pkcs.SignerInfo;

/**
 * This class holds a cryptographic signature, which is part of PKCS7 container
 * (RFC 2315).
 * The signature has been produced as a result of digital signing.
 * Current class holds:
 * - encrypted message (byte array)
 * - oid of the encryption algorithm
 * - oid of the digest algorithm (the message has been digested before encrypted)
 * @author Miroslav Dzhokanov
 */
public class PKCS7Signature {
    private byte[] signatureValue;
    private String digestAlgorithmName;
    private String encryptionAlgorithmName;

    public PKCS7Signature(SignerInfo info){
        // retrieves the encrypted message
        this.signatureValue = info.getEncryptedDigest();
        this.digestAlgorithmName = info.getDigestAlgorithmId().toString();
        this.encryptionAlgorithmName = info.getDigestEncryptionAlgorithmId().toString();
    }

    /**
     * Returns the name of the digest algorithm (SHA, MD, ...)
     * @return
     */
    public String getDigestAlgorithmName() {
        return this.digestAlgorithmName;
    }

    /**
     * Returns the name of the encryption algorithm (RSA, DSA, AES, ...)
     * @return
     */
    public String getEncryptionAlgorithmName() {
        return this.encryptionAlgorithmName;
    }

    /**
     * Returns the bytes, which has been generated after encryption.
     * @return signature values
     */
    public byte[] getSignatureBytes() {
        return this.signatureValue;
    }
}
