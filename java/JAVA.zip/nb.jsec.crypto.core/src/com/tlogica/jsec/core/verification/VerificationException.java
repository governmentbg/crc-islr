package com.tlogica.jsec.core.verification;

import java.security.GeneralSecurityException;

/**
 * General exception, which is thrown during the X509 validation process.
 * @author Miroslav Dzhokanov
 */
public class VerificationException extends GeneralSecurityException {
  
  public static final String UNDEFINED = "Undefined verification exception.";
  public static final String FIELDS_NOT_THE_SAME = "Signature Exception: Field are not the same.";
  public static final String PROCESSING_ERROR = "Signature Exception: Processing error.";
  public static final String UNSUPPORTED_ALGORITHM = "Signature Exception: Unsupported Algorithm.";
  public static final String PROVIDER_NOT_FOUND = "Signature Exception: Provider not found.";
  public static final String SIGNATURE_NOT_GENUINE = "Signature Exception: Signature not genuine.";
  public static final String NOT_EQUAL_HASHES = "Not equal hashes! The signed data is not the same as the data provided.";

  public static final String NO_SYSTEM_PROPERTIES = "No system properties (related to the verification process) were defined.";

  public static String XML_SIGNATURE_NOT_GENUINE = "XML Signature is not valid.";
  public static String XML_SIGNATURE_NOT_TIMESTAMPED = "XML Signature is not timestamped.";
  public static String XML_SIGNATURE_TIMESTAMP_NOT_VALID = "XML Signature's timestamp is not valid PKCS7.";

  public static final String CERTIFICATE_ERROR = "Certificate Exception: Undefined error.";
  public static final String CERT_CHAIN_NOT_VALID = "Certificate Exception: Certificate chain exception.";
  public static final String CERTIFICATE_EXPIRED = "Certificate Exception: Certificate expired.";
  public static final String CERTIFICATE_NOT_ACTIVATED = "Certificate Exception: Certificate was not activated.";
  public static final String CERTIFICATE_ISSUER_NOT_TRUSTED = "Certificate Exception: Certificate was issued by not trusted authority.";
  public static final String CERTIFICATE_REVOKED = "Certificate Exception: Certificate has been revoked.";
  public static final String CERTIFICATE_SELF_SIGNED = "Certificate Exception: Certificate is self-signed.";
  public static final String CERTIFICATE_REVOCATION_STATUS_COULD_NOT_BE_CHECKED = "Certificate Exception: Certificate is self-signed.";

  public static final String NO_CRL_EXCEPTION = "Can not download any CRL for this certificate.";

  private String errorCode;  
 
  public VerificationException(String mess) {
    super(mess);
    this.errorCode = VerificationException.UNDEFINED;    
  }
  
  public VerificationException(Throwable cause) {
    super(cause);
    if(cause instanceof VerificationException)
    {
      this.errorCode = ((VerificationException)cause).getErrorCode();
    }
    else{
      this.errorCode = VerificationException.UNDEFINED; 
    }
  }
  
  public VerificationException(String mess, Throwable cause) {
    super(mess, cause);
    if(cause instanceof VerificationException)
    {
      this.errorCode = ((VerificationException)cause).getErrorCode();
    }
    else{
      this.errorCode = VerificationException.UNDEFINED; 
    }  
  }
  
  public VerificationException(String mess, String errCode) {
    super(mess);
    this.errorCode = errCode;    
  }
  
  public VerificationException(Throwable cause, String errCode) {
    super(cause);
    this.errorCode = errCode;    
  }
  
  public VerificationException(String mess, Throwable cause, String errCode) {
    super(mess, cause);
    this.errorCode = errCode;    
  }
  
  public String getErrorCode() {
    return this.errorCode;
  }
  
}

