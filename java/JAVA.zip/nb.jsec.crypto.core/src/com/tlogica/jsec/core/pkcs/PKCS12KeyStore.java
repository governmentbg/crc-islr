package com.tlogica.jsec.core.pkcs;

import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.KeyStore.PrivateKeyEntry;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;
import java.util.Enumeration;

/**
 * TODO - doesn't work with key stores with multiple keys in it
 * @author Miroslav Dzhokanov
 */
public class PKCS12KeyStore {

    private InputStream m_file;
    private String m_keyStorePass;
    private String m_alias;
    private String m_keyPass;
    private PrivateKeyEntry m_privateKey;

    private PKCS12KeyStore() {
    } 
    
    /**
     * Establish contact with a PKCS12 file
     * @param file contains PKCS12 keystore
     * @param keyStorePass
     * @param alias if null then the first key in the store is get
     * @param keyPass
     * @throws KeyStoreException
     */
    public PKCS12KeyStore(InputStream file, String keyStorePass, String alias, String keyPass) throws KeyStoreException {
        m_file = file;
        m_keyStorePass = keyStorePass;
        m_alias = alias;
        m_keyPass = keyPass;
        load();
    }

    private void load() throws KeyStoreException {
        try {
            KeyStore ks = KeyStore.getInstance("PKCS12");
            ks.load(m_file, m_keyStorePass.toCharArray());
            if (m_alias == null) {
                m_alias = ks.aliases().nextElement();
            }

            m_privateKey =
                    (PrivateKeyEntry) ks.getEntry(m_alias, new KeyStore.PasswordProtection(m_keyPass.toCharArray()));

            // m_privateKey = X509Utils.getPrivateKeyEntryFromJKS(m_file, m_keyStorePass, m_alias, m_keyPass);
        } catch (KeyStoreException ex) {
            throw new KeyStoreException(ex);
        } catch (IOException ex) {
            throw new KeyStoreException(ex);
        } catch (NoSuchAlgorithmException ex) {
            throw new KeyStoreException(ex);
        } catch (CertificateException ex) {
            throw new KeyStoreException(ex);
        } catch (UnrecoverableEntryException ex) {
            throw new KeyStoreException(ex);
        }

    }

    public String getAlias() {
        return m_alias;
    } 

    public String getKeyPass() {
        return m_keyPass;
    }

    public String getKeyStorePass() {
        return m_keyStorePass;
    }

    public PrivateKeyEntry getPrivateKey() {
        return m_privateKey;
    }

    // провека за да видим дали работи
    public static void test(InputStream file, String keyStorePass, String alias, String keyPass) throws Exception {
        new PKCS12KeyStore(file, keyStorePass, alias, keyPass);
    }

    public static void main(String[] a) throws Exception {
        KeyStore ks = KeyStore.getInstance("PKCS12");
        ks.load(new java.io.FileInputStream("D:/prj-CROZ/cer&ks/all.p12"), new char[]{});
        Enumeration<String> aliases = ks.aliases();
        while(aliases.hasMoreElements()){
            String nextElement = aliases.nextElement();
            System.out.println(nextElement);
        }
    }
}
