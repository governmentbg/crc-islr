package com.tlogica.jsec.core.x509;

import com.tlogica.jsec.os.ExtensionFileFilter;
import com.tlogica.jsec.os.ResourceLocator;
import com.tlogica.jsec.utils.base64.Base64;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;

import java.security.GeneralSecurityException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Class that loads certificates from String, Stream, File, Dir.
 * It works only with ASN1 DER encoded X509Certificates.
 * @author Miroslav Dzhokanov
 */
public class X509CertLoader {

    private static final Logger log = Logger.getLogger("X509CertLoader");
    private static final String X509_TYPE = "X.509";

    /**
     * Loads X509Certificate from Base64 encoded string, which represents an
     * ASN1 DER encoded certificate.
     * @param base64EncodedString Base64 encoded string, which represents a certificate
     * @return X509Certificate
     * @throws X509Exception if it is not possible to be construct a
     *          X509Certificate from the provided string
     */
    public static X509Certificate loadX509CertificateFromString(String base64EncodedString)
            throws X509CertificateLoadingException {
        InputStream is = null;
        try {
            is = new ByteArrayInputStream(base64EncodedString.getBytes());
            return loadX509CertificateFromStream(is);
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                log.log(Level.WARNING, "Unable to close the stream. {0}", e.getMessage());
            }
        }
    }

    /**
     * Loads X.509 certificate from DER-encoded binary or base64-encoded file (usually 
     * with file extension .CER or .CRT ).
     * @param filePath the name of the refered file
     * @return X509Certificate
     * @throws GeneralSecurityException If it is not possible to parse the content
     * of the provided file
     * @throws IOException if the file was not found
     */
    public static X509Certificate loadX509CertificateFromFile(String filePath)
            throws IOException, X509CertificateLoadingException {
        File file = new File(filePath);
        return loadX509CertificateFromFile(file);
    }

    /**
     * Loads X.509 certificate from DER-encoded binary file (.CER file, .CRT file).
     * @param file referred file
     * @return X509Certificate
     * @throws GeneralSecurityException If it is not possible to be created a X509Certificate from the provided
     *  string
     * @throws IOException if the file was not found
     */
    public static X509Certificate loadX509CertificateFromFile(File file)
            throws IOException, X509CertificateLoadingException {
        InputStream is = null;

        if (file.exists()) {
            // local file
            is = new FileInputStream(file);
        } else {
            // unknown type of the resource (file, JAR, URL)
            is = ResourceLocator.loadDataFromResource(file.getPath());
        }
        if (is == null) {
            throw new IOException(file.getPath() + " was not found.");
        }

        X509Certificate cert = null;
        try {
            cert = loadX509CertificateFromStream(is);
        } finally {
            try {
                is.close();
            } catch (Exception e) {
                log.log(Level.WARNING, "Unable to close reading stream to file-{0}", file.getAbsolutePath());
            }
        }

        return cert;
    }

    /**
     * Loads all certificates from a specified directory. Able to make a deep search for 
     * certificates in the child directories. Loads only files with file extension CRT
     * or CER.
     * @param dir
     * @param deepSearch if true then this method makes a deep search for certificates
     * @return
     * @throws X509CertificateLoadingException if any of the certificate could not be loaded
     * @throws IOException in case the directory doesn't exist, or there are no
     *          certificates in the directory
     */
    public static List<X509Certificate> loadAllCertificatesFromDir(File dir, boolean deepSearch)
            throws IOException, X509CertificateLoadingException {
        log.log(Level.INFO, "Load all X509 certificates from directory - {0}", dir.getAbsolutePath());
        System.out.println("Load all X509 certificates from directory - " + dir.getPath());
        String[] cerExtensions = new String[]{"CER", "CRT", "DER"};

        // Load from local directory
        List<X509Certificate> certs = new LinkedList<X509Certificate>();
        if (dir.exists() && dir.isDirectory()) {
            ExtensionFileFilter filter = new ExtensionFileFilter(cerExtensions);
            File[] listOfFiles = dir.listFiles();
            if (listOfFiles == null || listOfFiles.length == 0) {
                throw new IOException("No certificates found in " + dir.getAbsolutePath());
            }
            for (int i = 0; i < listOfFiles.length; i++) {
                // is file
                if (listOfFiles[i].isFile() && filter.accept(dir, listOfFiles[i].getName())) {
                    X509Certificate cert = loadX509CertificateFromFile(listOfFiles[i]);
                    certs.add(cert);
                } // is directory
                else if (listOfFiles[i].isDirectory()) {
                    if (deepSearch) {
                        // recursive call
                        try{
                            certs.addAll(loadAllCertificatesFromDir(listOfFiles[i], deepSearch));
                        }
                        catch(IOException e){
                            // folder with no certificates -> do nothing
                        }
                    }
                }
            }
            log.log(Level.INFO, "{0} issuer certificates were loaded.", certs.size());
            return certs;
        }

        // Load from resource
        InputStream[] streams = null;
        try {
            streams = ResourceLocator.loadFilesFromResourceDir(dir.getPath(), deepSearch, cerExtensions);
            if (streams != null) {
                for (InputStream fis : streams) {
                    certs.add(X509CertLoader.loadX509CertificateFromStream(fis));
                }
            }
        } finally {
            if (streams != null) {
                for (InputStream is : streams) {
                    try {
                        is.close();
                    } catch (Exception e) {
                    }
                }
            }
        }
        log.log(Level.INFO, "{0} issuer certificates were loaded via ResourceLocator.", certs.size());
        return certs;
    }

    /**
     * This method ignores additional information in base64 encoded certificate
     * @param aCertStream
     * @return
     * @throws X509Exception
     */
    public static X509Certificate loadX509CertificateFromStream(InputStream certificateStream)
            throws X509CertificateLoadingException {
        // Copied stream data in here
        byte[] certificateData = readStreamToByteArray(certificateStream);

        String base64EncodedString = extractBase64EncodedString(certificateData);
        // is encoded
        if (base64EncodedString != null) {
            certificateData = base64EncodedString.getBytes();
        }

        InputStream is = new ByteArrayInputStream(certificateData);

        return loadX509CertificateFromStreamInternal(is);
    }

    private static X509Certificate loadX509CertificateFromStreamInternal(InputStream is)
            throws X509CertificateLoadingException {
        try {
            CertificateFactory cf = CertificateFactory.getInstance(X509_TYPE);
            return (X509Certificate) cf.generateCertificate(is);
        } catch (GeneralSecurityException e) {
            throw new X509CertificateLoadingException(e);
        } finally {
            try {
                is.close();
            } catch (IOException f) {
                log.log(Level.WARNING, "Unable to close the stream. {0}", f.getMessage());
            }
        }
    }

    /**
     * Extract only the encoded part (without open and ending instructions)
     * if there is an encoded part at all. If the passed data doesn't include
     * base64 encoded certificate then @null is returned. <br/>
     * This method determines whether the passed data contains base64 encoded
     * data by searchin for "-----BEGIN CERTIFICATE-----" instructions.
     *
     * @param certificateData
     * @return the base64 encoded String which was contained in the passed data
     *     null if the passed data does not include base64 encoded string
     *
     */
    private static String extractBase64EncodedString(byte[] certificateData) {
        String certText = null;
        try {
            certText = new String(certificateData, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            log.warning("Unsupported encoding exception (UTF-8)");
            certText = new String(certificateData);
        }
        String trimmedBase64EncodedString = removeStartAndEndInstructions(certText);
        trimmedBase64EncodedString = trimmedBase64EncodedString.replaceAll(" ", "");
        trimmedBase64EncodedString = trimmedBase64EncodedString.replaceAll("\n", "");
        trimmedBase64EncodedString = trimmedBase64EncodedString.replaceAll("\r", "");

        boolean isEncoded = Base64.isBase64Encoded(trimmedBase64EncodedString);
        if (isEncoded) {
            // Set process instruction lines needed for parsing the certificate
            // In some cases "-----BEGIN CERTIFICATE-----" line does not appear
            if (!trimmedBase64EncodedString.contains("-----BEGIN CERTIFICATE-----")) {
                trimmedBase64EncodedString = "-----BEGIN CERTIFICATE-----\n" + trimmedBase64EncodedString + "\n-----END CERTIFICATE-----";
            }
            return trimmedBase64EncodedString;
        }
        return null;
    }

    private static byte[] readStreamToByteArray(InputStream is) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        // Copy input stream to buffered byte array output stream
        final int BUFSIZE = 1024;
        byte[] buf = new byte[BUFSIZE];
        int n = 0;
        try {
            while ((n = is.read(buf, 0, BUFSIZE)) > 0) {
                baos.write(buf, 0, n);
            }
            baos.close();
        } catch (IOException e) {
            log.log(Level.WARNING, "Exception during writing to stream. {0}", e.getMessage());
        }

        // Copied stream data is here
        byte[] data = baos.toByteArray();

        return data;
    }

    /**
     * Removes start and end declaration of base64 encoded certificate if there 
     * are such. Returns the base64encoded string with no declarations.
     * If the passed string representation of certificate does not have such
     * star and end declarations the nothing is done in this method.
     * @return
     */
    private static String removeStartAndEndInstructions(String text) {
        if (text.contains("-----BEGIN CERTIFICATE-----")) {
            String parts[] = text.split("-----BEGIN CERTIFICATE-----");
            parts = parts[1].split("-----END CERTIFICATE-----");
            text = parts[0];
        }
        return text;
    }
}
