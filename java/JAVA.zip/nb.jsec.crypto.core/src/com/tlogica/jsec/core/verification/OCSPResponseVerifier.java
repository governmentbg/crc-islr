package com.tlogica.jsec.core.verification;

import com.tlogica.jsec.core.ocsp.CertId;
import com.tlogica.jsec.core.ocsp.OCSPResponse;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import sun.security.x509.AlgorithmId;
import sun.security.x509.X509CertImpl;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class OCSPResponseVerifier {

    /**
     * Makes offline check whether specific OCSP response is valid.
     * @param ocspResponse ASN.1/DER encoded byte array which complies with RFC 2560
     * @param userCert certificate of the user which has been checked for revocation
     * @param issuerCert issuer certificate, which issued the user certificate
     * @param responderCert certificate of the OCSP authority which we expect to have
     *          signed the OCSP response
     * @throws VerificationException in case the response is not valid due to any
     *         of next reasons:
     *         - user certificate is different
     */
    public static void verifyOCSPResponse(OCSPResponse ocspResponse) throws VerificationException {
        verifyOCSPResponse(ocspResponse,
                ocspResponse.getCertificateBeingChecked(),
                ocspResponse.getCertificateBeingCheckedIssuer(),
                ocspResponse.getCertificateBeingCheckedOCSPAuthority());
    }

    /**
     * Makes offline check whether specific OCSP response is valid.
     * @param ocspResponse ASN.1/DER encoded byte array which complies with RFC 2560
     * @param userCert certificate of the user which has been checked for revocation
     * @param issuerCert issuer certificate, which issued the user certificate
     * @param responderCert certificate of the OCSP authority which we expect to have
     *          signed the OCSP response
     * @throws VerificationException in case the response is not valid due to any
     *         of next reasons:
     *         - Signed OCSP Response is not valid
     *         - OCSP Response was signed with unrecognized certificate.
     */
    static void verifyOCSPResponse(OCSPResponse ocspResponse, X509Certificate userCert,
            X509Certificate issuerCert, X509Certificate responderCert) throws VerificationException {
        try {
            X509CertImpl issuerCertImpl = X509CertImpl.toImpl(issuerCert);
            X509CertImpl userCertImpl = X509CertImpl.toImpl((X509Certificate) userCert);
            // Check that response applies to the cert that was supplied
            CertId requestCertId = new CertId(issuerCertImpl, userCertImpl.getSerialNumberObject());
            if (!requestCertId.equals(ocspResponse.getCertId())) {
                throw new VerificationException("Certificate in the OCSP response does "
                        + "not match the certificate supplied in the OCSP request.");
            }
            // Confirm that the signed response was generated using the public
            // key from the trusted responder cert
            if (responderCert != null) {
                try{
                verifyResponseSignature(ocspResponse.getResponseData(), responderCert,
                        ocspResponse.getSigAlgId(), ocspResponse.getSignature());
                }
                catch(NoSuchAlgorithmException e){
                    throw new VerificationException("Unable to verify the signature of the OCSP response"
                            + " due to incorrectly specified algorithm - "+ocspResponse.getSigAlgId());
                }
                catch(InvalidKeyException e){
                    throw new VerificationException("Unable to verify the signature of the OCSP response."
                            + " Provided OCSP Server certificate("+responderCert.getSubjectDN()+") has"
                            + " not generated the passed signature.");
                }
                catch(SignatureException e){
                    throw new VerificationException("Unable to verify the signature of the OCSP response."
                            + " The signature object is not initialized correctly due to corrupted"
                            + " signature data or wrong algorithm specified.");
                }
            } else {
                // Need responder's cert in order to verify the signature
                throw new VerificationException("Unable to verify OCSP Responder's signature");
            }
        } catch (CertificateException e) {
            throw new VerificationException(e);
        } catch (IOException e) {
            throw new VerificationException(e);
        } catch (NoSuchAlgorithmException e) {
            throw new VerificationException(e);
        }
    }

    /**
     * Verify the signature of the OCSP response.
     * The responder's cert is implicitly trusted.
     * @param signedResponseData ResponseData which is supposed to be signed
     * @param signerCertificate certificate of the OCSP Responder which is supposed
     *        to have signed the OCSP response
     * @param signatureAlgorithmId signature algorithm
     * @param signatureBytes signature data, which should be verified
     * @throws SignatureException if the signature object is not initialized correctly
     *         due to corrupted signature data or wrong algorithm
     * @throws NoSuchAlgorithmException if the passed algorithm is not recognized
     * @throws InvalidKeyException if the passed <signerCertificate> does not match
     *         the certificate which generated the <signatureBytes>
     * @throws VerificationException if the passed signature is not valid.
     */
    private static void verifyResponseSignature(byte[] signedResponseData, X509Certificate signerCertificate,
            AlgorithmId signatureAlgorithmId, byte[] signatureBytes)
            throws NoSuchAlgorithmException, InvalidKeyException, SignatureException, VerificationException {
            Signature respSignature = Signature.getInstance(signatureAlgorithmId.getName());
            respSignature.initVerify(signerCertificate);
            respSignature.update(signedResponseData);
            if (respSignature.verify(signatureBytes)) {
               //Verified signature. Do nothing.
            } else {
                throw new VerificationException("The signature of the OCSP Response is not valid. "
                        + "May be the signature data has been modified or the signature was created "
                        + "by another OCSP server certificate.");
            }
    }
}
