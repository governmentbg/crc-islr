package com.tlogica.jsec.core.x509;

import com.tlogica.jsec.utils.base64.Base64;
import java.io.File;
import java.io.FileInputStream;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.KeyStore;
import java.security.KeyStore.PrivateKeyEntry;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableEntryException;

import java.security.cert.CRLException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import sun.security.pkcs.ParsingException;
import sun.security.x509.CRLDistributionPointsExtension;
import sun.security.x509.DistributionPoint;
import sun.security.x509.X509CertImpl;

/**
 * This class provides support functionality, related to X509 manipulation.
 * @author Miroslav Dzhokanov
 */
public class X509Utils {

    /**
     * Converts X509Certificate to Base64 encoded String.
     * @param aCert
     * @return String
     * @throws X509Exception if an encoding error occurs
     */
    public static String convertCertToB64(X509Certificate aCert) throws X509CertificateLoadingException {
        try {
            String certB64 = "-----BEGIN CERTIFICATE-----\n";
            certB64 += new String(Base64.encode(aCert.getEncoded()), "UTF-8");
            certB64 += "\n-----END CERTIFICATE-----";
            return certB64;
        } catch (CertificateEncodingException ex) {
            throw new X509CertificateLoadingException(ex);
        } catch (UnsupportedEncodingException ex) {
            throw new X509CertificateLoadingException(ex);
        }
    }

    /**
     * Extracts all CRL distribution point URLs from the "CRL Distribution Point"
     * extension in a X.509 certificate. If CRL distribution point extension is
     * unavailable, returns an empty list.
     * @param cert
     * @return
     * @throws CertificateException
     * @throws IOException
     */
    public static List<String> getCrlDistributionPoints(X509Certificate cert) {
        List<String> crlUrls = new ArrayList<String>();
        sun.security.x509.X509CertImpl certImpl = null;
        try {
            certImpl = X509CertImpl.toImpl(cert);
        } catch (CertificateException ex) {
            // не ме интересува 
        }

        if (certImpl != null) {
            sun.security.x509.CRLDistributionPointsExtension crlDistPoints =
                    certImpl.getCRLDistributionPointsExtension();
            if (crlDistPoints != null) {

                List<sun.security.x509.DistributionPoint> list = null;
                try {
                    list = (List<DistributionPoint>) crlDistPoints.get(CRLDistributionPointsExtension.POINTS);
                } catch (IOException ex) {
                    // не ме интересува
                }

                if (list != null) {
                    for (sun.security.x509.DistributionPoint distributionPoint : list) {
                        for (sun.security.x509.GeneralName generalName : distributionPoint.getFullName().names()) {
                            String generalNameString = generalName.toString();
                            if (generalNameString.startsWith("URIName: ")) {
                                String crlURLString = generalNameString.substring(9);
                                crlUrls.add(crlURLString);
                            }
                        }
                    }
                }
            }
        }

        return crlUrls;
    }
}
