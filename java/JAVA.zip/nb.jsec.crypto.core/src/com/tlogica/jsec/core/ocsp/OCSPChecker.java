package com.tlogica.jsec.core.ocsp;
 
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.security.cert.CertPathValidatorException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.List;
import sun.security.x509.AccessDescription;
import sun.security.x509.AuthorityInfoAccessExtension;
import sun.security.x509.GeneralName;
import sun.security.x509.GeneralNameInterface;
import sun.security.x509.URIName;
import sun.security.x509.X509CertImpl;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class OCSPChecker {

    private static final int CONNECT_TIMEOUT = 15000; // 15 seconds

    //
    public static Status makeOCSPCheck(
            // тоя дето ще го проверявам
            X509Certificate cert,
            // тоя дето му го е издал
            X509Certificate issuerCert,
            // тоя на ocsp
            X509Certificate ocspCert,
            //
            String ocspUrl) {
        try {
            return makeOCSPCheck(X509CertImpl.toImpl(cert), X509CertImpl.toImpl(issuerCert), X509CertImpl.toImpl(ocspCert), ocspUrl);
        } catch (CertificateException ex) {
            throw new RuntimeException("X509Certificate->X509CertImpl", ex);
        }
    }

    //
    public static Status makeOCSPCheck(
            // тоя дето ще го проверявам
            X509CertImpl cert,
            // тоя дето му го е издал
            X509CertImpl issuerCert,
            // тоя на ocsp
            X509CertImpl ocspCert,
            //
            String ocspUrl) //
    {
        // за всеки случай
        if (ocspUrl == null || ocspCert == null || issuerCert == null) {
            return Status.CERT_STATUS_UNKNOWN;
        }
        OCSPResponse ocspResponse = null;

        // make OCSP request
        // response = sendOCSPRequest(cert, issuerCert, ocspCert);
        OCSPRequest ocspRequest = null;
        // (1) OCSP заявка
        try {
            ocspRequest = new OCSPRequest(cert, issuerCert);
        } catch (CertPathValidatorException ex) {
            throw new RuntimeException("(1) OCSP заявка", ex);
        }
        //(2) свързвам се по URL-то от този дето трябва да го проверявам
        HttpURLConnection con;
        int responseCode = -1;
        try {
            URL url = new URL(ocspUrl);
            con = (HttpURLConnection) url.openConnection();
            con.setConnectTimeout(CONNECT_TIMEOUT);
            con.setReadTimeout(CONNECT_TIMEOUT);
            con.setDoOutput(true);
            con.setDoInput(true);
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-type", "application/ocsp-request");
            byte[] bytes = ocspRequest.encodeBytes();
            con.setRequestProperty("Content-length", String.valueOf(bytes.length));
            OutputStream out = con.getOutputStream();
            out.write(bytes);
            out.flush();
            responseCode = con.getResponseCode();
        } catch (Exception ex) {
            throw new RuntimeException("(2) OCSP връзка към url=" + ocspUrl, ex);
        }
        //(2.3) отговора
        if (responseCode != HttpURLConnection.HTTP_OK) {
            throw new RuntimeException("(2.3) Не успешна http-връзка responseCode=" + responseCode);
        }
        //(3) разкодиране на отговора
        try {
            InputStream in = con.getInputStream();
            ByteArrayOutputStream aos = new ByteArrayOutputStream();
            byte[] buff = new byte[4 * 1024];
            int nred = in.read(buff);
            while (nred != -1) {
                aos.write(buff, 0, nred);
                nred = in.read(buff);
            }
            ocspResponse = new OCSPResponse(aos.toByteArray(), ocspCert);
        } catch (Exception ex) {
            throw new RuntimeException("(3) разкодиране на отговора", ex);
        }
        // какво разбрах ...
        return ocspResponse.getCertStatus();
    }

    // къде да търся OCSP валидация
    static URI getResponderURI(X509CertImpl certImpl) {
//        // Examine the certificate's AuthorityInfoAccess extension
//        AuthorityInfoAccessExtension aia =
//                certImpl.getAuthorityInfoAccessExtension();
//        if (aia != null) {
//            List<AccessDescription> descriptions =
//                    aia.getAccessDescriptions();
//            for (AccessDescription description : descriptions) {
//                GeneralName generalName = description.getAccessLocation();
//                if (description.getAccessMethod().equals(AccessDescription.Ad_OCSP_Id)
//                        && generalName.getType() == GeneralNameInterface.NAME_URI) {
//                    URIName uri = (URIName) generalName.getName();
//                    return uri.getURI();
//                }
//            }
//        }
        return null;
    }
}
