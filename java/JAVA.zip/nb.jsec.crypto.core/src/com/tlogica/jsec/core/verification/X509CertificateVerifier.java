//package com.tlogica.jsec.core.verification;
//
//import com.tlogica.jsec.core.Property;
//import com.tlogica.jsec.core.x509.X509CRLChecker;
//import com.tlogica.jsec.core.x509.X509CertLoader;
//import com.tlogica.jsec.core.x509.X509CertificateLoadingException;
//import com.tlogica.jsec.os.PropertyLoader;
//import java.io.File;
//import java.io.IOException;
//import java.security.GeneralSecurityException;
//import java.security.InvalidKeyException;
//import java.security.NoSuchAlgorithmException;
//import java.security.NoSuchProviderException;
//import java.security.PublicKey;
//import java.security.Security;
//import java.security.SignatureException;
//import java.security.cert.CRLException;
//import java.security.cert.CertPathBuilder;
//import java.security.cert.CertStore;
//import java.security.cert.CertificateException;
//import java.security.cert.CollectionCertStoreParameters;
//import java.security.cert.PKIXBuilderParameters;
//import java.security.cert.PKIXCertPathBuilderResult;
//import java.security.cert.TrustAnchor;
//import java.security.cert.X509CertSelector;
//import java.security.cert.X509Certificate;
//
//import java.util.Date;
//import java.util.HashSet;
//import java.util.LinkedList;
//import java.util.List;
//import java.util.Set;
//import java.util.logging.Level;
//import java.util.logging.Logger;
//
///**
// * Validate X509 certificates
// * @author Miroslav Dzhokanov
// */
//public class X509CertificateVerifier {
//
//    private static final Logger log = Logger.getLogger("CertificateVerifier");
//    public static final String SUN_PROVIDER_NAME = "SUN";
//    public static final String SUN_RSA_PROVIDER_NAME = "SunRsaSign";
//
//    public X509CertificateVerifier() {
//    }
//
//    /**
//     * Depending to the System properties this method could makes next verifications:
//     * - time expiry check (toward current date)
//     * - time activation check (toward current date)
//     * - revocation status of the certificate (by OCSP or CRL)
//     * - direct issuer check
//     * - certificate chain check
//     * This method expect following System properties to have been loaded:
//     *      # paths to root and intermediate CA certs
//     *      trusted_issuers_dir_path = resources/ca_certs
//     *      trusted_certificates_dir_path = resources/ca_certs
//     *      # certificate verification options
//     *      check_certificate_expiry_date = true
//     *      check_certificate_activation_date = true
//     *      check_certificate_direct_issuer = true
//     *      check_certificate_chain = true
//     *      check_certificate_revocation_status_by_ocsp = true
//     *      # CRL check is not performed if OCSP check was made and valid OCSP Response was received
//     *      check_certificate_revocation_status_by_crl = true
//     *
//     * @param certificate the certificate which is being verified
//     * @throws VerificationException in case the certificate was not successfully
//     *      verified
//     */
//    public void verifyCertificate(X509Certificate certificate) throws VerificationException {
//        // check toward current system date
//        verifyCertificate(certificate, new Date());
//    }
//
//    /**
//     * Depending to the System properties this method could makes next verifications:
//     * - time expiry check (toward specified date)
//     * - time activation check (toward specified date)
//     * - revocation status of the certificate (by OCSP or CRL)
//     * - direct issuer check
//     * - certificate chain check
//     * This method expect following System properties to have been loaded:
//     *      # paths to root and intermediate CA certs
//     *      trusted_issuers_dir_path = resources/ca_certs
//     *      trusted_certificates_dir_path = resources/ca_certs
//     *      # certificate verification options
//     *      check_certificate_expiry_date = true
//     *      check_certificate_activation_date = true
//     *      check_certificate_direct_issuer = true
//     *      check_certificate_chain = true
//     *      check_certificate_revocation_status_by_ocsp = true
//     *      # CRL check is not performed if OCSP check was made and valid OCSP Response was received
//     *      check_certificate_revocation_status_by_crl = true
//     *
//     * @param date the expiry and activation checks would be performed toward this date
//     *        the certification chain would also rely on this date
//     * @param certificate the certificate which is being verified
//     * @throws VerificationException in case the certificate was not successfully
//     *      verified
//     */
//    public void verifyCertificate(X509Certificate certificate, Date date) throws VerificationException {
//        // false in case the properties has already been defined in another properties file
//        PropertyLoader.loadFromFile(Property.PROPERTY_FILE, false);
//        // get system properties
//        Boolean checkActivationDate = getBooleanProperty(Property.CHECK_CERTIFICATE_ACTIVATION_DATE);
//        Boolean checkExpiryDate = getBooleanProperty(Property.CHECK_CERTIFICATE_EXPIRY_DATE);
//        Boolean checkDirectIssuer = getBooleanProperty(Property.CHECK_CERTIFICATE_DIRECT_ISSUER);
//        Boolean checkCertChain = getBooleanProperty(Property.CHECK_CERTIFICATE_CHAIN);
//        Boolean checkOCSP = getBooleanProperty(Property.CHECK_CERTIFICATE_REVOCATION_STATUS_BY_OCSP);
//        Boolean checkCRL = getBooleanProperty(Property.CHECK_CERTIFICATE_REVOCATION_STATUS_BY_CRL);
//
//        // validate system properties
//        if (checkActivationDate == null && checkExpiryDate == null && checkDirectIssuer == null
//                && checkCertChain == null && checkOCSP == null && checkCRL == null) {
//            throw new VerificationException("No verification was performed due to missing system properties.",
//                    VerificationException.NO_SYSTEM_PROPERTIES);
//        }
//
//        // perform activation date check
//        if (checkActivationDate != null && checkActivationDate && !wasCertificateActivated(certificate, date)) {
//            throw new VerificationException("Certificate [SN=" + certificate.getSerialNumber() + "] "
//                    + "was not active (was not activated yet) on this date - " + date,
//                    VerificationException.CERTIFICATE_NOT_ACTIVATED);
//        }
//        // perform expiry date check
//        if (checkExpiryDate != null && checkExpiryDate && wasCertificateExpired(certificate, date)) {
//            throw new VerificationException("Certificate [SN=" + certificate.getSerialNumber() + "] "
//                    + "was not active (was expired) on this date - " + date,
//                    VerificationException.CERTIFICATE_EXPIRED);
//        }
//        // perform direct issuer check
//        if (checkDirectIssuer != null && checkDirectIssuer) {
//            String trustedIssuersDir = System.getProperty(Property.TRUSTED_ISSUERS_DIR);
//            log.log(Level.INFO, Property.TRUSTED_ISSUERS_DIR + " --> " + trustedIssuersDir);
//            if (trustedIssuersDir != null) {
//                List<X509Certificate> trustedIssuers = null;
//                try {
//                    trustedIssuers = X509CertLoader.loadAllCertificatesFromDir(new File(trustedIssuersDir), false);
//                } catch (IOException e) {
//                    log.log(Level.WARNING, "Direct issuer check is not performed because trusted certificates "
//                            + "could not be loaded. Directory " + trustedIssuersDir + " was not found.", e);
//                } catch (X509CertificateLoadingException e) {
//                    log.log(Level.WARNING, "Direct issuer check is not performed because trusted certificates "
//                            + "could not be loaded from " + trustedIssuersDir + ". Some of the certificates "
//                            + "have bad format/structure, furthermore they are unparseable", e);
//                }
//                if (trustedIssuers != null && !trustedIssuers.isEmpty()) {
//                    verifyCertificateIssuer(certificate, trustedIssuers);
//                } else {
//                    log.log(Level.WARNING, "Direct issuer check is not performed because trusted certificates " + "could not be loaded. Directory " + "{0} was not found.", trustedIssuersDir);
//                }
//            }
//        }
//        // perform certification chain check
//        if (checkCertChain != null && checkCertChain) {
//            String trustedCertsDir = System.getProperty(Property.TRUSTED_CERTS_DIR);
//            log.info(Property.TRUSTED_CERTS_DIR + " --> " + trustedCertsDir);
//            if (trustedCertsDir != null) {
//                List<X509Certificate> trustedCerts = null;
//                try {
//                    trustedCerts = X509CertLoader.loadAllCertificatesFromDir(new File(trustedCertsDir), false);
//                } catch (IOException e) {
//                    log.log(Level.WARNING, "Cerificate chain check is not performed because trusted certificates "
//                            + "could not be loaded. Directory " + trustedCertsDir + " was not found.", e);
//                } catch (X509CertificateLoadingException e) {
//                    log.log(Level.WARNING, "Cerificate chain check is not performed because trusted certificates "
//                            + "could not be loaded from " + trustedCertsDir + ". Some of the certificates "
//                            + "have bad format/structure, furthermore they are unparseable", e);
//                }
//                if (trustedCerts != null && !trustedCerts.isEmpty()) {
//                    verifyCertificationChain(certificate, trustedCerts, date);
//                } else {
//                    log.log(Level.WARNING, "Cerificate chain check is not performed because trusted certificates " + "could not be loaded. Directory " + "{0} was not found.", trustedCertsDir);
//                }
//            }
//        }
//        // perform certification chain check
//        Boolean isRevoked = null;
////        if (checkOCSP != null && checkOCSP) {
////            try {
////                isRevoked = OCSPChecker.isCertificateRevokedOnlineOCSPCheck(certificate);
////                if (isRevoked) {
////                    throw new VerificationException("Certificate [SN=" + certificate.getSerialNumber() + "] has been revoked.", VerificationException.CERTIFICATE_REVOKED);
////                }
////            } catch (X509RelationsException ex) {
////                log.log(Level.WARNING, "Cerificate revocation status check (by OCSP) was not performed.", ex);
////            }
////        }
//
//        // OCSP check were not performed
//        if (isRevoked == null && checkCRL != null && checkCRL) {
//            try {
//                isRevoked = X509CRLChecker.isCertificateRevokedOnlineCRLCheck(certificate);
//                if (isRevoked) {
//                    throw new VerificationException("Certificate [SN=" + certificate.getSerialNumber() + "] has been revoked.", VerificationException.CERTIFICATE_REVOKED);
//                }
//            } catch (CRLException ex) {
//                log.log(Level.WARNING, "Cerificate revocation status check (by downloading CRL) was not performed.", ex);
//            }
//        }
//        // throw exception in case of of unsuccessful revocation status check
//        if ((checkOCSP != null && checkOCSP == true) || (checkCRL != null && checkCRL == true)) {
//            if (isRevoked == null) {
//                throw new VerificationException("Certificate [SN=" + certificate.getSerialNumber() + "] revocation status can not be checked.",
//                        VerificationException.CERTIFICATE_REVOCATION_STATUS_COULD_NOT_BE_CHECKED);
//            }
//        }
//    }
//
//    /**
//     * Return value of system property which is of type Boolean
//     * @param propertyName
//     * @return null if no such property was found or the found property is not
//     *         of Boolean type
//     */
//    private Boolean getBooleanProperty(String propertyName) {
//        String propertyString = System.getProperty(propertyName);
//        if (propertyString != null) {
//            try {
//                return Boolean.parseBoolean(propertyString);
//            } catch (Exception e) {
//                log.log(Level.SEVERE, "System property ({0}) is not of type Boolean.", propertyName);
//            }
//        } else {
//            log.log(Level.WARNING, "System property ({0}) was not found.", propertyName);
//        }
//        return null;
//    }
//
//    /**
//     * Checks whether given X.509 certificate is self-signed.
//     * @param aCertificate
//     * @return
//     * @throws CertificateException
//     * @throws NoSuchAlgorithmException
//     * @throws NoSuchProviderException
//     */
//    public boolean isSelfSigned(X509Certificate aCertificate) throws CertificateException,
//            NoSuchAlgorithmException,
//            NoSuchProviderException {
//        try {
//            // Try to verify certificate signature with its own public key
//            PublicKey key = aCertificate.getPublicKey();
//            aCertificate.verify(key);
//            return true;
//        } catch (SignatureException sigEx) {
//            // Invalid signature --> not self-signed
//            return false;
//        } catch (InvalidKeyException keyEx) {
//            // Invalid key --> not self-signed
//            return false;
//        }
//    }
//
//    public boolean wasCertificateActivated(X509Certificate certificate,
//            Date inputDate) throws VerificationException {
//        log.log(Level.INFO, "Verifying certificate validity toward {0}", inputDate.toString());
//        Date fromDate = certificate.getNotBefore();
//        if (fromDate.compareTo(inputDate) > 0) {
//            return false;
//        }
//        return true;
//    }
//
//    public boolean wasCertificateExpired(X509Certificate certificate,
//            Date inputDate) throws VerificationException {
//        log.log(Level.INFO, "Verifying certificate validity toward {0}", inputDate.toString());
//        Date toDate = certificate.getNotAfter();
//        if (toDate.compareTo(inputDate) < 0) {
//            return true;
//        }
//        return false;
//    }
//
//    /**
//     * Verifies that this certificate was directly signed by some of the
//     * passed trusted certificates
//     * @param aCertificate - Certificate to be verified
//     * @param aTrustedCertificates - Trusted Root Certificates
//     * @throws VerificationException if verification fail
//     */
//    public void verifyCertificateIssuer(X509Certificate aCertificate,
//            List<X509Certificate> aTrustedCertificates) throws VerificationException {
//        log.info("Direct verifying of certificate's issuer.");
//        System.out.println(" TYPE="+aCertificate.getType());
//        System.out.println(" IssuerDN="+aCertificate.getIssuerDN());
//        System.out.println(" IssuerX500Principal="+aCertificate.getIssuerX500Principal());
//        System.out.println(" NotAfter="+aCertificate.getNotAfter());
//        System.out.println(" NotBefore="+aCertificate.getNotBefore());
//        System.out.println(" SerialNumber="+aCertificate.getSerialNumber());
//        System.out.println(" SubjectDN="+aCertificate.getSubjectDN());
//        System.out.println(" SubjectX500Principal="+aCertificate.getSubjectX500Principal());
//        System.out.println(" Version="+aCertificate.getVersion());
//        // Check if the certificate is signed by some of the given trusted certificates
//        for (X509Certificate trustedCert : aTrustedCertificates) {
//            try {
//                aCertificate.verify(trustedCert.getPublicKey());
//                // Found parent certificate. Certificate is verified to be valid
//                return;
//            } catch (GeneralSecurityException ex) {
//                // Certificate is not signed by current trustedCert. Try the next one
//            }
//        }
//        // Cert. is not signed by any of the trusted certificates
//        throw new VerificationException("Issuing certificate is not trusted - " + aCertificate.getIssuerDN().getName(),
//                VerificationException.CERTIFICATE_ISSUER_NOT_TRUSTED);
//    }
//
//    /**
//     * Verifies all the chain above specified certificate. For this purpose checks
//     * the completeness of the chain and validity toward specific date.
//     * @param certificate the certificate which is being verified
//     * @param CAs parent certificates to be included in the chain
//     * @param verificationDate checks all parent certificate toward this date.
//     *      If null then verification toward specific date is not performed on
//     *      any of the certificates in the chain.
//     * @throws VerificationException in case the certificate was not successfully
//     *      verified
//     */
//    public void verifyCertificationChain(X509Certificate certificate,
//            List<X509Certificate> CAs,
//            Date verificationDate) throws VerificationException {
//        try {
//            // revocation status is checked by <OCSPChecker> or <X509CRLChecker> classes
//            boolean verifyRevocationStatus = false;
//            verifyCertificationChainInternal(certificate, CAs, verificationDate, verifyRevocationStatus);
//        } catch (VerificationException e) {
//            throw e;
//        }
//    }
//
//    /**
//     * Attempts to build a certification chain for given certificate and to verify
//     * it. Relies on a set of root CA certificates and intermediate certificates
//     * that will be used for building the certification chain. The verification
//     * process assumes that all self-signed certificates in the set are trusted
//     * root CA certificates and all other certificates in the set are intermediate
//     * certificates.
//     *
//     * @param aCertificate - certificate for validation
//     * @param aAdditionalCerts - set of trusted root CA certificates that will be
//     *      used as "trust anchors" and intermediate CA certificates that will be
//     *      used as part of the certification chain. All self-signed certificates
//     *      are considered to be trusted root CA certificates. All the rest are
//     *      considered to be intermediate CA certificates.
//     * @param verificationDate verify against this date (all certificates in the chain)
//     * @param verifyRevocationStatus if true this method makes OCSP check in order
//     *        to determine whether the user certificate has been revoked
//     * @return the certification chain (if verification is successful)
//     * @throws VerificationException - if the certification is not
//     *      successful (e.g. certification path cannot be built or some
//     *      certificate in the chain is expired or CRL checks are failed)
//     */
//    private PKIXCertPathBuilderResult verifyCertificationChainInternal(X509Certificate aCertificate,
//            List<X509Certificate> aAdditionalCerts,
//            Date verificationDate, boolean verifyRevocationStatus) throws VerificationException {
//        log.info("Verifying certificate chain.");
//        try {
//            // Check for self-signed certificate
//            if (isSelfSigned(aCertificate)) {
//                throw new VerificationException("The certificate is self-signed.", VerificationException.CERTIFICATE_SELF_SIGNED);
//            }
//
//            // Prepare a set of trusted root CA certificates
//            // and a set of intermediate certificates
//            List<X509Certificate> trustedRootCerts = new LinkedList<X509Certificate>();
//            List<X509Certificate> intermediateCerts = new LinkedList<X509Certificate>();
//
//            for (X509Certificate additionalCert : aAdditionalCerts) {
//                if (isSelfSigned(additionalCert)) {
//                    trustedRootCerts.add(additionalCert);
//                } else {
//                    intermediateCerts.add(additionalCert);
//                }
//            }
//
//            // Attempt to build the certification chain and verify it
//            PKIXCertPathBuilderResult verifiedCertChain = null;
//            try {
//                verifiedCertChain = verifyCertificationChainInternal(aCertificate, trustedRootCerts,
//                        intermediateCerts, verificationDate, verifyRevocationStatus);
//            } catch (GeneralSecurityException ex) {
//                throw new VerificationException("Unable to construct a verification chain for this certificate [SN=" + aCertificate.getSerialNumber() + "]",
//                        ex, VerificationException.CERT_CHAIN_NOT_VALID);
//            }
//            return verifiedCertChain;
//
//        } catch (VerificationException ex) {
//            throw ex;
//        } catch (GeneralSecurityException ex) {
//            throw new VerificationException("Error verifying certificate [SN=" + aCertificate.getSerialNumber() + "]",
//                    ex, VerificationException.CERT_CHAIN_NOT_VALID);
//        }
//    }
//
//    /**
//     * Attempts to build a certification chain for given certificate and to verify
//     * it. Relies on a set of root CA certificates (trust anchors) and a set of
//     * intermediate certificates (to be used as part of the chain).
//     * @param aCertificate - certificate for validation
//     * @param aTrustedRootCerts - set of trusted root CA certificates
//     * @param aIntermediateCerts - set of intermediate certificates
//     * @return the certification chain (if verification is successful)
//     * @throws GeneralSecurityException - if the verification is not successful
//     *      (e.g. certification path cannot be built or some certificate in the
//     *      chain is expired)
//     */
//    private PKIXCertPathBuilderResult verifyCertificationChainInternal(X509Certificate aCertificate,
//            List<X509Certificate> aTrustedRootCerts,
//            List<X509Certificate> aIntermediateCerts,
//            Date verificationDate, boolean verifyRevocationStatus) throws GeneralSecurityException {
//        // Create the selector that specifies the starting certificate
//        X509CertSelector selector = new X509CertSelector();
//        selector.setCertificate(aCertificate);
//
//        // Create the trust anchors (set of root CA certificates)
//        Set<TrustAnchor> trustAnchors = new HashSet<TrustAnchor>();
//        for (X509Certificate trustedRootCert : aTrustedRootCerts) {
//            trustAnchors.add(new TrustAnchor(trustedRootCert, null));
//        }
//
//        // Configure the PKIX certificate builder algorithm parameters
//        PKIXBuilderParameters pkixParams = new PKIXBuilderParameters(trustAnchors, selector);
//
//        // Enable OCSP/CRL checks (CRL check occurs only if OCSP check fails)
//        if (verifyRevocationStatus) {
//            pkixParams.setRevocationEnabled(true);
//            Security.setProperty("ocsp.enable", "true");
//        } // Disable CRL/OCSP checks (this is done manually as additional step)
//        else {
//            Security.setProperty("ocsp.enable", "false");
//            pkixParams.setRevocationEnabled(false);
//        }
//
//
//        // IMPORTANT
//        // If we do not add the certificate that is being validated, the chain would NOT be constructed succesfully
//        aIntermediateCerts.add(aCertificate);
//
//        // Specify a list of intermediate certificates
//        CertStore intermediateCertStore =
//                CertStore.getInstance("Collection", new CollectionCertStoreParameters(aIntermediateCerts),
//                SUN_PROVIDER_NAME);
//
//        pkixParams.addCertStore(intermediateCertStore);
//
//        if (verificationDate == null) {
//            // this check always return true if the root and intermediate certificates
//            // were active on the date when verifiable certificate was issued
//            pkixParams.setDate(aCertificate.getNotBefore());
//        } else {
//            // Otherwise CertpathBuilder would check certificate's validation period toward current date.
//            pkixParams.setDate(verificationDate);
//        }
//
//        // Build and verify the certification chain
//        CertPathBuilder builder = CertPathBuilder.getInstance("PKIX", SUN_PROVIDER_NAME);
//        PKIXCertPathBuilderResult result =
//                (PKIXCertPathBuilderResult) builder.build(pkixParams);
//        return result;
//    }
//}
