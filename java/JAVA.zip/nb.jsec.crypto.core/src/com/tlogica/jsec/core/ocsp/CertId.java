package com.tlogica.jsec.core.ocsp;

import com.tlogica.jsec.utils.base64.Base64;
import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import sun.security.util.DerInputStream;
import sun.security.util.DerOutputStream;
import sun.security.util.DerValue;
import sun.security.x509.AlgorithmId;
import sun.security.x509.SerialNumber;
import sun.security.x509.X509CertImpl;

/*
* This class corresponds to the CertId field in OCSP Request and the OCSP Response.
* The ASN.1 definition for CertID is defined in RFC 0 as:
* CertID          ::=     SEQUENCE {
*   hashAlgorithm       AlgorithmIdentifier,
*   issuerNameHash      OCTET STRING, -- Hash of Issuer's DN
*   issuerKeyHash       OCTET STRING, -- Hash of Issuers public key
*   serialNumber        CertificateSerialNumber
* }
*/
public class CertId {

    private AlgorithmId hashAlgId;
    private byte[] issuerNameHash;
    private byte[] issuerKeyHash;
    private SerialNumber certSerialNumber;
    private int myhash = -1; // hashcode for this CertId

//Creates a CertId. The hash algorithm used is SHA-1.
    public CertId(X509CertImpl issuerCert, SerialNumber serialNumber) throws IOException, NoSuchAlgorithmException {

        // compute issuerNameHash
        MessageDigest md = MessageDigest.getInstance("SHA1");
        hashAlgId = AlgorithmId.get("SHA1");
        md.update(issuerCert.getSubjectX500Principal().getEncoded());
        issuerNameHash = md.digest();

        // compute issuerKeyHash (remove the tag and length)
        byte[] pubKey = issuerCert.getPublicKey().getEncoded();
        DerValue val = new DerValue(pubKey);
        DerValue[] seq = new DerValue[2];
        seq[0] = val.data.getDerValue(); // AlgorithmID
        seq[1] = val.data.getDerValue(); // Key
        byte[] keyBytes = seq[1].getBitString();
        md.update(keyBytes);
        issuerKeyHash = md.digest();
        certSerialNumber = serialNumber;
    }

//Creates a CertId from its ASN.1 DER encoding.
    public CertId(DerInputStream derIn) throws IOException {
        hashAlgId = AlgorithmId.parse(derIn.getDerValue());
        issuerNameHash = derIn.getOctetString();
        issuerKeyHash = derIn.getOctetString();
        certSerialNumber = new SerialNumber(derIn);
    }

//Return the hash algorithm identifier.
    public AlgorithmId getHashAlgorithm() {
        return hashAlgId;
    }

//Return the hash value for the issuer name.
    public byte[] getIssuerNameHash() {
        return issuerNameHash;
    }

//Return the hash value for the issuer key.
    public byte[] getIssuerKeyHash() {
        return issuerKeyHash;
    }

//Return the serial number.
    public BigInteger getSerialNumber() {
        return certSerialNumber.getNumber();
    }

//Encode the CertId using ASN.1 DER. The hash algorithm used is SHA-1.
    public void encode(DerOutputStream out) throws IOException {
        DerOutputStream tmp = new DerOutputStream();
        hashAlgId.encode(tmp);
        tmp.putOctetString(issuerNameHash);
        tmp.putOctetString(issuerKeyHash);
        certSerialNumber.encode(tmp);
        out.write(DerValue.tag_Sequence, tmp);
    }

//Returns a hashcode value for this CertId.
    @Override
    public int hashCode() {
        if (myhash == -1) {
            myhash = hashAlgId.hashCode();
            for (int i = 0; i < issuerNameHash.length; i++) {
                myhash += issuerNameHash[i] * i;
            }
            for (int i = 0; i < issuerKeyHash.length; i++) {
                myhash += issuerKeyHash[i] * i;
            }
            myhash += certSerialNumber.getNumber().hashCode();
        }
        return myhash;
    }

    /*Compares this CertId for equality with the specified object. Two CertId objects are considered equal if their hash algorithms, their issuer name and issuer key hash values and their serial numbers are equal.
    Parameters:
    other the object to test for equality with this object.
    Returns:
    true if the objects are considered equal, false otherwise.*/
    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || (!(other instanceof CertId))) {
            return false;
        }
        CertId that = (CertId) other;
        if (hashAlgId.equals(that.getHashAlgorithm())
                && Arrays.equals(issuerNameHash, that.getIssuerNameHash())
                && Arrays.equals(issuerKeyHash, that.getIssuerKeyHash())
                && certSerialNumber.getNumber().equals(that.getSerialNumber())) {
            return true;
        } else {
            return false;
        }
    }

//Create a string representation of the CertId.
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("CertId \n");
        sb.append("Algorithm: ").append(hashAlgId.toString()).append("\n");
        sb.append("issuerNameHash \n");
        sb.append(new String(Base64.encode(issuerNameHash)));
        sb.append("\nissuerKeyHash: \n");
        sb.append(new String(Base64.encode(issuerKeyHash)));
        sb.append("\n").append(certSerialNumber.toString());
        return sb.toString();
    }
}
