package com.tlogica.jsec.core.pkcs;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FilenameFilter;
import java.security.Provider;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.security.auth.login.LoginException;

/**
 * This class provide access to PKCS11 Smart Card reader. The access is established via PKCS11 DLLs (Siemens,
 * Charismatics ...) The location of the PKCS11 DLLs is written in the pkcs11 config files.
 *
 * @author Miroslav Dzhokanov
 */
public class PKCS11KeyStore {

    // TODO: това да се чете на
    // какви dll познавам и търся ...
    //http://www.infoseccorp.com/products/secretagent/support/pkcs11.htm
    //http://www.koders.com/noncode/fid57E0E0B63C88E5FF7A14B501B48BF0C95CF59E8D.aspx
    //http://janus.liebregts.nl/pkcs11/smartc.html
    public static final String[] dlls = new String[]{
	"core32"//unknowen
	, "cvP11"//(for JCOP)(for some Siemens Card OS cards)
	, "dkck232"//unknowen
	, "settoki"//unknowen
	, "pkcs11v2"//unknowen
	, "spypk11"//unknowen
	, "cmP11"//unknowen
	, "w32pk2ig"//unknowen
	, "bit4ipki"//unknowen
	, "pseudotoken"//unknowen
	, "cmP1164"//unknowen
	, "aetpkss1" //(for G&D StarCos and Rainbow iKey 3000)
	, "cs2_pkcs11" //(for Utimaco CryptoServer LAN)
	, "CccSigIT" //(for IBM MFC)
	, "pk2priv" //(for GemSAFE, old version)
	, "gclib" //(for GemSAFE, new version)
	, "dspkcs" //(for Dallas iButton)
	, "slbck" //(for Schlumberger Cryptoflex and Cyberflex Access)
	//, "SetTokI" //(for SeTec)
	, "acpkcs" //(for ActivCard)
	, "psepkcs11" //(for A-Sign Premium)
	, "id2cbox" //(for ID2 PKCS#11)
	, "smartp11" //(for SmartTrust PKCS#11)
	, "pkcs201n" //(for Utimaco Cryptoki for SafeGuard)
	, "dkck201" //(for DataKey and Rainbow iKey 2000 series)
	, "AuCryptoki2-0" //(for Oberthur AuthentIC)
	, "eTpkcs11" //(for Aladdin eToken, and some Siemens Card OS cards)
	, "cknfast" //(for nCipher nFast or nShield)
	, "cryst201" //(for Chrysalis LUNA)
	, "cryptoki" //(for IBM 4758)/(for Eracom CSA)
	, "softokn3" //(for the Mozilla or Netscape crypto module, see also next property)
	, "iveacryptoki" //(for Rainbow CryptoSwift HSM)
	, "sadaptor" //(for Eutron CryptoIdentity or Algorithmic Research MiniKey)
	, "pkcs11" //(for TeleSec)
	, "siecap11" //(for Siemens HiPath SIcurity Card API)
	, "asepkcs" //(for Athena Smartcard System ASE Card) 
    };
    // списък със успешно заредени dll-и
    private final List<Provider> providers =
	    new ArrayList<Provider>();

    // почиствам дани от предходно подписване
    public void step0() {
	try {
	    for (Provider p : providers)
		((sun.security.pkcs11.SunPKCS11) p).logout();

	} catch (LoginException ex) {
	    //
	}
	providers.clear();
    }

    // намирам всички потенциялни pkcs11-dll-и
    public List<Provider> step1() {
	// почистване ...
	step0();
	// направи pattern
	final String fileNamePattern;
	{
	    StringBuilder sb = new StringBuilder();
	    String delim = "((";
	    for (String fileName : dlls) {
		sb.append(delim);
		sb.append(fileName.toLowerCase());
		sb.append(")");
		delim = "|(";
	    }
	    sb.append(")[.]dll");
	    fileNamePattern = sb.toString();
	}
	// къде да търся dll-ли
	String sysPath = System.getenv("Path").toString();
	// зареди наличните pkcs11-dll
	for (String d : sysPath.split(";")) {
	    File dir = new File(d);
	    if (!dir.exists() || !dir.isDirectory()) {
		continue;
	    }
	    // имам опасност файла да е написан с малки/големи букви !
	    File[] myDll = dir.listFiles(new FilenameFilter() {

		public boolean accept(File dir, String name) {
		    // само от dll-списъка ми
		    return name.toLowerCase().matches(fileNamePattern);
		}
	    });
	    System.out.printf("? dir = %s \n", d);
	    for (File dll : myDll) {
		// има ли го на компютъра
		if (dll.exists()) {
		    String config = String.format("name = %s\nlibrary = %s\n", dll.getName(), dll.toString());
		    // пробвам да ползва dll
		    ByteArrayInputStream is = new ByteArrayInputStream(config.getBytes());
		    Provider provider;
		    try {
			provider = new sun.security.pkcs11.SunPKCS11(is);
		    } catch (Exception ex) {
			// явно това не е моя
			//System.out.println("!" + dll + ":" + ex.getMessage());
			continue;
		    }
		    System.out.printf("+ pkcs11[%s]\n", dll.toString());
		    // запазвам си го, за да го пробвам после
		    providers.add(provider);
		}
	    }
	}
	// опа-а
	if (providers.isEmpty()) {
	    throw new RuntimeException(" Няма намерена подходяща PKCS#11 библиотека(dll-файл)");
	}
	return providers;
    }
}
