package com.tlogica.jsec.core.ocsp;

/**
 *
 * @author Miroslav Dzhokanov
 */
public enum Status {
    CERT_STATUS_GOOD, 
    CERT_STATUS_REVOKED, 
    CERT_STATUS_UNKNOWN;
}
