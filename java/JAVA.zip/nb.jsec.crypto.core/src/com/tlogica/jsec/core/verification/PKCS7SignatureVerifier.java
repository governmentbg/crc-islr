package com.tlogica.jsec.core.verification;

import com.tlogica.jsec.core.pkcs.PKCS7Container;
import com.tlogica.jsec.core.pkcs.PKCS7Signature;
import com.tlogica.jsec.core.pkcs.PKCS7SignedData;
import com.tlogica.jsec.utils.ByteArray;
import com.tlogica.jsec.utils.base64.Base64;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.util.logging.Logger;
import sun.security.pkcs.ParsingException;

/**
 * Class that validates X509 signatures
 * @author Miroslav Dzhokanov
 */
public class PKCS7SignatureVerifier {

    private byte[] contentData;
    private byte[] signatureData;
    private String content;
    private static final Logger log = Logger.getLogger("PKCS7SignatureVerifier");

    /**
     * Initialize a verifier of PKCS #7 signature.
     * 
     * @param signature PKCS7 signature container (RFC-2315) (base64 encoded DER 
     *        or binary DER)
     * @param signedContent data, which is supposed to have been signed and to relate
     *        to the passed signature
     */
    public PKCS7SignatureVerifier(byte[] signature, byte[] signedContent) {
        signatureData = signature;
        contentData = signedContent;
        this.content = new String(signedContent);
    }

    /**
     * Verify that the signature corresponds to the included signer certificate
     * and the signed text has not been changed after signing
     * @throws VerificationException if error occur
     */
    public void verify() throws VerificationException {

        try {
            // Extract certitificate from signature, using SUN API
            PKCS7Container pkcs7 = new PKCS7Container(signatureData);
            PKCS7Signature signature = pkcs7.getSignature();
            PKCS7SignedData signedData = pkcs7.getSignedData();
            String digestAlgorithm = signature.getDigestAlgorithmName();

            // Add 1 to SHA => SHA1
            if ("SHA".equals(digestAlgorithm)) {
                digestAlgorithm = "SHA1";
            }

            String signingAlgorithm = digestAlgorithm + "with" + signature.getEncryptionAlgorithmName();
            // Constructing signature
            Signature sig = Signature.getInstance(signingAlgorithm);
            PublicKey pubKey = pkcs7.getSignerCert().getPublicKey();
            // Initialize Signature object
            sig.initVerify(pubKey);
            // Update signature object with the signed content
            sig.update(signedData.getSignedDataBytes());
            // Verification
            boolean verified = sig.verify(signature.getSignatureBytes());
            if (!verified) {
                throw new VerificationException("The signature is not valid. Signatute has been modified.");
            } else {
                log.info("Verified that signature bytes has not been modified. Now should check"
                        + " the content bytes too.");
            }
            // determine whether the original data has been modified
            checkHashMatches(signedData.getMessageDigest(), digestAlgorithm);

        } catch (ParsingException ex) {
            throw new VerificationException(ex);
        } catch (IOException ex) {
            throw new VerificationException(ex);
        } catch (SignatureException ex) {
            throw new VerificationException(ex);
        } catch (InvalidKeyException ex) {
            throw new VerificationException(ex);
        } catch (NoSuchAlgorithmException ex) {
            throw new VerificationException(ex);
        }
    }

    /**
     * Current method encode the defined <content> String with several encodings
     * because there is no information about the encoding in which the initial content
     * was signed. This encoding depends on HTTP Server configuration and the
     * concrete web browser which the user has used (for example IE encodes each
     * string with <UnicodeLittleUnmarked> encoding).
     * Depending to the initial encoding the bytes that have been hashed
     * and later encrypted are different.
     * Currently in this method we compare the signed hash toward the content data
     * encoded in following encodings:
     *  UTF-8
     *  windows-1251
     *  windows-1252
     *  UnicodeLittleUnmarked
     *  ISO-8859-1
     *  ISO-8859-5
     *
     * @param signedHash this is the digest of the original message which were signed
     * @param digestAlgorithm algodithm which produced the hash
     * @throws VerificationException
     * @throws UnsupportedEncodingException
     * @throws NoSuchAlgorithmException
     */
    private void checkHashMatches(byte[] signedHash, String digestAlgorithm) throws VerificationException, UnsupportedEncodingException, NoSuchAlgorithmException{
        // retrieves the hash of the content
            MessageDigest digest = MessageDigest.getInstance(digestAlgorithm);
            byte[] contentHash = digest.digest(contentData);
            // retrieves the hash of the content, whit another encoding (used in IE)
            byte[] contentIE = content.getBytes("UnicodeLittleUnmarked"); // Internet Explorer encoding
            byte[] contentIEHash = digest.digest(contentIE);

            byte[] content1251 = content.getBytes("windows-1251");
            byte[] content1251Hash = digest.digest(content1251);

            byte[] content1252 = content.getBytes("windows-1252");
            byte[] content1252Hash = digest.digest(content1252);

            byte[] contentUTF8 = content.getBytes("UTF-8");
            byte[] contentUTF8Hash = digest.digest(contentUTF8);

            byte[] contentISO_8859_1 = content.getBytes("ISO-8859-1");
            byte[] contentISO_8859_1Hash = digest.digest(contentISO_8859_1);

            byte[] contentISO_8859_5 = content.getBytes("ISO-8859-5");
            byte[] contentISO_8859_5Hash = digest.digest(contentISO_8859_5);

            // Verify the content has not been changed after signing
            boolean equalHashes = ByteArray.constantTimeAreEqual(signedHash, contentHash)
                    || ByteArray.constantTimeAreEqual(signedHash, contentIEHash)
                    || ByteArray.constantTimeAreEqual(signedHash, content1251Hash)
                    || ByteArray.constantTimeAreEqual(signedHash, contentUTF8Hash)
                    || ByteArray.constantTimeAreEqual(signedHash, content1252Hash)
                    || ByteArray.constantTimeAreEqual(signedHash, contentISO_8859_1Hash)
                    || ByteArray.constantTimeAreEqual(signedHash, contentISO_8859_5Hash);

            if (!equalHashes) {
                throw new VerificationException(VerificationException.NOT_EQUAL_HASHES);
            }
    }
}
