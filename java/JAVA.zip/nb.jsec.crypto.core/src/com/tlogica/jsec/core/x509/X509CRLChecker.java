package com.tlogica.jsec.core.x509;

import java.io.FileInputStream;
import java.security.cert.CRLException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Miroslav Dzhokanov
 */
public class X509CRLChecker {

    /**
     * Checks the certificate revocation status against the passed CRLs
     *
     * @param cert the certificate to be checked for revocation
     * @return true if the certificate is revoked. Otherwise return false
     */
    public static boolean isCertificateRevokedOffline(X509Certificate aCertificate,
            List<X509CRL> crls) {
        for (X509CRL crl : crls) {
            if (crl.isRevoked(aCertificate)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Extracts the CRL distribution points from the certificate (if available)
     * and checks the certificate revocation status against the CRLs coming from
     * the distribution points. Supports HTTP, HTTPS, FTP and LDAP based URLs.
     * @param cert - the certificate to be checked for revocation
     * @throws CRLException if this method is unable to download relevant CRL
     *         for this certificate
     * @return true if the certificate is revoked. Otherwise return false
     */
    public static boolean isCertificateRevokedOnlineCRLCheck(X509Certificate cert) throws CRLException {
        //Online CRL check whether certificate({0}) is revoked.", cert.getSerialNumber());
        X509CRL crl = X509CRLLoader.downloadRelevantCRL(cert);
        if (crl == null) {
            throw new CRLException(" no CRL found ");
        }
        if (crl.isRevoked(cert)) {
            return true;
        }
        //Certificate is not revoked
        return false;
    }

    public static void main(String... a) throws Exception {
        String str = "C:\\WINDOWS\\Profiles\\cstoykov\\Desktop\\delet.me.later\\2023375439.cer";
        CertificateFactory cf = //
                CertificateFactory.getInstance("X.509");
        X509Certificate cert = (X509Certificate) //
                cf.generateCertificate(new FileInputStream(str));
        System.out.println("valid[CRL] = " + X509CRLChecker.isCertificateRevokedOnlineCRLCheck(cert));
    }
}
