package com.tlogica.jsec.core.x509;

import com.tlogica.jsec.utils.base64.Base64;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.GeneralSecurityException;
import java.security.cert.*;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

/**
 * Class that loads CRLs from String, Stream, File, Dir.
 * It works only with ASN1 DER encoded X509CRL.
 * @author Miroslav Dzhokanov
 */
public class X509CRLLoader {

    private static final String X509_TYPE = "X.509";

    /**
     * @param base64CRL 
     * @return X509Certificate
     * @throws GeneralSecurityException
     * @throws IOException
     */
    public static X509CRL loadX509CRLFromB64String(String base64CRL)//
            throws GeneralSecurityException,//
            IOException //
    {
        byte[] crlDecoded = Base64.decode(base64CRL);
        X509CRL crl = loadX509CRLFromStream(new ByteArrayInputStream(crlDecoded));
        return crl;
    }

    /**
     * Loads X.509 CRL from DER-encoded binary file (.CRL file).
     * @param aFileName
     * @return
     * @throws GeneralSecurityException
     * @throws IOException
     */
    public static X509CRL loadX509CRLFromFile(String aFileName) throws GeneralSecurityException,
            IOException {
        InputStream fis = new FileInputStream(aFileName);
        X509CRL crl = null;
        try {
            crl = loadX509CRLFromStream(fis);
        } finally {
            fis.close();
        }
        return crl;
    }

    /**
     * Loads X.509 CRL from DER-encoded binary file (.CRL file).
     * @param aFile
     * @return
     * @throws GeneralSecurityException 
     * @throws IOException
     */
    public static X509CRL loadX509CRLFromFile(File aFile) throws GeneralSecurityException,
            IOException {
        InputStream fis = new FileInputStream(aFile);
        X509CRL crl = null;
        try {
            crl = loadX509CRLFromStream(fis);
        } finally {
            fis.close();
        }
        return crl;
    }

    public static X509CRL loadX509CRLFromStream(InputStream aInStream) throws GeneralSecurityException {
        CertificateFactory cf = CertificateFactory.getInstance(X509_TYPE);
        X509CRL crl = null;
        try {
            crl = (X509CRL) cf.generateCRL(aInStream);

        } catch (GeneralSecurityException e) {
            try {
                aInStream.close();
            } catch (IOException f) {
                Logger.getLogger(X509CRLLoader.class.getName()).log(Level.SEVERE, null, f);
            }
            throw e;
        }
        return crl;
    }

    /**
     * Loads all CRLs from the specified directory
     * @param aDirPath
     * @return List of X509CRL
     * @throws GeneralSecurityException
     * @throws IOException
     */
    public static List<X509CRL> loadAllCRLsFromDir(String aDirPath) throws GeneralSecurityException,
            IOException {
        List<X509CRL> certs = new LinkedList<X509CRL>();
        ExtensionFileFilter filter = new ExtensionFileFilter(new String[]{".CRL"});
        File dir = new File(aDirPath);

        File[] listOfFiles = dir.listFiles();
        for (int i = 0; i < listOfFiles.length; i++) {
            if (listOfFiles[i].isFile() && filter.accept(dir, listOfFiles[i].getName())) {
                X509CRL ca_cert = loadX509CRLFromFile(listOfFiles[i]);
                certs.add(ca_cert);
            } else {
                System.out.println("CERTIFICATE-INFO: Not acceptable certificate file "
                        + listOfFiles[i].getName());
            }
        }
        return certs;
    }

    /**
     * Extracts the CRL distribution points from the certificate and downloads
     * CRLs coming from the distribution points. Supports HTTP, HTTPS, FTP
     * and LDAP based URLs. Returns null if no CRL were found.
     *
     * @param cert the certificate to be checked for revocation
     * @return null if no CRL were found.
     */
    public static X509CRL downloadRelevantCRL(X509Certificate cert) {
        X509CRL crl = null;
        List<String> crlDistPoints = X509Utils.getCrlDistributionPoints(cert);
        for (String crlDP : crlDistPoints) {
            try {
                crl = downloadCRL(crlDP);
            } catch (Exception ex) {
                // не ме интересува що ...
                System.out.printf(" - %s [failed] %s\n", crlDP, ex.getMessage());
            }
            if (crl != null) {
                // намерих нещо
                break;
            }
        }
        return crl;
    }

    /**
     * Downloads CRL from given URL. Supports http, https, ftp and ldap based URLs.
     * @param crlURL 
     * @return
     * @throws IOException
     * @throws CertificateException
     * @throws CRLException
     * @throws NamingException
     * @throws X509Exception 
     */
    public static X509CRL downloadCRL(String crlURL)
            throws Exception {

        // ldap ...
        if (crlURL.matches("^ldap://.*")) {
            return downloadCRLFromLDAP(crlURL);
        } else {
            // ако е пропуснато значи е http://
            if (!crlURL.matches("(^\\w+://).*")) {
                crlURL = "http://" + crlURL;
            }
            // какъвто и да е протокола пробвай му се 
            return downloadCRLFromWeb(crlURL);
        }
    }

    /**
     * Downloads a CRL from given LDAP url, e.g.
     * ldap://ldap.infonotary.com/dc=identity-ca,dc=infonotary,dc=com
     * @param ldapURL
     * @return
     * @throws CertificateException 
     * @throws NamingException
     * @throws CRLException
     * @throws X509Exception
     */
    private static X509CRL downloadCRLFromLDAP(String ldapURL) throws CertificateException,
            NamingException,
            CRLException {
        Hashtable<String, String> env = new Hashtable<String, String>();
        env.put(Context.INITIAL_CONTEXT_FACTORY,
                "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL, ldapURL);

        DirContext ctx = new InitialDirContext(env);
        Attributes avals = ctx.getAttributes("");
        Attribute aval = avals.get("certificateRevocationList;binary");
        byte[] val = (byte[]) aval.get();
        if ((val == null) || (val.length == 0)) {
            throw new CRLException("Can not download CRL from: " + ldapURL);
        } else {
            InputStream inStream = new ByteArrayInputStream(val);
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            X509CRL crl = (X509CRL) cf.generateCRL(inStream);
            return crl;
        }
    }

    /**
     * Downloads a CRL from given HTTP/HTTPS/FTP URL, e.g.
     * http://crl.infonotary.com/crl/identity-ca.crl
     * @param crlURL 
     * @return 
     * @throws MalformedURLException 
     * @throws IOException
     * @throws CertificateException
     * @throws CRLException
     */
    private static X509CRL downloadCRLFromWeb(String crlURL) throws MalformedURLException,
            IOException,
            CertificateException,
            CRLException {
        URL url = new URL(crlURL);
        InputStream crlStream = url.openStream();
        try {
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            X509CRL crl = (X509CRL) cf.generateCRL(crlStream);
            return crl;
        } finally {
            crlStream.close();
        }
    }
}
