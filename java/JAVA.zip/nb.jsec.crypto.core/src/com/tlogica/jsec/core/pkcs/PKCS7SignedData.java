package com.tlogica.jsec.core.pkcs;

import java.io.IOException;
import java.util.Date;
import sun.security.pkcs.PKCS9Attribute;
import sun.security.pkcs.PKCS9Attributes;
import sun.security.pkcs.SignerInfo;
import sun.security.pkcs.SigningCertificateInfo;

/**
 * This class holds digest(hash) of the message that has been signed.
 * Except message the current class holds also the next signed attributes:
 * - oid of digestAlgorithm;
 * - oid of the content type of the message (String, or previously signed data)
 * - the signing time (informal time - wasn't received from a TimeStamp Authority)
 * All the digest of the message and the other signed attributes have been signed
 * by the signer in order to comply with RFC 2315 (PKCS7/CMS)
 *
 * @author Miroslav Dzhokanov
 */
public class PKCS7SignedData {

    private final String contentTypeOID = "1.2.840.113549.1.9.3";
    private final String messageDigestOID = "1.2.840.113549.1.9.4";
    private final String signingTimeOID = "1.2.840.113549.1.9.5";
    private final String signerCertificateOID = "1.2.840.113549.1.9.16.2.12";
    // is the message a simple data(1.2.840.113549.1.7.1), or signed data
    //(1.2.840.113549.1.7.2), or enveloped data (1.2.840.113549.1.7.3) ...
    private String contentTypeId;
    // digest of the message, which was signed along with some attributes
    private byte[] messageDigest;
    // informal time (not received from a TimeStamp Authority)
    private Date signingTime;
    // all the bytes, that have been signed (including the signed attributes)
    private byte[] signedData;
    // syntax version number RFC 2315 - if 1 then crls are allowed
    private int version = -1;
    // Currently unused attribute. In case of signed in PKCS7 format timestamps
    // this field holds information about signer certificate digest
    private SigningCertificateInfo signerCertInfo;

    public PKCS7SignedData(SignerInfo info) throws IOException {
        PKCS9Attribute[] attrs = info.getAuthenticatedAttributes().getAttributes();
        // loop through all signed attributes
        for (PKCS9Attribute attr : attrs) {
            if (attr.getOID().toString().equals(messageDigestOID)) {
                this.messageDigest = (byte[]) attr.getValue();
            } else if (attr.getOID().toString().equals(signingTimeOID)) {
                this.signingTime = (Date) attr.getValue();
            } else if (attr.getOID().toString().equals(contentTypeOID)) {
                // returns OID (i.e 1.2.840.113549.1.7.1)
                this.contentTypeId = attr.getValue().toString();
            } else if (attr.getOID().toString().equals(signerCertificateOID)) {
                if (attr.getValue() != null) {
                    signerCertInfo = (SigningCertificateInfo) attr.getValue();
                }
            } else {
                System.out.println("WARNING: Uncaught signed attribute: " + attr.getOID().toString());
            }
        }
        this.signedData = info.getAuthenticatedAttributes().getDerEncoding();
        PKCS9Attributes attrsBunch = info.getUnauthenticatedAttributes();
        if (attrsBunch != null) {
            attrs = attrsBunch.getAttributes();
            for (PKCS9Attribute attr : attrs) {
                System.out.println("WARNING: Uncaught unsigned attribute: " + attr.getOID().toString());
            }
        }
        version = info.getVersion().intValue();
    }

    /**
     * Returns the digest (hash) of the message, that have been signed along
     * with some attributes.
     * @return digest (hash) of the message, that have been signed
     */
    public byte[] getMessageDigest() {
        return this.messageDigest;
    }

    /**
     * These are the actual bytes, that have been encrypted by the encryption
     * algorithm (RSA, DSA, ...).
     * @return the bytes, that have been signed
     */
    public byte[] getSignedDataBytes() {
        return this.signedData;
    }

    /**
     * Returns the date and time of signing. This time is informal(not received
     * from TimeStamp Authority) and could easily be compromised.
     * @return signing timestamp
     */
    public Date getSigningTime() {
        return this.signingTime;
    }

    /**
     * Returns the Object Identifier of the content type as String.
     * @return OID-formatted contentType (RFC-2315)
     */
    public String getContentTypeId() {
        return contentTypeId;
    }
}
