package main;

import com.tlogica.jsec.parsing.ExtractorType;
import java.io.File;
import java.io.FileOutputStream;
import java.security.KeyStore;
import java.security.cert.X509Certificate;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import sun.security.x509.X509CertImpl;

/** 
 * @author Цанко Ст.( tsani_san@abv.bg )
 */
public class Go {

//    public static void addCertificate(File cert, File jksFile, char[] password) //
//            throws Exception //
//    {
//        System.out.println("-------- " + jksFile);
//        // type
//        KeyStore ks = KeyStore.getInstance("jks");
//        // load
//        ks.load(new java.io.FileInputStream(jksFile), password);
//
//        // what's inside ...
//        Enumeration<String> en = ks.aliases();
//        String a = en.nextElement();
//        for (;;) {
//            X509CertImpl tmp = (X509CertImpl) ks.getCertificate(a);
//            try {
//                tmp.checkValidity(new Date());
//                System.out.printf("alias=%s, serial=%s, dn=%s\n", a, tmp.getSerialNumber().toString(), tmp.getSubjectDN().toString());
//            } catch (Exception e) {
//                System.err.printf("alias=%s, serial=%s\n", a, tmp.getSerialNumber().toString());
//            }
//            if (!en.hasMoreElements()) {
//                break;
//            }
//            a = en.nextElement();
//        }
//    }

    // вади и записва сертификатите ми ...
    public static void createTrustedKeyStore(File jksFile, char[] password) //
            throws Exception //
    {
        // type
        KeyStore ks = KeyStore.getInstance("jks");
        // create
        ks.load(null, password);
        // load
        ExtractorType[] etArr = ExtractorType.values();
        for (int i = 0;i<etArr.length;i++) {
            int index = 0;
            ExtractorType et = etArr[i]; 
            Iterator iter =  et.getIssuers().iterator();
            while (iter.hasNext()) {
                X509Certificate cert = (X509Certificate) iter.next();
                ks.setCertificateEntry(et.toString() + "." + index, cert);
                index++;
            }
            System.out.println("#"+et.toString()+",\t"+index);
        }
        // store
        ks.store(new FileOutputStream(jksFile), password);
    }

    // показва какво имам в KeyStore
    public static void inspectKeyStore(File jksFile, char[] password) //
            throws Exception //
    {
        System.out.println("-------- " + jksFile);
        // type
        KeyStore ks = KeyStore.getInstance("jks");
        // load
        ks.load(new java.io.FileInputStream(jksFile), password);

        // what's inside ...
        Enumeration en = ks.aliases();
        String a = (String) en.nextElement();
        for (;;) {
            X509CertImpl tmp = (X509CertImpl) ks.getCertificate(a);
            try {
                tmp.checkValidity(new Date());
                System.out.println("alias="+a+", serial="+tmp.getSerialNumber().toString());//+", dn="+tmp.getSubjectDN().toString()+"\n");
            } catch (Exception e) {
                System.err.println("alias="+a+", serial="+tmp.getSerialNumber().toString()+"\n");
            }
            if (!en.hasMoreElements()) {
                break;
            }
            a = (String) en.nextElement();
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        // password
        char[] password = new char[]{'1', '2', '3', '4', '5', '6'};
        File jks1 = new File("D:\\cstoykov\\new.trustedcerts.jks");
        File jks2 = new File("D:\\cstoykov\\trustedcerts.jks");
        File jks3 = new File("D:\\cstoykov\\lr_crc_bg.jks");
        File jks4 = new File("D:\\cstoykov\\server.jks");
        File jks5 = new File("D:\\cstoykov\\tmp.server.jks");
        File jks6 = new File("D:\\prj-CROZ\\cer&ks\\tks.jks");

        password = new char[]{'1', '2', '3', '4', '5', '6'};
        //inspectKeyStore(jks1, password);

        password = new char[]{'1', '2', '3', '4', '5', '6'};
        //inspectKeyStore(jks2, password);

        password = new char[]{'l', 'r', 'c', 'r', 'c', 'p', 'a', 's', 's'};
        //inspectKeyStore(jks3, password);

        password = new char[]{'1', '2', '3', '4', '5', '6'};
        //inspectKeyStore(jks4, password);

        password = new char[]{'1', '2', '3', '4', '5', '6'};
        //inspectKeyStore(jks5, password);

        createTrustedKeyStore(jks6,password);
        //inspectKeyStore(jks6, password);

    }
}
