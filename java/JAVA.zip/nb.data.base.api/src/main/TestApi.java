package main;

import com.tlogica.jsec.parsing.InfoExtractor;
import com.tlogica.jsec.parsing.bg.db.DBParser;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.reflect.Method;

/** 
 * @author Цанко Ст.( tsani_san@abv.bg )
 */
public class TestApi {

    public static void main2(String[] a) throws Exception {
        Method[] tmpList = InfoExtractor.class.getMethods();
        for (int i = 0; i < tmpList.length; i++) {
            Method m = tmpList[i];
            if (m.getName().matches("get.*") && !m.getName().matches("getCertificate")) {

                System.out.println(m.getName().replaceAll("^get", ""));

            }
        }
    }

    public static void main(String[] a) throws Exception {
        String[] cers = {
	    null
	    //,"nmehmedov.cer"
	    //,"dd.cer"
	    //,"ee.cer"
	    //,"kk.cer"
	    //,"kk2.cer"
	    //,"some.cer"
	    ,"vg.cer"
	};
        for (int is = 0; is < cers.length; is++) {
            StringBuffer sb = new StringBuffer();
	    if(cers[is]==null) continue;
            Reader r = new InputStreamReader(TestApi.class.getResourceAsStream(cers[is]));
            char[] cb = new char[1024];
            int nred = r.read(cb);
            while (nred > 0) {
                sb.append(cb, 0, nred);
                //следващ
                nred = r.read(cb);
            }
            r.close();
            Method[] tmpList = InfoExtractor.class.getMethods();
            for (int i = 0; i < tmpList.length; i++) {
                Method m = tmpList[i];
                if (m.getName().matches("get.*") && !m.getName().matches("getCertificate")) {
                    try {
                        System.out.println(m.getName().replaceAll("^get", "") + "(...)=" + DBParser.callMethod(m.getName(), sb.toString()));
                    } catch (Exception e) {
			e.printStackTrace();
                        System.out.println(m.getName() + "->ERROR");
			break;
                    }
                }
            }
        }
    }
}
