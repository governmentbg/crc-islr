
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.Writer;
import sun.misc.BASE64Encoder;

/** 
 * @author Цанко Ст.( tsani_san@abv.bg )
 */
public class Helper {

    static final BASE64Encoder encode = new BASE64Encoder();

    public static void processSingle(File f) throws Exception {
        FileInputStream is = new FileInputStream(f);
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        byte[] b = new byte[1024];
        int nred = is.read(b);
        while (nred > 0) {
            os.write(b, 0, nred);
            nred = is.read(b);
        }
        Writer w = new FileWriter(f + ".cer");
        w.write(encode.encode(os.toByteArray()));
        w.flush();
        is.close();
    }

    public static void main(String[]a) throws Exception {
        File dir = new File("C:/Projects/crc_2010/trunc/JAVA/nb.data.base.api/src/certificates/Spektar");

        File[] tmpArr = dir.listFiles();
        for (int i=0;i<tmpArr.length;i++) {
            File f = tmpArr[i];
            processSingle(f);
        }
    }
}
