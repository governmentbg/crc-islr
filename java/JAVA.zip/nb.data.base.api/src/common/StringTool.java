package common;

/**
 * Низови операции
 *
 * Аргументацията да ги събера тук е, че има
 * разлики в java.lang.String в 1.3, 1.4 и 1.5
 * 
 * @author Цанко Ст.( tsani_san@abv.bg )
 */
public class StringTool {

    // действа като едноимената функция от 1.4
    public static String replaceAll(String originalString, String pattern, String repalceString) {
        return originalString.replaceAll(pattern, repalceString);
    }
    // public static void main(String[]a) throws Exception {}
}
