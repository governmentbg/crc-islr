package com.tlogica.jsec.parsing;

import java.security.GeneralSecurityException;

/**
 * This Exception is thrown if ParserFactory class could not retrieve
 * or do not recognize the certificate's issuer company name
 * @author Miroslav Dzhokanov
 */
public class NotRecognizedAuthorityException extends GeneralSecurityException {

    private static String ERR_MESSAGE = "Parsing certificates issued by this Certificate Authority "
            + "is not supported.\n";

    public NotRecognizedAuthorityException(Throwable throwable) {
        super(ERR_MESSAGE);
    }

    public NotRecognizedAuthorityException(String string,
                                           Throwable throwable) {
        super(ERR_MESSAGE);
    }

    public NotRecognizedAuthorityException(String string) {
        super(ERR_MESSAGE);
    }

    public NotRecognizedAuthorityException() {
        super(ERR_MESSAGE);
    }
}
