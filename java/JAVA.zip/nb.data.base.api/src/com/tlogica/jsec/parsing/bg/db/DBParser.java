package com.tlogica.jsec.parsing.bg.db;

import com.tlogica.jsec.parsing.InfoExtractor;
import com.tlogica.jsec.parsing.InfoExtractorFactory;
import java.io.*;
import java.lang.reflect.Method;
import java.security.cert.X509Certificate;
import java.sql.Clob;
import java.sql.SQLException;

/**
 * @author Цанко Ст.( tsani_san@abv.bg )
 */
public class DBParser {

    // като низ
    public static String asString(Clob certClob) {
        try {
            return certClob.getSubString(1, (int) certClob.length());
        } catch (SQLException ex) {
            throw new RuntimeException(" не мога да взема като String от clob=" + certClob, ex);
        }
    }

    // помощна процедура ... clob
    public static InfoExtractor getIInfoExtractor(Clob certClob) {
        return getIInfoExtractor(asString(certClob));
    }

    // помощна процедура ... X509
    public static InfoExtractor getIInfoExtractor(X509Certificate cert) {
        InfoExtractor ex;
        try {
            ex = InfoExtractorFactory.getExtractor(cert);
        } catch (Exception ex1) {
            throw new RuntimeException(" Не успях да разпозная издателя : " + ex1.getMessage(), ex1);
        }
        return ex;
    }

    // помощна процедура ... clob
    public static InfoExtractor getIInfoExtractor(String str) {
        X509Certificate cert;
        try {
            cert = com.tlogica.jsec.core.x509.X509CertLoader.loadX509Certificate(str);
        } catch (Exception ex) {
            throw new RuntimeException(" Не успях да заредя сертификата: " + ex.getMessage(), ex);
        }
        return getIInfoExtractor(cert);
    }

    // помощна процедура ...
    public static String callMethod(String methodName, Clob data) {
        InfoExtractor ie = getIInfoExtractor(data);
        return callMethod(methodName, ie);
    }

    // помощна процедура ...
    public static String callMethod(String methodName, String data) {
        InfoExtractor ie = getIInfoExtractor(data);
        return callMethod(methodName, ie);
    }

    // за да си спестя copy/paste на код използвам reflaction
    public static String callMethod(String methodName, InfoExtractor ie) {
        Method m;
        try {
            m = InfoExtractor.class.getMethod(methodName, new Class[]{});
        } catch (NoSuchMethodException ex) {
            throw new RuntimeException(" IInfoExtractor няма метод " + methodName + "()", ex);
        } catch (SecurityException ex) {
            throw new RuntimeException(" IInfoExtractor има метод " + methodName + "(), но не може да се вика така ", ex);
        }
        Object result;
        try {
            result = m.invoke(ie, new Object[]{});
        } catch (Exception ex) {
            throw new RuntimeException(" грешка при извикването  [" + ie + "]."
                    + methodName + "() ... няма достъп/грешни аргументи/невалидна референция ", ex);
        }
        return result == null ? null : result.toString();
    }

    // дали не изтекъл срока на употреба към днешна дата
    public static String hasExpired(Clob data) {
        InfoExtractor ie = getIInfoExtractor(data);
        X509Certificate cert = ie.getCertificate();
        return System.currentTimeMillis() > cert.getNotAfter().getTime() ? "Y" : "N";
    }

    // дали е активиран към днешна дата
    public static String isActivated(Clob data) {
        InfoExtractor ie = getIInfoExtractor(data);
        X509Certificate cert = ie.getCertificate();
        return System.currentTimeMillis() > cert.getNotBefore().getTime() ? "Y" : "N";
    }

    public static String convertStreamToString(InputStream is, String encoding)//
            throws Exception //
    {
        /*
         * To convert the InputStream to String we use the
         * Reader.read(char[] buffer) method. We iterate until the
         * Reader return -1 which means there's no more data to
         * read. We use the StringWriter class to produce the string.
         */
        if (is != null) {
            Writer writer = new StringWriter();

            char[] buffer = new char[1024];
            try {
                Reader reader = new BufferedReader(
                        new InputStreamReader(is, encoding));
                int n;
                while ((n = reader.read(buffer)) != -1) {
                    writer.write(buffer, 0, n);
                }
            } finally {
                is.close();
            }
            return writer.toString();
        } else {
            return "";
        }
    }
}
