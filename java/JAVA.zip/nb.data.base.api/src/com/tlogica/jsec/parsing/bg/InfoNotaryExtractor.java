package com.tlogica.jsec.parsing.bg;

import com.tlogica.jsec.parsing.CertificateType;
import com.tlogica.jsec.parsing.InfoExtractor;

import com.tlogica.jsec.parsing.NotParseableCertificateException;

import com.tlogica.jsec.parsing.ParsingUtils;

import java.math.BigInteger;

import java.security.cert.X509Certificate;
import java.util.Collection;
import java.util.List;

/**
 * InfoNotary Certificates Parser
 * http://repository.infonotary.com/certpolicy_qsign-company.html
 * ---------
 * This class extracts information from ordinary InfoNotary certificate,
 * taking account of its specific structure
 * @author Miroslav Dzhokanov
 */
public class InfoNotaryExtractor implements InfoExtractor {

    private final String ISSUER_NAME = "InfoNotary";
    private final String[] SEPARATORS = {",", "\"", "=", "+"};
    //we need to set two backslashes in front of "\\+" separator
    //for the needs of the String.split() method, which throws Exception if "+"
    //comes without backslashes
    private final String TAG_SEPARATOR = "+";
    private X509Certificate mCert;
    private CertificateType mCertificateType;
    private String mCertificateUniqueId;
    private String mSerialNumber;
    private String mPersonId;
    private String mPersonMail;
    private String mPersonFullName;
    private String mPersonFirstName;
    private String mPersonLastName;
    private String mPersonLocation;
    private String mPersonPhoneNumber;
    private String mPersonAddress;
    private String mCompanyId;
    private String mCompanyName;
    private String mCompanyAddress;
    private String mTechnicalCertificateName;
    private String mIssuerCNName;
    private String mIssuerPhoneNumber;
    private String mIssuerMail;
    private String mIssuerAddress;
    private String mIssuerCompanyId;
    private String mIssuerLocation;

    private InfoNotaryExtractor() {
    }

    public InfoNotaryExtractor(X509Certificate aCert) throws NotParseableCertificateException {
        mCert = aCert;
        loadCertInfo();
    }

    public X509Certificate getCertificate() {
        return mCert;
    }

    public String getSerialNumber() {
        return mSerialNumber;
    }

    public String getCertificateUniqueId() {
        return this.mCertificateUniqueId;
    }

    public CertificateType getCertificateType() {
        return this.mCertificateType;
    }

    public String getPersonId() {
        return this.mPersonId;
    }

    public String getPersonMail() {
        return this.mPersonMail;
    }

    public String getPersonFullName() {
        return this.mPersonFullName;
    }

    public String getPersonFirstName() {
        return this.mPersonFirstName;
    }

    public String getPersonLastName() {
        return this.mPersonLastName;
    }

    public String getPersonLocation() {
        return this.mPersonLocation;
    }

    public String getPersonPhoneNumber() {
        return mPersonPhoneNumber;
    }

    public String getPersonAddress() {
        return mPersonAddress;
    }

    public String getCompanyId() {
        return this.mCompanyId;
    }

    public String getCompanyName() {
        return this.mCompanyName;
    }

    public String getCompanyAddress() {
        return this.mCompanyAddress;
    }

    public String getTechnicalCertificateName() {
        return this.mTechnicalCertificateName;
    }

    public String getIssuerName() {
        return ISSUER_NAME;
    }

    public String getIssuerCertificateName() {
        return mIssuerCNName;
    }

    public String getIssuerPhoneNumber() {
        return this.mIssuerPhoneNumber;
    }

    public String getIssuerMail() {
        return this.mIssuerMail;
    }

    public String getIssuerAddress() {
        return this.mIssuerAddress;
    }

    public String getIssuerCompanyId() {
        return this.mIssuerCompanyId;
    }

    public String getIssuerLocation() {
        return this.mIssuerLocation;
    }

    /**
     * Main loading method
     *
     */
    private void loadCertInfo() throws NotParseableCertificateException {
        // Extract Issuer information
        String issuerInfo = mCert.getIssuerDN().getName();
        setIssuerCertificateName(issuerInfo);
        setIssuerPhoneNumber(issuerInfo);
        setIssuerMail(issuerInfo);
        setIssuerAddress(issuerInfo);
        setIssuerCompanyId(issuerInfo);

        // Extract general certificate information
        setSerialNumber();
        setCertificateUniqueId();

        String subjectInfo = mCert.getSubjectDN().getName();
        String subjectInfoAlt = "";
        try {
            Collection subjAltNames = mCert.getSubjectAlternativeNames();
            if (subjAltNames != null) {
                List tmpList = (List) subjAltNames.iterator().next();
                subjectInfoAlt = tmpList.get(1).toString();
            }
        } catch (Exception e) {
            // Could not retrieve InfoNotary SubjectAlternativeNames.
        }

        // Extract titul (personal) information
        setPersonId(subjectInfo);
        if (mCompanyAddress == null) {
            setPersonId(subjectInfoAlt);
        }
        setPersonMail(subjectInfo);
        setPersonFullName(subjectInfo);
        setPersonPhoneNumber(subjectInfoAlt);
        setPersonAddress(subjectInfo);
        setPersonAddress(subjectInfoAlt);
        setPersonLocation(subjectInfoAlt);
        mPersonFirstName = ParsingUtils.getFirstName(mPersonFullName);
        mPersonLastName = ParsingUtils.getLastName(mPersonFullName);

        // depends on assumption that person Id is already set
        setCertificateType(subjectInfo);

        if (mCertificateType.equals(CertificateType.Professional)) {
            // Extract Company information
            setCompanyId(subjectInfoAlt);
            if (mCompanyId == null) {
                setCompanyId(subjectInfo);
            }
            if (mCompanyId != null) {
                setCompanyName(subjectInfo);
                setCompanyAddress(subjectInfo);
            }
        }
    }

    private void setCertificateType(String subjectInfo) {
        int idx = subjectInfo.indexOf("DC=");
        String certType = null;
        if (idx >= 0) {
            String piece = (subjectInfo.substring(idx + 3));
            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);

            piece = ParsingUtils.trimString(piece);
            int firstSeparator = ParsingUtils.getFirstSeparator(piece, SEPARATORS);
            certType = piece.substring(0, firstSeparator);
        }

        if (certType != null && certType.indexOf("company")>-1) {
            mCertificateType = CertificateType.Professional;
        } else if (certType != null && certType.indexOf("personal")>-1) {
            mCertificateType = CertificateType.Personal;
        } else if (getPersonId() != null) {
            mCertificateType = CertificateType.Personal;
        } else {
            mCertificateType = CertificateType.Technical;
            initTechnicalCertificate(subjectInfo);
        }
    }

    private void initTechnicalCertificate(String subjectInfo) {
        int idx = subjectInfo.indexOf("CN=");
        if (idx >= 0) {
            String piece = (subjectInfo.substring(idx + 3));
            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);
            piece = ParsingUtils.trimString(piece);
            int firstSeparator = ParsingUtils.getFirstSeparator(piece, SEPARATORS);
            mTechnicalCertificateName = piece.substring(0, firstSeparator);
        } else {
            mTechnicalCertificateName = null;
        }
        // flush personal fields. Technical certificates are not personalized.
        mPersonId = null;
        mPersonAddress = null;
        mPersonFirstName = null;
        mPersonFullName = null;
        mPersonLastName = null;
        mPersonLocation = null;
        mPersonMail = null;
        mPersonPhoneNumber = null;
    }

    private void setCompanyId(String subjectInfo) {
//        //SEARCH FOR BULSTAT FIELD
//        int startIdx = subjectInfo.indexOf("2.5.4.10.100.1.2=");
//        //SEARCH FOR TAXATION ID FIELD
//        if (startIdx <= 0) {
        int startIdx = subjectInfo.indexOf("2.5.4.10.100.1.1="); // EGN or BULSTAT
//      }
        if (startIdx > 0) {
            // shift cursor on the value
            startIdx += 17;
            String id = (subjectInfo.substring(startIdx)).split("\\+")[0];
            mCompanyId = ParsingUtils.trimString(id);
        }
    }

    private void setCompanyName(String subjectInfo) {
        int idx = subjectInfo.indexOf("O=");

        if (idx >= 0) {
            String piece = (subjectInfo.substring(idx + 2));
            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);

            piece = ParsingUtils.trimString(piece);
            int firstSeparator = ParsingUtils.getFirstSeparator(piece, SEPARATORS);
            mCompanyName = piece.substring(0, firstSeparator);
        } else {
            mCompanyName = null;
        }
    }

    private void setCompanyAddress(String subjectInfo) {
        int startIdx = subjectInfo.indexOf("1.2.840.113549.1.9.8=#");
        if (startIdx > 0) {
            String address = (subjectInfo.substring(startIdx + 22 + 4)).split("\\+")[0];
            BigInteger hexFormat = new BigInteger(address, 16);
            mCompanyAddress = new String(hexFormat.toByteArray());
        } else {
            startIdx = subjectInfo.indexOf("1.2.840.113549.1.9.8=");
            if (startIdx > 0) {
                // 22 shift to the value itself
                String address = (subjectInfo.substring(startIdx + 22)).split("\\+")[0];
                mCompanyAddress = ParsingUtils.trimString(address);
            }
        }
//
//        int idx = subjectInfo.indexOf("1.2.840.113549.1.9.8=");
//
//        if (idx >= 0) {
//            String piece = (subjectInfo.substring(idx + 21));
//            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);
//
//            piece = ParsingUtils.trimString(piece);
//            int firstSeparator = ParsingUtils.getFirstSeparator(piece, SEPARATORS);
//            mCompanyAddress = piece.substring(0, firstSeparator);
//        } else {
//            mCompanyAddress = null;
//        }
    }

    private void setPersonId(String subjectInfo) {
        if (subjectInfo.indexOf("2.5.4.3.100.1.1=#") > -1) {
            int startIdx = subjectInfo.indexOf("2.5.4.3.100.1.1=#") + 17 + 4;
            String EGN = (subjectInfo.substring(startIdx)).split("\\+")[0];
            BigInteger hexFormat = new BigInteger(EGN, 16);
            mPersonId = new String(hexFormat.toByteArray());
        } else if (subjectInfo.indexOf("2.5.4.10.100.1.1=") > -1) {
            int startIdx = subjectInfo.indexOf("2.5.4.10.100.1.1=") + 17;
            String piece = subjectInfo.substring(startIdx);
            int firstSeparator = ParsingUtils.getFirstSeparator(piece, SEPARATORS);
            String EGN = piece.substring(0, firstSeparator);
            EGN = ParsingUtils.trimString(EGN);
            mPersonId = EGN;
        }
    }

    private void setPersonMail(String subjectInfo) {
        int idx = subjectInfo.indexOf("EMAILADDRESS=");
        if (idx >= 0) {
            String piece = (subjectInfo.substring(idx + 13));
            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);
            piece = ParsingUtils.trimString(piece);
            int firstSeparator = ParsingUtils.getFirstSeparator(piece, SEPARATORS);
            piece = piece.substring(0, firstSeparator);
            mPersonMail = ParsingUtils.trimString(piece);
        } else {
            mPersonMail = ParsingUtils.getWildCardMail(subjectInfo, TAG_SEPARATOR,
                    SEPARATORS);
        }
    }

    private void setPersonFullName(String subjectInfo) {
        int idx = subjectInfo.indexOf("CN=");
        if (idx >= 0) {
            String piece = (subjectInfo.substring(idx + 3));
            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);

            int firstSeparator = ParsingUtils.getFirstSeparator(piece, SEPARATORS);
            piece = piece.substring(0, firstSeparator);
            mPersonFullName = ParsingUtils.trimString(piece);
        } else {
            mPersonFullName = null;
        }
    }

    private void setPersonPhoneNumber(String subjectInfo) {
        if (subjectInfo.indexOf("2.5.4.20=#") > -1) {
            int startIdx = subjectInfo.indexOf("2.5.4.20=#") + 10 + 4;
            String phoneNum =
                    (subjectInfo.substring(startIdx)).split("\\+")[0];
            BigInteger hexFormat = new BigInteger(phoneNum, 16);
            mPersonPhoneNumber = new String(hexFormat.toByteArray());
        } else {
            // No Phone
            mPersonPhoneNumber = null;
        }
    }

    private void setPersonAddress(String subjectInfo) {
        int startIdx = subjectInfo.indexOf("1.2.840.113549.1.9.8=#");
        if (startIdx > 0) {
            // shift cursor on the address value
            startIdx += 22 + 4; // hex value starts with 4 meta characters
            String personAddress =
                    (subjectInfo.substring(startIdx)).split("\\+")[0];
            BigInteger hexFormat = new BigInteger(personAddress, 16);
            mPersonAddress = new String(hexFormat.toByteArray());
        } else {
            startIdx = subjectInfo.indexOf("1.2.840.113549.1.9.8=");
            if (startIdx > 0) {
                startIdx += 21; // shift cursor on the address value
                String piece = subjectInfo.substring(startIdx);
                piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);
                mPersonAddress = ParsingUtils.trimString(piece);
            }
        }
    }

    private void setPersonLocation(String subjectInfo) {
        int startIdx = subjectInfo.indexOf("ST=");
        if (startIdx > 0) {
            // shift cursor on the address value
            startIdx += 3;
            String piece = subjectInfo.substring(startIdx);
            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);
            mPersonLocation = ParsingUtils.trimString(piece);
        }
    }

    private void setSerialNumber() {
        mSerialNumber = mCert.getSerialNumber().toString(16).toUpperCase();
    }

    private void setCertificateUniqueId() throws NotParseableCertificateException {
        mCertificateUniqueId = ParsingUtils.createUniqueId(this);
    }

    private void setIssuerCertificateName(String issuerInfo) {
        int idx = issuerInfo.indexOf("CN=");
        if (idx >= 0) {
            String piece = (issuerInfo.substring(idx + 3));
            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);

            mIssuerCNName = ParsingUtils.trimString(piece);
        } else {
            mIssuerCNName = null;
        }
    }

    private void setIssuerPhoneNumber(String issuerInfo) {
        this.mIssuerPhoneNumber = null;
    }

    private void setIssuerMail(String issuerInfo) {
        this.mIssuerMail = null;
    }

    private void setIssuerAddress(String issuerInfo) {
        this.mIssuerAddress = null;
    }

    private void setIssuerCompanyId(String issuerInfo) {
        this.mIssuerCompanyId = null;
    }
}
