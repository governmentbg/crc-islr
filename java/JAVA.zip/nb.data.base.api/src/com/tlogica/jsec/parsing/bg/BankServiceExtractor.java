package com.tlogica.jsec.parsing.bg;

import com.tlogica.jsec.parsing.CertificateType;
import com.tlogica.jsec.parsing.InfoExtractor;

import com.tlogica.jsec.parsing.NotParseableCertificateException;

import com.tlogica.jsec.parsing.ParsingUtils;



import java.security.cert.X509Certificate;
import java.util.logging.Logger;

/**
 * BankService (B-Trust) Certificates Parser
 * ---------
 * This class extracts information from ordinary BankService certificate,
 * taking account of its specific structure
 * @author Miroslav Dzhokanov
 */
public class BankServiceExtractor implements InfoExtractor {

    private final String ISSUER_NAME = "Bank Service";
    private final String[] SEPARATORS = {",", "\"", "=", "+"};
    private final String TAG_SEPARATOR = ",";
    private X509Certificate mCert;
    private CertificateType mCertificateType;
    private String mCertificateUniqueId;
    private String mSerialNumber;
    private String mPersonId;
    private String mPersonMail;
    private String mPersonFullName;
    private String mPersonFirstName;
    private String mPersonLastName;
    private String mPersonLocation;
    private String mPersonPhoneNumber;
    private String mPersonAddress;
    private String mCompanyId;
    private String mCompanyName;
    private String mCompanyAddress;
    private String mTechnicalCertificateName;
    private String mIssuerCNName;
    private String mIssuerPhoneNumber;
    private String mIssuerMail;
    private String mIssuerAddress;
    private String mIssuerCompanyId;
    private String mIssuerLocation;

    private BankServiceExtractor() {
    }

    public BankServiceExtractor(X509Certificate aCert) //
            throws NotParseableCertificateException //
    {
        mCert = aCert;
        loadCertInfo();
    }

    public X509Certificate getCertificate() {
        return mCert;
    }

    public String getSerialNumber() {
        return mSerialNumber;
    }

    public String getCertificateUniqueId() {
        return this.mCertificateUniqueId;
    }

    public CertificateType getCertificateType() {
        return this.mCertificateType;
    }

    public String getPersonId() {
        return this.mPersonId;
    }

    public String getPersonMail() {
        return this.mPersonMail;
    }

    public String getPersonFullName() {
        return this.mPersonFullName;
    }

    public String getPersonFirstName() {
        return this.mPersonFirstName;
    }

    public String getPersonLastName() {
        return this.mPersonLastName;
    }

    public String getPersonLocation() {
        return this.mPersonLocation;
    }

    public String getPersonPhoneNumber() {
        return mPersonPhoneNumber;
    }

    public String getPersonAddress() {
        return mPersonAddress;
    }

    public String getCompanyId() {
        return this.mCompanyId;
    }

    public String getCompanyName() {
        return this.mCompanyName;
    }

    public String getCompanyAddress() {
        return this.mCompanyAddress;
    }

    public String getTechnicalCertificateName() {
        return this.mTechnicalCertificateName;
    }

    public String getIssuerName() {
        return ISSUER_NAME;
    }

    public String getIssuerCertificateName() {
        return mIssuerCNName;
    }

    public String getIssuerPhoneNumber() {
        return this.mIssuerPhoneNumber;
    }

    public String getIssuerMail() {
        return this.mIssuerMail;
    }

    public String getIssuerAddress() {
        return this.mIssuerAddress;
    }

    public String getIssuerCompanyId() {
        return this.mIssuerCompanyId;
    }

    public String getIssuerLocation() {
        return this.mIssuerLocation;
    }

    /**
     * Main loading method
     *
     */
    private void loadCertInfo() throws NotParseableCertificateException {
        Logger.getLogger(this.getClass().getName()).fine("Start Loading from Bank Service certificate");
        String subjectInfo = mCert.getSubjectDN().getName();

        setSerialNumber();
        setCertificateUniqueId();
        setPersonId(subjectInfo);
        setPersonMail(subjectInfo);
        setPersonFullName(subjectInfo);
        mPersonFirstName = ParsingUtils.getFirstName(mPersonFullName);
        mPersonLastName = ParsingUtils.getLastName(mPersonFullName);
        setPersonPhoneNumber(subjectInfo);
        setPersonAddress(subjectInfo);
        setPersonLocation(subjectInfo);

        // depends on assumption that person Id is already set
        setCertificateType(subjectInfo);
        if (CertificateType.Professional.equals(mCertificateType)) {
            setCompanyId(subjectInfo);
            setCompanyName(subjectInfo);
            setCompanyAddress(subjectInfo);
        }

        String issuerInfo = mCert.getIssuerDN().getName();
        setIssuerCertificateName(issuerInfo);
        setIssuerPhoneNumber(issuerInfo);
        setIssuerMail(issuerInfo);
        setIssuerAddress(issuerInfo);
        setIssuerCompanyId(issuerInfo);
        setIssuerLocation(issuerInfo);
    }

    private void setCertificateType(String subjectInfo) {
        boolean isPersonal = subjectInfo.indexOf("Personal Certificate")>-1;
        boolean isProfessional = subjectInfo.indexOf("Professional Certificate")>-1;

        if (isPersonal) {
            mCertificateType = CertificateType.Personal;
        } else if (isProfessional) {
            mCertificateType = CertificateType.Professional;
        } else {
            if (subjectInfo.indexOf("BULSTAT")>-1) {
                mCertificateType = CertificateType.Professional;
            } else if (getPersonId() != null) {
                mCertificateType = CertificateType.Personal;
            } else {
                // No BULSTAT, nor EGN/PID/SID was found
                mCertificateType = CertificateType.Technical;
                initTechnicalCertificate(subjectInfo);
            }
        }
    }

    private void initTechnicalCertificate(String subjectInfo) {
        int idx = subjectInfo.indexOf("CN=");
        if (idx >= 0) {
            String piece = (subjectInfo.substring(idx + 3));
            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);
            piece = ParsingUtils.trimString(piece);
            int firstSeparator = ParsingUtils.getFirstSeparator(piece, SEPARATORS);
            mTechnicalCertificateName = piece.substring(0, firstSeparator);
        } else {
            mTechnicalCertificateName = null;
        }
        // flush personal fields. Technical certificates are not personalized.
        mPersonId = null;
        mPersonAddress = null;
        mPersonFirstName = null;
        mPersonFullName = null;
        mPersonLastName = null;
        mPersonLocation = null;
        mPersonMail = null;
        mPersonPhoneNumber = null;
    }

    private void setCompanyId(String subjectInfo) {
        int idx = subjectInfo.indexOf("BULSTAT:");
        if (idx >= 0) {
            String piece = (subjectInfo.substring(idx + 8));
            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);
            piece = ParsingUtils.trimString(piece);
            int firstSeparator = ParsingUtils.getFirstSeparator(piece, SEPARATORS);
            mCompanyId = piece.substring(0, firstSeparator);
        } else {
            idx = subjectInfo.indexOf("OU="); //CompanyInfo Tag

            if (idx >= 0) {
                String piece = (subjectInfo.substring(idx + 3));
                piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);
                if (!(piece.indexOf("EGN")>-1)) {
                    int idx2 = piece.indexOf(":");
                    if (idx2 > 0) {
                        piece = piece.substring(idx2 + 1);
                        piece = ParsingUtils.trimString(piece);
                        int firstSeparator = ParsingUtils.getFirstSeparator(piece, SEPARATORS);
                        mCompanyId = piece.substring(0, firstSeparator);
                    } else {
                        //inner tag for CompanyID not found
                        mCompanyId = null;
                    }
                }
            } else {
                //outer tag for CompanyInfo not found
                mCompanyId = null;
            }
        }
    }

    private void setCompanyName(String subjectInfo) {
        int idx = subjectInfo.indexOf("O=");

        if (idx >= 0) {
            String piece = (subjectInfo.substring(idx + 2));
            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);
            piece = ParsingUtils.trimString(piece);
            int firstSeparator = ParsingUtils.getFirstSeparator(piece, SEPARATORS);
            mCompanyName = piece.substring(0, firstSeparator);
        } else {
            mCompanyName = null;
        }
    }

    private void setCompanyAddress(String subjectInfo) {
        int idx = subjectInfo.indexOf("STREET=");

        if (idx >= 0) {
            String piece = (subjectInfo.substring(idx + 7));

            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);
            mCompanyAddress = ParsingUtils.trimString(piece);
        } else {
            mCompanyAddress = null;
        }
    }

    private void setPersonId(String subjectInfo) {
        int idx = subjectInfo.indexOf("EGN:");

        if (idx >= 0) {
            String piece = (subjectInfo.substring(idx + 4));
            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);
            piece = ParsingUtils.trimString(piece);
            int firstSeparator = ParsingUtils.getFirstSeparator(piece, SEPARATORS);
            mPersonId = piece.substring(0, firstSeparator);
        } else {
            idx = subjectInfo.indexOf("PID:");
            if (idx >= 0) {
                String piece = (subjectInfo.substring(idx + 4));
                piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);
                piece = ParsingUtils.trimString(piece);
                int firstSeparator = ParsingUtils.getFirstSeparator(piece, SEPARATORS);
                mPersonId = piece.substring(0, firstSeparator);
            } else {
                mPersonId = null;
            }
        }
    }

    private void setPersonMail(String subjectInfo) {
        int idx = subjectInfo.indexOf("EMAILADDRESS=");
        if (idx >= 0) {
            String piece = (subjectInfo.substring(idx + 13));
            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);
            piece = ParsingUtils.trimString(piece);
            int firstSeparator = ParsingUtils.getFirstSeparator(piece, SEPARATORS);
            mPersonMail = piece.substring(0, firstSeparator);
        } else {
            mPersonMail = ParsingUtils.getWildCardMail(subjectInfo, TAG_SEPARATOR,
                    SEPARATORS);
        }
    }

    private void setPersonFullName(String subjectInfo) {
        int idx = subjectInfo.indexOf("CN=");
        if (idx >= 0) {
            String piece = (subjectInfo.substring(idx + 3));
            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);
            piece = ParsingUtils.trimString(piece);
            int firstSeparator = ParsingUtils.getFirstSeparator(piece, SEPARATORS);
            mPersonFullName = piece.substring(0, firstSeparator);
        } else {
            mPersonFullName = null;
        }
    }

    private void setPersonPhoneNumber(String subjectInfo) {
        int idx = subjectInfo.indexOf("2.5.4.20=");
        if (idx >= 0) {
            String piece = (subjectInfo.substring(idx + 9));
            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);
            mPersonPhoneNumber = piece;
        } else {
            mPersonPhoneNumber = null;
        }
    }

    private void setPersonAddress(String subjectInfo) {
        int idx = subjectInfo.indexOf("ST=");
        if (idx >= 0) {
            String piece = (subjectInfo.substring(idx + 3));
            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);
            //piece = ParsingUtils.trimString(piece);
            int firstSeparatorIdx =
                    ParsingUtils.getFirstSeparator(piece, new String[]{"PID", "EIK", "EGN"});
            if (firstSeparatorIdx > 0) {
                piece = piece.substring(0, firstSeparatorIdx);
                piece = ParsingUtils.trimString(piece);
            } else {
                piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);
            }

            mPersonAddress = piece;
        }
    }

    private void setPersonLocation(String subjectInfo) {
        int idx = subjectInfo.indexOf("L=");
        if (idx >= 0) {
            String piece = (subjectInfo.substring(idx + 2));
            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);

            piece = ParsingUtils.trimString(piece);
            int firstSeparator = ParsingUtils.getFirstSeparator(piece, SEPARATORS);
            mPersonLocation = piece.substring(0, firstSeparator);
        } else {
            mPersonLocation = null;
        }
    }

    private void setCertificateUniqueId() throws NotParseableCertificateException {
        mCertificateUniqueId = ParsingUtils.createUniqueId(this);
    }

    private void setSerialNumber() {
        mSerialNumber = mCert.getSerialNumber().toString(16).toUpperCase();
    }

    private void setIssuerCertificateName(String issuerInfo) {
        int idx = issuerInfo.indexOf("CN=");
        if (idx >= 0) {
            String piece = (issuerInfo.substring(idx + 3));
            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);

            piece = ParsingUtils.trimString(piece);
            int firstSeparator = ParsingUtils.getFirstSeparator(piece, SEPARATORS);
            mIssuerCNName = piece.substring(0, firstSeparator);
        } else {
            mIssuerCNName = null;
        }
    }

    private void setIssuerPhoneNumber(String issuerInfo) {
        int idx = issuerInfo.indexOf("OID.2.5.4.20=");
        if (idx >= 0) {
            String piece = (issuerInfo.substring(idx + 13));
            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);

            piece = ParsingUtils.trimString(piece);
            int firstSeparator = ParsingUtils.getFirstSeparator(piece, SEPARATORS);
            mIssuerPhoneNumber = piece.substring(0, firstSeparator);
        } else {
            mIssuerPhoneNumber = null;
        }
    }

    private void setIssuerMail(String issuerInfo) {
        int idx = issuerInfo.indexOf("EMAILADDRESS=");
        if (idx >= 0) {
            String piece = (issuerInfo.substring(idx + 13));
            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);

            piece = ParsingUtils.trimString(piece);
            int firstSeparator = ParsingUtils.getFirstSeparator(piece, SEPARATORS);
            mIssuerMail = piece.substring(0, firstSeparator);
        } else {
            mIssuerMail = null;
        }
    }

    private void setIssuerAddress(String issuerInfo) {
        int idx = issuerInfo.indexOf("STREET=");
        if (idx >= 0) {
            String piece = (issuerInfo.substring(idx + 7));
            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);

            mIssuerAddress = ParsingUtils.trimString(piece);
        } else {
            mIssuerAddress = null;
        }
    }

    private void setIssuerCompanyId(String issuerInfo) {
        int idx = issuerInfo.indexOf("BULSTAT U ");
        if (idx >= 0) {
            String piece = (issuerInfo.substring(idx + 10));
            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);

            piece = ParsingUtils.trimString(piece);
            int firstSeparator = ParsingUtils.getFirstSeparator(piece, SEPARATORS);
            mIssuerCompanyId = piece.substring(0, firstSeparator);
        } else {
            mIssuerCompanyId = null;
        }
    }

    private void setIssuerLocation(String issuerInfo) {
        int idx = issuerInfo.indexOf("L=");
        if (idx >= 0) {
            String piece = (issuerInfo.substring(idx + 2));
            piece = ParsingUtils.clearAllNextTags(piece, TAG_SEPARATOR);

            piece = ParsingUtils.trimString(piece);
            int firstSeparator = ParsingUtils.getFirstSeparator(piece, SEPARATORS);
            mIssuerLocation = piece.substring(0, firstSeparator);
        } else {
            mIssuerLocation = null;
        }
    }
}
