package com.tlogica.jsec.parsing;

import java.io.IOException;
import java.math.BigInteger;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;

/**
 * This class provides support functionality, related to certificate parsing process.
 * @author Miroslav Dzhokanov
 */
public class ParsingUtils {

    /**
     * @param text in this string we look for a separators
     * @param separators array with separators we are interested in
     * @return the index of the passed string, where is the first met separator
     */
    public static int getFirstSeparator(String text, String[] separators) {
        int minIdx = text.length();

        for (int i = 0; i < separators.length; i++) {
            int separatorIdx = text.indexOf(separators[i]);
            if (separatorIdx > 0) {
                minIdx = separatorIdx < minIdx ? separatorIdx : minIdx;
            }
        }

        return minIdx;
    }

    /**
     * This method recieves text, which contains many X509 tags (i.e "CN", "OU",
     * "ST" ...). Its purpose is to return the text which is before the first
     * met tag
     * @param aText the string which is going to be manipulated
     * @param aTagSeparator char or string, which serves as separator between
     * any two tags (i.e " "-whitespace, "+"-plus or ","-comma)
     * @return
     */
    public static String clearAllNextTags(String aText, String aTagSeparator) {
        // SPECIFIC CASE: when the TagSeparator is used for internal delimiter too:
        // OU="Name=Technologica EIK=124335" CN="..."
        // whitespace is tagSeparator and internal delimiter within a single tag
        // at the same time
        if (aText.charAt(0) == '"') {
            aText = aText.substring(1, aText.length() - 1);
            int idx = aText.indexOf("\"");
            if (idx > -1) {
                aText = aText.substring(0, idx);
            }
        } else {
//            // Clearing next OID tags
//            int idx = aText.indexOf("OID");
//            if (idx > 0) {
//                aText = aText.substring(0, idx);
//            }
//            System.out.println("aText -> " + aText);
//            idx = aText.indexOf(ParsingConfigurator.ATTR_VALUE_SEPARATOR); //finds next tag
//            System.out.println("idx -> " + idx);
//            if (idx > 0) {
//                String firstPiece = aText.substring(0, idx);
//                //search for specific separator
//                int idxSep = firstPiece.lastIndexOf(aTagSeparator);
//                if (idxSep > 0) {
//                    aText = firstPiece.substring(0, idxSep);
//                } else {
//                    aText = firstPiece.substring(0, firstPiece.length() - 1);
//                }
//            }
            int idx = aText.indexOf(aTagSeparator);
            if (idx > 0) {
                aText = aText.substring(0, idx);
            }
        }
        return aText;
    }

    /**
     * Searches for @ sign and find the start and end point of the mail.
     * This method is supposed to be part of a whole CertificateWildCard class
     *
     * @param subjectInfo string which is examined in looking for a mail address
     * @param aTagSeparator tag separator for the specific certificate
     * @param aSeparators additional array of separators and inner delimiters
     * @return the extracted mail, if such is available in the certificate.
     * Otherwise returns null.
     */
    public static String getWildCardMail(String subjectInfo,
            String aTagSeparator,
            String[] aSeparators) {
        String mail = null;

        // Merge all separators in single array
        String[] allSeparators = new String[aSeparators.length + 1];
        int allSepLength = allSeparators.length;
        for (int i = 0; i < allSepLength; i++) {
            if (i == allSepLength - 1) {
                allSeparators[i] = aTagSeparator;
            } else {
                allSeparators[i] = aSeparators[i];
            }
        }

        // Search for mail sign
        int idx = subjectInfo.indexOf("@");

        if (idx >= 0) {
            // Search for the start of the mail name
            String piece = (subjectInfo.substring(0, idx));
            int startIdx = idx;
            char currentChar = piece.charAt(startIdx - 1);
            while (startIdx > 0 && isNotSeparator(currentChar, allSeparators)) {
                startIdx--;
                currentChar = piece.charAt(startIdx - 1);
            }
            String firstPart = piece.substring(startIdx);


            int endIdx = 0;
            piece = subjectInfo.substring(idx + 1);
            piece = clearAllNextTags(piece, aTagSeparator);
            currentChar = piece.charAt(endIdx);
            while (endIdx < piece.length() && isNotSeparator(currentChar, allSeparators)) {
                endIdx++;
            }
            String secondPart = piece.substring(0, endIdx);

            mail = firstPart + "@" + secondPart;

            mail = trimString(mail);
        }

        return mail;
    }

    /**
     * This method determines whether a specific char appears in a passed
     * array of separators.
     * @param currentChar the char which is being checked
     * @param aSeparators list of separators
     * @return status of the passed char
     */
    static boolean isNotSeparator(char currentChar,
            String[] aSeparators) {
        boolean flag = true;

        for (int i = 0; i < aSeparators.length; i++) {
            if (Character.toString(currentChar).equals(aSeparators[i])) {
                flag = false;
                break;
            }
        }

        return flag;
    }

    /**
     * Returns the first word from the input sentence
     * @param aFullName
     * @return First name
     */
    public static String getFirstName(String aFullName) {
        if (aFullName != null) {
            int idx = aFullName.indexOf(" ");
            if (idx > 0) {
                String firstName = aFullName.substring(0, idx);
                return firstName;
            } else {
                return "";
            }
        } else {
            return null;
        }
    }

    /**
     * Returns the last word from the input sentence if there are
     * 2 or 3 words.
     * Returns last TWO words if the input sentence contains more than 3 words.
     * @param aFullName
     * @return last name
     */
    public static String getLastName(String aFullName) {
        // basic validation
        if (aFullName == null) {
            return aFullName;
        }
        // remove all double spaces
        aFullName = removeDoubleSpaces(aFullName);

        String[] names = aFullName.split(" ");
        int nameCount = names.length;
        switch (nameCount) {
            case 1:
                return aFullName;
            case 2:
                return names[1] != null ? names[1] : "";
            case 3:
                return names[2] != null ? names[2] : "";
            default:
                return names[nameCount - 2] + " " + names[nameCount - 1];
        }
    }

    /**
     * Returns NULL if no certificate was passed to this method.
     * @param aParser ICertificateParser
     * @return hex-formatted result of MD5Sum
     * @throws NotParseableCertificateException
     */
    public static String createUniqueId(InfoExtractor aParser)
            throws NotParseableCertificateException {
        return createUniqueId(aParser.getCertificate());
    }

    /**
     * Constructs a unique Id for the passed certificate using the Authority Key Identifier
     * and the certificate's Serial Number.
     * @param aCertificate X509Certificate
     * @return hex-formatted string
     * @throws NotParseableCertificateException
     */
    public static String createUniqueId(
            X509Certificate aCertificate) throws NotParseableCertificateException {
        String uniqueId = null;

        try {
            uniqueId = getAuthKeyIdAsString(aCertificate);

            // Checks whether authority key identifier is available
            if (uniqueId == null) {
                throw new NotParseableCertificateException("CERTIFICATE-EXCEPTION: Authority key identifier was not found in the certificate.");
            }

            uniqueId += ":" + aCertificate.getSerialNumber();

        } catch (IOException e) {
            throw new NotParseableCertificateException(e);
        }

        return uniqueId;

    }

    /**
     * This method returns trusted certificate's name
     * This method is used for mapping betwen user Certificate, Trusted Certificate
     * and corresponding CRL.
     * @param aCertificate - Trusted certificate
     * @return CAName - trusted certificate name in format, suitable for inserting in DB
     */
    public static String getTrustedCertificateName(
            X509Certificate aCertificate) {
        if (aCertificate.getSubjectDN() != null) {
            if (aCertificate.getSubjectDN().getName() != null) {
                String CAName = aCertificate.getSubjectDN().getName().split("CN")[1];
                CAName =
                        trimCAName(CAName);
                return CAName;
            }
        }

        return null;
    }

    /**
     * This method accept an ordinary user certificate and returns the name of the
     * certificate, which signed it.
     * This method is used for mapping betwen user Certificate, Trusted Certificate
     * and corresponding CRL.
     * @param aCertificate common user certificate
     * @return CAName issuer's certificate subject name
     */
    public static String getCAIssuerName(
            X509Certificate aCertificate) {
        String CAName = aCertificate.getIssuerDN().getName().split("CN")[1];
        CAName =
                trimCAName(CAName);
        return CAName;
    }

    /**
     * This method is used for mapping betwen user Certificate, Trusted Certificate
     * and corresponding CRL.
     * @param aCRL crl which issuer we need to determine
     * @return CAName trusted certificate name
     */
    public static String getCAName(
            X509CRL aCRL) {
        String CAName = aCRL.getIssuerX500Principal().getName().split("CN")[1];
        CAName =
                trimCAName(CAName);

        return CAName;
    }

    /**
     * This method receives a CRL as input parameter and returns
     * its authority key identifier.
     * Returns NULL if no authority key identifier is provided in the crl.
     * @param aCRL X509CRL
     * @return authority key identifier
     * @throws IOException
     */
    public static String getAuthKeyId(
            X509CRL aCRL) throws IOException {
        String authKeyId = "";

        // Authority Key Identifier
        byte[] authKey =
                aCRL.getExtensionValue(Constants.AUTHORITY_KEY_ID_OID);
        if (authKey != null) {
            // Determine where the keyId starts
            int ind = getAuthKeyIdStartIndex(authKey);

            // Get the Key Identifier
            byte[] keyId = new byte[20];
            for (int i = ind; i < 20 + ind; i++) {
                keyId[i - ind] = authKey[i];
            }

            BigInteger keyIdNum = new BigInteger(1, keyId);
            authKeyId =
                    keyIdNum.toString(16);
        }

        return authKeyId;
    }

    /**
     * This method receives an user certificate as input parameter and returns
     * its authority key identifier.
     * Returns NULL if no authority key identifier is provided in the certificate.
     * NOTE: Master ROOT certificates usually would return NULL.
     * @param aCertificate user certificate
     * @return authority key identifier
     * @throws IOException
     */
    public static String getAuthKeyIdAsString(
            X509Certificate aCertificate) throws IOException {
        String authKeyId = null;

        // Authority Key Identifier
        byte[] authKey =
                aCertificate.getExtensionValue(Constants.AUTHORITY_KEY_ID_OID);

        if (authKey != null) {
            // Determine where the keyId starts
            int ind = getAuthKeyIdStartIndex(authKey);

            // Get the Key Identifier
            byte[] keyId = new byte[20];
            for (int i = ind; i < 20 + ind; i++) {
                keyId[i - ind] = authKey[i];
            }

            BigInteger keyIdNum = new BigInteger(1, keyId);
            authKeyId =
                    keyIdNum.toString(16);
        }

        return authKeyId;

    }

    /**
     * This method receives an user certificate as input parameter and returns
     * its authority key identifier.
     * Returns NULL if no authority key identifier is provided in the certificate.
     * NOTE: Master ROOT certificates usually would return NULL.
     * @param aCertificate user certificate
     * @return authority key identifier
     */
    public static byte[] getAuthKeyId(X509Certificate aCertificate) {
        // Authority Key Identifier
        byte[] authKey =
                aCertificate.getExtensionValue(Constants.AUTHORITY_KEY_ID_OID);
        byte[] keyId = new byte[20];

        if (authKey != null) {
            // Determine where the keyId starts
            int ind = getAuthKeyIdStartIndex(authKey);

            // Get the Key Identifier
            for (int i = ind; i < ind + 20; i++) {
                keyId[i - ind] = authKey[i];
            }

            /*
            BigInteger keyIdNum = new BigInteger(1, keyId);
            authKeyId = keyIdNum.toString(16);
             */
        }

        return keyId;

    }

    /**
     * This method receives a trusted certificate as input parameter and returns
     * its subject key identifier.
     * @param aCertificate Trusted certificate
     * @return subject key identifier
     */
    public static String getSubjectKeyIdAsString(
            X509Certificate aCertificate) {
        String subjKeyId = null;

        // Subject Key Identifier
        byte[] subjKey =
                aCertificate.getExtensionValue(Constants.SUBJECT_KEY_ID_OID);

        // Get the OCTET STRING - From 4th to 24th Byte
        byte[] keyId = new byte[20];

        //Ex4160414 (usually) - It indicates the start of Subject Key Id
        System.out.println(new BigInteger(1, subjKey).toString(16));
        int ind = getSubjKeyIdStartIndex(subjKey);

        for (int i = ind; i < ind + 20; i++) {
            keyId[i - ind] = subjKey[i];
        }

        BigInteger keyIdNum = new BigInteger(1, keyId);
        subjKeyId =
                keyIdNum.toString(16);

        return subjKeyId;
    }

    /**
     * This method receives a trusted certificate as input parameter and returns
     * its subject key identifier.
     * @param aCertificate Trusted certificate
     * @return subject key identifier
     */
    public static byte[] getSubjectKeyId(X509Certificate aCertificate) {
        byte[] subjKeyId = new byte[20];

        // Subject Key Identifier
        byte[] subjKey =
                aCertificate.getExtensionValue(Constants.SUBJECT_KEY_ID_OID);

        // Get the OCTET STRING - From 4th to 24th Byte
        //Ex4160414 (usually 4 bytes) - It indicates the start of Subject Key Id
        int ind = getSubjKeyIdStartIndex(subjKey);

        for (int i = ind; i < ind + 20; i++) {
            subjKeyId[i - ind] = subjKey[i];
        }

        return subjKeyId;
    }

    /**
     * This method finds the position in ASN1 DER formatted Authority Key Identifier,
     * where the Key Identifier value could be found.
     * @param authKeyId ASN1 DER formatted Authority Key Identifier (OID 2.5.29.35)
     * @return
     */
    static int getAuthKeyIdStartIndex(byte[] authKeyId) {
        int index = 0;
        for (int i = 1; i < authKeyId.length; i++) {
            if (authKeyId[i] == (byte) Constants.AUTH_KEY_IDENTIFIER_FLAG_SECOND_BYTE) {
                if (authKeyId[i - 1] == (byte) Constants.AUTH_KEY_IDENTIFIER_FLAG_FIRST_BYTE) {
                    index = i + 1;
                    break;
                }
            }
        }
        return index;
    }

    /**
     * This method finds the position in ASN1 DER formatted Subject Key Identifier,
     * where the Key Identifier value could be found.
     * <BR>
     * Ex4160414 (usually) - It indicates the start of Subject Key Id
     * @param authKeyId ASN1 DER formatted Subject Key Identifier (OID 2.5.29.14)
     * @return
     */
    static int getSubjKeyIdStartIndex(byte[] authKeyId) {
        int index = 0;
        for (int i = 3; i < authKeyId.length - 3; i++) {
            if (authKeyId[i] == (byte) Constants.SUBJECT_KEY_IDENTIFIER_FLAG_FOURTH_BYTE) {
                if (authKeyId[i - 1] == (byte) Constants.SUBJECT_KEY_IDENTIFIER_FLAG_THIRD_BYTE) {
                    if (authKeyId[i - 2] == (byte) Constants.SUBJECT_KEY_IDENTIFIER_FLAG_SECOND_BYTE) {
                        if (authKeyId[i - 3] == (byte) Constants.SUBJECT_KEY_IDENTIFIER_FLAG_FIRST_BYTE) {
                            index = i + 1;
                            break;
                        }
                    }
                }
            }
        }
        return index;
    }

    /**
     * This method trims the subject name, so it length is no longer than
     * the maximum size, defined with the MAX_CA_NAME_LENGTH paramater.
     * This method is not recommended to be changed.
     * @param aCAName
     * @return trimmed aCAName
     */
    static String trimCAName(String aCAName) {
        // InfoNotary specific delimiter - "+"
        aCAName = aCAName.substring(1).split("\\+")[0];
        aCAName =
                aCAName.split(",")[0];

        // If it is still longer, we simply cut the additional letters
        if (aCAName.length() > Constants.MAX_CA_NAME_LENGTH) {
            aCAName = aCAName.substring(0, Constants.MAX_CA_NAME_LENGTH - 1);
        }

        aCAName = ParsingUtils.trimString(aCAName);

        return aCAName;
    }

    /**
     * Recursive method that removes all double quotes, commas and white spaces and [:]
     * from the start and the ending of the passed string.
     * @param text the string which is going to be trimmed
     * @return a trimmed string
     */
    public static String trimString(String text) {
        String badSymbols = "[\"]|[ ]|[,]|[:]";
        String result = text.replaceAll("(^(" + badSymbols + "))|((" + badSymbols + ")$)", "");
//        boolean badChar = false;
//
//        // trims front side of the String
//        badChar = text.charAt(0) == '"' || text.charAt(0) == ' ' || text.charAt(0) == ',' || text.charAt(0) == ':';
//        if (badChar && text.length() > 0) {
//            text = trimString(text.substring(1, text.length()));
//        }
//
//        // trims back side of the String
//        badChar = text.charAt(text.length() - 1) == '"' || text.charAt(text.length() - 1) == ' ' || text.charAt(text.length() - 1) == ',' || text.charAt(text.length() - 1) == ':';
//        if (badChar && text.length() > 0) {
//            text = trimString(text.substring(0, text.length() - 1));
//        }

        return result;
    }

    /**
     * Recursive function which removes all consecutive white spaces, leaving
     * only single spacing.
     * @param text
     * @return
     */
    static String removeDoubleSpaces(String text) {
        // replace double space with single space character
        text = text.replaceAll("  ", " ");
        if (text.indexOf("  ") > -1) {
            text = removeDoubleSpaces(text);
        }
        return text;
    }
}
