package com.tlogica.jsec.parsing;

import java.security.cert.X509Certificate;

//NOTE: This is simplified version see ... other projcets 
public class InfoExtractorFactory {

    /**
     * Encapsulates the default constructor.
     */
    private InfoExtractorFactory() {
    }

    /**
     * This is the main ParserFactory method, which holds the responsibility
     * to determine the certificate's issuer name and in conformity with it to
     * pass the certificate to a specific certificate parser.
     *
     * @param aCertificate the certificate, which needs to be parsed
     * @return ICertificateParser
     * @throws NotRecognizedAuthorityException if the issuer name does not match
     * any of the predefined in the 'mProviders' enumeration
     * @throws NotRecognizedCertTypeException the certificate type is not determinable
     * @throws NotParseableCertificateException 
     */
    public static InfoExtractor getExtractor(X509Certificate aCertificate)
            throws NotRecognizedAuthorityException {
        String certProvider = getCertificateCA(aCertificate);
        ExtractorType et = ExtractorType.valueOf(certProvider);
        return et.parse(aCertificate);
    }

    /**
     *
     * @param aCertificate the certificate, which CA needs to be determined
     * @return CAName if such was found and matched one in the 'mProviders' enumeration
     * @throws NotRecognizedAuthorityException if the issuer's company name does not
     * match any of the predefined in the 'mProviders' enumeration
     */
    public static String getCertificateCA(X509Certificate aCertificate)
            throws NotRecognizedAuthorityException //
    {
        String issuerDN = aCertificate.getIssuerDN().getName();
        if (issuerDN != null) {
            ExtractorType[] tmpArr = ExtractorType.values();
            for (int i = 0; i < tmpArr.length; i++) {
                ExtractorType provider = tmpArr[i];
                if (issuerDN.toUpperCase().indexOf(provider.toString().toUpperCase()) > -1) {
                    return provider.toString();
                }
            }
        }
        return issuerDN;
    }
}
