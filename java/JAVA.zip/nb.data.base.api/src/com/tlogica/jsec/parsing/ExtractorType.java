package com.tlogica.jsec.parsing;

import com.tlogica.jsec.parsing.bg.*;
import java.io.*;
import java.security.GeneralSecurityException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * Подържаните източници на сертификати са :
 * InfoNotary, Bankservice, Information, Spektar, SEP
 *
 * 1) за всеки от тях е направен отделен клас, който вади егн, булстат, имена и т.н.
 * 2) всеки от тях има адрес за ocsp-валидация
 * 3) всеки от тях има група сертификати ...
 * 
 * @author Цанко Ст.( tsani_san@abv.bg )
 */
// NOTE: tss, enum to class
public class ExtractorType {

    private static final ExtractorType[] values;
    public static final ExtractorType InfoNotary =
            new ExtractorType("InfoNotary", InfoNotaryExtractor.class, "http://ocsp.infonotary.com/responder.cgi");
    public static final ExtractorType Bankservice =
            new ExtractorType("Bankservice", BankServiceExtractor.class, "http://ocsp.b-trust.org");
    public static final ExtractorType Information =
            new ExtractorType("Information", StampItExtractor.class, null);
    public static final ExtractorType Spektar =
            new ExtractorType("Spektar", SpektarExtractor.class, "http://ocsp.spektar.org/");
    public static final ExtractorType SEP =
            new ExtractorType("SEP", SepExtractor.class, "http://ocsp.mobisafe.bg");
    public static final ExtractorType TSANKO =
            new ExtractorType("TSANKO", TsankoExtractor.class, null);

    static {
	values = new ExtractorType[6];
        values[0] = InfoNotary;
        values[1] = Bankservice;
        values[2] = Information;
        values[3] = Spektar;
        values[4] = SEP;
        values[5] = TSANKO;
    }

    public static ExtractorType valueOf(String certProvider) {
        for (int i = 0; i < values.length; i++) {
            ExtractorType tmp = values[i];
            if (tmp.toString().equals(certProvider)) {
                return tmp;
            }
        }
        throw new RuntimeException(" enum iter=\"" + certProvider + "\" does not exists ");
    }
    // как се казва
    private final String name;
    // клас praser на атрибутите
    private final Class claz;
    // ocsp-проверка
    private final String ocspUrl;
    // ocsp-сертификат
    private X509Certificate ocspCert;
    // списък от сертификатите, с който валидирам
    private Set certs;

    private ExtractorType(String str, Class c, String ocspUrl) {
        name = str;
        this.claz = c;
        this.ocspUrl = ocspUrl;
    }

    public String toString() {
        return name;
    }

    // къде да търся OCSP-валидацията
    public String getOcspUrl() {
        return ocspUrl;
    }

    // дай ми ocsp-сертификата ...
    public X509Certificate getOcspCertificate() {
        if (ocspUrl != null && ocspCert == null) {
            // не съм го зареди още ...
            InputStream is = ExtractorType.class.getResourceAsStream(
                    "/certificates/" + this.toString() + "/ocsp.cer");
            try {
                ocspCert = (X509Certificate) CertificateFactory.getInstance("X509").generateCertificate(is);
                is.close();
            } catch (Exception e) {
                throw new RuntimeException(" failed to load OCSP X509Certificate for " + this, e);
            }
        }
        return ocspCert;
    }

    // дай ми всички възможни сертификати ...
    // базирайки се на типа създавам нужния ...
    public InfoExtractor parse(X509Certificate cert) {
        try {
            return (InfoExtractor) claz.getConstructor(new Class[]{X509Certificate.class}).newInstance(new Object[]{cert});
        } catch (Exception ex) {
            throw new RuntimeException(" О-опс! Разпзнаване на Extractor по тип (" + this + ") ... ", ex);
        }
    }

    // намира с кой от моите съм го подписал 
    public X509Certificate findIssuer(X509Certificate cert) {
        lazyLoad();
        if (cert != null) {
            Iterator iter = certs.iterator();
            while (iter.hasNext()) {
                X509Certificate certIssuer = (X509Certificate) iter.next();
                try {
                    cert.verify(certIssuer.getPublicKey());
                    return certIssuer;
                } catch (GeneralSecurityException ex) {
                    // явно не е подписан с този ...
		    ex = null;
                }
            }
        }
        return null;
    }

    // описание на състоянието
    public void println() {
        System.out.println("------------------");
        System.out.println("name=" + this);
        System.out.println("parser class=" + claz);
        System.out.println("ocsp url=" + ocspUrl);
        String tmpStr = "null";
        if (ocspCert != null) {
            tmpStr = ocspCert.getSerialNumber().toString();
        }
        System.out.println("ocsp cert[ID]=" + tmpStr);
        if (certs != null) {
            Iterator iter = certs.iterator();
            while (iter.hasNext()) {
                X509Certificate c = (X509Certificate) iter.next();
                System.out.println("trusted cert[ID]=" + c.getSerialNumber());
            }
        }
    }

    public static ExtractorType[] values() {
        return values;
    }

    public Set getIssuers() {
        lazyLoad();
        return certs;
    }

    // зарежда списък със сертификати
    private void lazyLoad() {
        if (certs != null) {
            return;
        }
        certs = new HashSet();
        try {
            InputStream is;
            X509Certificate tmp;
            for (int i = 1; i < 1000; i++) {
                is = ExtractorType.class.getResourceAsStream("/certificates/" + this.toString() + "/" + i + ".cer");
                // няма повече
                if (is == null) {
                    break;
                }
                tmp = (X509Certificate) CertificateFactory.getInstance("X509").generateCertificate(is);
                certs.add(tmp);
                is.close();
            }
        } catch (Exception ex) {
            throw new RuntimeException(" failed to load trusted X509Certificates for " + this, ex);
        }
    }
}
