package com.tlogica.jsec.parsing;

import java.security.GeneralSecurityException;

/**
 * This Exception is thrown if a certificate parser decide
 * that the relevant certificate is not parseable (i.e no personId,
 * nor companyId were found in the certificate)
 * @author Miroslav Dzhokanov
 */
public class NotParseableCertificateException extends GeneralSecurityException {

    private static String ERR_MESSAGE = "Not parseable certificate.\n";

    public NotParseableCertificateException(Throwable throwable) {
        super(ERR_MESSAGE);
    }

    public NotParseableCertificateException(String string, Throwable throwable) {
        super(ERR_MESSAGE);
    }

    public NotParseableCertificateException(String string) {
        super(ERR_MESSAGE);
    }

    public NotParseableCertificateException() {
        super(ERR_MESSAGE);
    }
}
