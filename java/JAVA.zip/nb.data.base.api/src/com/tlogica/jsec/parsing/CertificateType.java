package com.tlogica.jsec.parsing;

//NOTE: This is simplified version see ... other projcets
//NOTE: tss, enum to class
public class CertificateType {

    public static final CertificateType Professional, Personal, Technical;

    // само аз правя обекти
    private CertificateType(String str) {
        name = str;
    }
    // как ми се казват обектите
    private final String name;
    //
    public String toString() {
        return name;
    }

    static {
        Professional = new CertificateType("Professional");
        Personal = new CertificateType("Personal");
        Technical = new CertificateType("Technical");
    }
}

