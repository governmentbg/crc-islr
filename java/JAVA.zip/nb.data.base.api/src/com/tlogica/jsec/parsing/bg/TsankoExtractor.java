package com.tlogica.jsec.parsing.bg;

import com.tlogica.jsec.parsing.CertificateType;
import com.tlogica.jsec.parsing.InfoExtractor;
import com.tlogica.jsec.parsing.InfoExtractorFactory;
import com.tlogica.jsec.parsing.NotParseableCertificateException;
import java.io.File;
import java.io.FileInputStream;
import java.io.Serializable;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Прочита данните от сертификати издавани от мен :)
 *
 * @author Цанко Ст.( tsani_san@abv.bg )
 */
public class TsankoExtractor implements InfoExtractor{

    // сертификата
    protected X509Certificate cert;
    // низови ...
    protected String egn, bulstat;

    //
    private void loadCertInfo() throws Exception {

        String subjectInfo = cert.getSubjectDN().getName();
        //System.out.println(cert.getSubjectAlternativeNames());
        //System.out.println(subjectInfo);

        // намирам EGN:
        Matcher m = Pattern.compile("EGN[:]\\d+").matcher(subjectInfo);
        if (m.find()) {
            egn = m.group().substring(4);
        }

        // намирам
        m = Pattern.compile("B[:]\\d+").matcher(subjectInfo);
        if (m.find()) {
            bulstat = m.group().substring(2);
        }
    }

    public TsankoExtractor(X509Certificate aCert) throws NotParseableCertificateException {
        cert = aCert;
        try {
            loadCertInfo();
        } catch (Exception ex) {
            throw new NotParseableCertificateException(ex);
        }
    }

    public X509Certificate getCertificate() {
        return cert;
    }

    public CertificateType getCertificateType() {
        return bulstat != null ? CertificateType.Professional : CertificateType.Personal;
    }

    public String getSerialNumber() {
        return cert.getSerialNumber().toString(16).toUpperCase();
    }

    public String getCertificateUniqueId() {
        return "test-"+cert.getSerialNumber().toString(16).toUpperCase();
    }

    public String getPersonId() {
        return egn;
    }

    public String getPersonMail() {
        return egn+"@tl.com";
    }

    public String getPersonFullName() {
        return "fname lname";
    }

    public String getPersonFirstName() {
        return "fname";
    }

    public String getPersonLastName() {
        return "lname";
    }

    public String getPersonPhoneNumber() {
        return null;
    }

    public String getPersonAddress() {
        return null;
    }

    public String getPersonLocation() {
        return null;
    }

    public String getCompanyId() {
        return bulstat;
    }

    public String getCompanyName() {
        return "tl";
    }

    public String getCompanyAddress() {
        return null;
    }

    public String getTechnicalCertificateName() {
        return null;
    }

    public String getIssuerName() {
        return "tss";
    }

    public String getIssuerCertificateName() {
        return null;
    }

    public String getIssuerPhoneNumber() {
        return null;
    }

    public String getIssuerMail() {
        return null;
    }

    public String getIssuerAddress() {
        return null;
    }

    public String getIssuerLocation() {
        return null;
    }

    public String getIssuerCompanyId() {
        return null;
    }

    public static void main(String[] a) throws Exception {
        File f = new File("D:\\prj-CROZ\\cer&ks\\egn.cer");
        File f1 = new File("D:\\prj-CROZ\\cer&ks\\egn.bulstat.cer");
        File f2 = new File("D:\\prj-CROZ\\cer&ks\\kaloqn.cer");
        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        X509Certificate cert =
                (X509Certificate) cf.generateCertificate(new FileInputStream(f1));
        //TestExtractor te = new TestExtractor(cert);
        InfoExtractorFactory.getExtractor(cert);
    }
}
