package com.tlogica.jsec.parsing;

//NOTE: This is simplified version see ... other projcets
public class Constants {

    public static final String SUBJECT_KEY_ID_OID = "2.5.29.14";
    public static final String AUTHORITY_KEY_ID_OID = "2.5.29.35";

    public static final int AUTH_KEY_IDENTIFIER_FLAG_FIRST_BYTE = -128;
    public static final int AUTH_KEY_IDENTIFIER_FLAG_SECOND_BYTE = 20;
    public static final int SUBJECT_KEY_IDENTIFIER_FLAG_FIRST_BYTE = 4;
    public static final int SUBJECT_KEY_IDENTIFIER_FLAG_SECOND_BYTE = 22;
    public static final int SUBJECT_KEY_IDENTIFIER_FLAG_THIRD_BYTE = 4;
    public static final int SUBJECT_KEY_IDENTIFIER_FLAG_FOURTH_BYTE = 20;
    
    // MAX_CA_NAME_LENGTH depends on the DB column constraint
    public static final int MAX_CA_NAME_LENGTH = 60;
}
