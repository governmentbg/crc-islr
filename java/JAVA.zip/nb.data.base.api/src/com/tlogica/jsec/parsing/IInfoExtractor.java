package com.tlogica.jsec.parsing;

import java.io.Serializable;
import java.security.cert.X509Certificate;

//NOTE: This is simplified version see ... other projcets
public interface IInfoExtractor extends Serializable {

    /**
     * Every parser is connected with a single certificate through composite
     * pattern. That certificate is accessible by this method.
     * @return
     */
    public X509Certificate getCertificate();

    /**
     *
     * @return CertificateType object, which determines whether the
     * certificate is Personal or Professional
     */
    public CertificateType getCertificateType();

    /**
     * @return hex-formatted representation of current
     * certificate's serial number
     */
    public String getSerialNumber();

    /**
     * This method generates an unique identification number for
     * the current certificate. For further information about
     * the algorithm by which this unique Id is constructed,
     * please have a look in X509Manager class.
     * @see com.tlogica.bnbisis.security.certificate.x509.X509Manager
     * @return String certificate Unique ID
     */
    public String getCertificateUniqueId();

    /**
     * This method extracts the titul's identification number (EGN, FIN, SID)
     * @return null if no ID was found in the certificate
     */
    public String getPersonId();

    /**
     * This method extracts a mail address from the certificate, if such
     * is available.
     * It is not specified whether it is an office or personal mail
     * @return null if no mail was found in the certificate
     */
    public String getPersonMail();

    /**
     * This method extracts the full name of the person, which is
     * the titular of the certificate.
     * @return null if no personal name was found in the certificate
     */
    public String getPersonFullName();

    /**
     * This method extracts the first name of the titular
     * @return
     */
    public String getPersonFirstName();

    /**
     * This method extracts the last name of the titular
     * @return
     */
    public String getPersonLastName();

    /**
     * This method extracts a phone number from the certificate, if such
     * is available.
     * It is not specified whether it is an office or home phone number
     * @return null if no phone number was found in the certificate
     */
    public String getPersonPhoneNumber();

    /**
     * This method extracts the personal address from the certificate, if such
     * is available.
     * @return null if no personal address was found in the certificate
     */
    public String getPersonAddress();

    /**
     * This method extracts name of city from the certificate, if such
     * is available.
     * This city defines where the titul of certificate is located (lives or works)
     * @return null if no address was found in the certificate
     */
    public String getPersonLocation();

    /**
     * This method extracts the subject's company identification number
     * (BULSTAT, EIK), if such is available.
     * This method is applicable for professional certificates only.
     * @return null if no company id was found in the certificate or
     * the certificate is not professional at all
     */
    public String getCompanyId();

    /**
     * This method extracts the subject's company name, if such
     * is available.
     * This method is applicable for professional certificates only.
     * @return null if no company name was found in the certificate or
     * the certificate is not professional at all
     */
    public String getCompanyName();

    /**
     * This method extracts company address from the certificate, if such
     * is available.
     * @return null if no company address was found in the certificate
     */
    public String getCompanyAddress();

    /**
     * This method returns name only when the certificate type is TECHNICAL
     * (servers, machines, etc.)
     * @return null if no company address was found in the certificate
     */
    public String getTechnicalCertificateName();

    /**
     * This method extracts the company name of the certificate authority,
     * which issued the current certificate
     * @return
     */
    public String getIssuerName();

    /**
     * This method extracts the CN field of the CA root certificate,
     * which issued the current certificate
     * @return
     */
    public String getIssuerCertificateName();

    /**
     * This method extracts the phone number of the certificate authority,
     * which issued the current certificate
     * @return
     */
    public String getIssuerPhoneNumber();

    /**
     * This method extracts the email of the certificate authority,
     * which issued the current certificate
     * @return
     */
    public String getIssuerMail();

    /**
     * This method extracts the address of the certificate authority,
     * which issued the current certificate
     * @return
     */
    public String getIssuerAddress();

    /**
     * This method extracts the city of the certificate authority,
     * which issued the current certificate
     * @return
     */
    public String getIssuerLocation();

    /**
     * This method extracts the company ID (BULSTAT, EIK ...) of the certificate
     * authority, which issued the current certificate
     * @return
     */
    public String getIssuerCompanyId();
}
