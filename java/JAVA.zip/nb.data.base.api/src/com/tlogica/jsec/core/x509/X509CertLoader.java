package com.tlogica.jsec.core.x509;

import common.StringTool;
import java.io.ByteArrayInputStream;
import java.io.InputStream;

import java.security.GeneralSecurityException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import sun.misc.BASE64Decoder;

//NOTE: This is simplified version see ... other projcets
public class X509CertLoader {

    // NOTE: This is simplified version see ... other projcets
    public static X509Certificate loadX509Certificate(String strSert)
            throws Exception //
    {
        // почиствам низа ...
        strSert = StringTool.replaceAll(strSert, "^[-]+BEGIN CERTIFICATE[-]+", "");
        strSert = StringTool.replaceAll(strSert, "[-]+END CERTIFICATE[-]+$", "");
        X509Certificate sert;
        BASE64Decoder decoder = new BASE64Decoder();
        InputStream is = new ByteArrayInputStream(decoder.decodeBuffer(strSert));

        try {
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            sert = (X509Certificate) cf.generateCertificate(is);
        } catch (GeneralSecurityException e) {
            throw new Exception(" неуспях при правенето на сертификат от низ\n" + e);
        }
        return sert;
    }
}
